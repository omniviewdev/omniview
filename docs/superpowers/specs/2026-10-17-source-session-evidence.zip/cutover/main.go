package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"runtime"
	"sort"
	"strings"
)

type Results struct {
	Purpose string `json:"purpose"`
	Command string `json:"command"`
	WorkingDirectory string `json:"workingDirectory"`
	Runtime map[string]string `json:"runtime"`
	SHA256 map[string]string `json:"sha256"`
	Summary map[string]int `json:"summary"`
	Checks []Check `json:"checks"`
	Scenarios []Scenario `json:"scenarios"`
	Limitations []string `json:"limitations"`
	SemanticAmbiguities []string `json:"semanticAmbiguities"`
}
func readJSON(path string, dst any) { b,err:=os.ReadFile(path); must(err); must(json.Unmarshal(b,dst)) }
func writeJSON(path string, value any) { b,err:=json.MarshalIndent(value,"","  "); must(err); b=append(b,'\n'); must(os.WriteFile(path,b,0600)) }
func limitations() []string { return []string{
	"Throwaway deterministic native-style simulator and host staging model only; NOT an actual cloud, container, hypervisor or Kubernetes provider, production adapter, SDK binding or real transport.",
	"Frames undergo in-process JSON marshal/unmarshal only, not IPC/TCP/gRPC/Wails; framing and pre-allocation wire limits, cancellation races, refcounts and real backpressure belong to the separate lifecycle probe.",
	"The strong fixture assumes native immutable snapshot/cursor-chain semantics; a real provider needs independent evidence for those semantics, cursor expiry and selection/access consistency. Simulator ordinals never reach the host and source revisions are never used to order.",
	"Weak subscribe/list/replay deliberately remains stale at the bounded controlled horizon. Expected counterexample checks are NOT successful recency/reconciliation feature passes. Later delayed events could heal the state but cannot erase the demonstrated regression.",
	"Absent-incarnation fixture intentionally withholds known native identity evidence. It demonstrates ambiguity, not a recreation-safe adapter. No UID, global order, synthetic watcher, retry or host repair is invented.",
	"Expected row states are independently authored in expected.json from native histories. Native truth mutates from fixtures.json independently of source frames; row projections are test diagnostics, NOT a query evaluator or result delivery.",
	"Source/access provenance is represented by isolated host/session bindings and out-of-band fixture principal labels, not a real authorization system. No cross-credential body merge or multi-source conflict-resolution algorithm is implemented.",
	"Partial snapshots publish only staged current-generation observations. Unseen old observations stay in a separate explicitly stale cache with original generations; they are not promoted into the current source view. Broader sources remain isolated. This is a private-cache demonstration, not a product stale-data policy/UI.",
	"Buffer bytes count serialized native packets, and staging bytes count serialized entries. These are deterministic logical bounds, not measured allocator/RSS ceilings or proof against allocating an oversized native callback before admission.",
	"Exact-scope selection, enumeration, one representation/schema binding and JSON text are exercised. QueryScope any/oneOf normalization (including empty oneOf), nativeQuery capability admission, denied/unsupported opens, SourceError DTOs, EOF/cancellation and coverage-progress-only changes are unexercised here.",
	"Document admission validates JSON, selected binding and typed present/knownAbsent contradictions. It is not a full schema/type validator, field-level authorization system, projection engine, general source-resume endpoint or durable log.",
	"No actual concurrency, sleep-based timing evidence, real provider I/O, query-result generation, combined SDK ingestion/evaluation/result integration, UI behavior or performance claim. Explicit step schedules establish only the simulated interleavings.",
} }
func ambiguities() []string { return []string{
	"The contract intentionally leaves the product stale-data publication/retention policy open. This probe keeps stale cache entries separate and labels old published views unsynchronized during replacement; consumers are not implemented.",
	"Native absence of ordering/incarnation evidence cannot distinguish an old delete from a current membership remove. Stronger recency/recreation guarantees are unsupported without native proof; bestEffort is a declaration, not a repair algorithm.",
	"No generic source-to-source body reconciliation rule is specified. This probe preserves source membership independently rather than silently choosing a global latest observation.",
	"Exact domain/protobuf mapping, transport/decode accounting and real adapter ordering proofs remain production prerequisites. The simulated cursor chain is not portable sourceRevision ordering or a public resume contract.",
} }
func report(res Results) string {
	var b strings.Builder
	fmt.Fprintln(&b,"# Throwaway acquisition cutover confirmation probe")
	fmt.Fprintln(&b,"\nThis is executed feasibility evidence from a deterministic native-style simulator, not product implementation or a real provider/SDK/transport proof.")
	fmt.Fprintln(&b,"\n## Reproduction")
	fmt.Fprintf(&b,"\nWorking directory: `%s`\n\nExact command:\n\n```sh\nGOWORK=off go run .\n```\n",res.WorkingDirectory)
	fmt.Fprintf(&b,"\nObserved runtime: `%s %s/%s`; GOWORK environment: `%s`. Standard library only; `go.mod` requests Go 1.26.1.\n",res.Runtime["goVersion"],res.Runtime["goos"],res.Runtime["goarch"],res.Runtime["GOWORK"])
	fmt.Fprintf(&b,"\nObserved assertions: **%d passed, %d failed**, across %d scenario records (%d expected counterexample/limitation records). Unexpected assertions exit nonzero. Expected known-broken behavior is classified separately; it is not counted as a successful repair feature.\n",res.Summary["checksPassed"],res.Summary["checksFailed"],res.Summary["scenarios"],res.Summary["expectedCounterexamplesAndLimitations"])
	fmt.Fprintln(&b,"\n## Evidence and independent oracle")
	fmt.Fprintln(&b,"\n- `fixtures.json`: explicit native initial state, ordered mutations, opaque native cursors, weak delayed-callback schedule, provider-neutral selections and opaque-revision counterexamples.\n- `expected.json`: independently authored checkpoint row states; not generated from emitted frames. Native truth is separately updated from the native history.\n- `actual.json`: observed checkpoint rows plus numeric-lexeme and opaque-token controls.\n- `frames.json`: exact source DTO frame traces after a JSON text boundary roundtrip, plus deliberate host rejections.\n- `results.json`: every expected/actual assertion, classifications, observed limits/peaks, coverage and continuity, hashes, versions and limitations.\n- `report.md`: this generated human-readable report. A first assertion failure, if encountered, is preserved in `failures-initial.json`.")
	fmt.Fprintln(&b,"\n## Principal findings")
	fmt.Fprintln(&b,"\n1. **Conditional strong profile:** immutable native cut0 stays frozen while events 1–5 accumulate under an opaque native cursor chain. Only snapshotEnd publishes cut0; the ordered replay is one host publication, then events 6–7 continue. Known incompatible-incarnation remove cannot erase the recreated value. Native truth and final host state independently equal `{a: final|a2, c: added|c1}`. The adapter, not the host, owns native ordering.\n2. **Known-broken naive adapter:** subscribe → buffer update `9` → newer page `10` → snapshotEnd → replay `9` overwrites a known newer page while all source frames remain contiguous. A later membership removal is also exercised. Native truth remains `newer-page|a1`; the host ends at `older-buffered|a1`. This is an expected counterexample, explicitly bestEffort—not a repaired or gap-free feature.\n3. **Coverage is not continuity:** source enumeration, source consistency, continuity and per-document field coverage are recorded separately. Exhausted point-in-time enumeration can contain a partial document. Mutable pagination is exhausted but bestEffort; contiguous delivery does not elevate it.\n4. **Boundaries and isolation:** no updates before snapshotEnd, no late old snapshot pages after it, immutable replaced views, old-generation rejection, empty finite snapshots, isolated source-owned membership and partial resnapshot stale-cache separation are exercised.\n5. **Failure behavior:** an opaque native cursor-chain gap invalidates an earlier gap-free claim. Item/byte startup overflow resets and frees native buffer and staging without publication; separate staging bounds reject atomically.\n6. **Admission and exactness:** typed cloud/container/VM selections need no Kubernetes fields. JSON text retains `9007199254740993`, `1.2300e+04`, and `-0`; a float64 control rounds the integer. Representation/schema/scope/provider escapes and typed known-absent contradictions reject the whole ordered changes batch. Canonical decimal sequence controls reject zero, leading zeros, plus, whitespace and uint64 overflow.\n7. **Explicit limitation:** a stale remove without surfaced incarnation evidence can erase a recreated host observation while native truth retains it. No generic host revision sorting or recreation repair is fabricated.")
	fmt.Fprintln(&b,"\n## Scenario outcomes\n\n| Scenario | Classification | Enumeration / consistency | Continuity |\n| --- | --- | --- | --- |")
	for _,s:=range res.Scenarios { coverage:="not published"; if s.Coverage!=nil { coverage=s.Coverage.Enumeration+" / "+s.Coverage.Consistency }; continuity:=s.Continuity; if continuity=="" { continuity="not established" }; fmt.Fprintf(&b,"| %s | %s | %s | %s |\n",s.Name,s.Classification,coverage,continuity) }
	fmt.Fprintln(&b,"\nA recorded published continuity describes the last valid view. Gap/reset or admission rejection sets the host unsynchronized, so it is not an active continuity claim after failure. See each scenario's phase/reset evidence.")
	fmt.Fprintln(&b,"\n## Observed counters and bounds")
	for _,s:=range res.Scenarios { if strings.HasPrefix(s.Name,"strong_") || strings.HasPrefix(s.Name,"native_startup_") || strings.HasPrefix(s.Name,"host_staging_") { data,err:=json.MarshalIndent(s.Evidence,"","  "); must(err); fmt.Fprintf(&b,"\n### %s\n\n```json\n%s\n```\n",s.Name,data) } }
	fmt.Fprintln(&b,"\n## SHA-256 source and fixture identity")
	keys:=make([]string,0,len(res.SHA256)); for k:=range res.SHA256 { keys=append(keys,k) }; sort.Strings(keys)
	for _,k:=range keys { fmt.Fprintf(&b,"\n- `%s`: `%s`",k,res.SHA256[k]) }; fmt.Fprintln(&b)
	fmt.Fprintln(&b,"\n## Limits")
	for _,l:=range res.Limitations { fmt.Fprintf(&b,"\n- %s",l) }; fmt.Fprintln(&b)
	fmt.Fprintln(&b,"\n## Unclosed semantic questions / production prerequisites")
	for _,a:=range res.SemanticAmbiguities { fmt.Fprintf(&b,"\n- %s",a) }; fmt.Fprintln(&b)
	return b.String()
}
func main() {
	r:=&Run{Expected:map[string]map[string]string{},Frames:map[string]*Recorder{},Actual:map[string]any{}}
	readJSON("fixtures.json",&r.Fixtures); readJSON("expected.json",&r.Expected); r.execute()
	for name:=range r.Expected { _,ok:=r.Actual[name]; r.check("oracle.expectation-exercised."+name,true,ok) }
	passed,failed,counterexamples:=0,0,0
	for _,c:=range r.Checks { if c.Passed { passed++ } else { failed++ } }; for _,s:=range r.Scenarios { if strings.HasPrefix(s.Classification,"expected_") { counterexamples++ } }
	cwd,err:=os.Getwd(); must(err)
	res:=Results{Purpose:"throwaway deterministic acquisition cutover feasibility evidence",Command:"GOWORK=off go run .",WorkingDirectory:cwd,Runtime:map[string]string{"goVersion":runtime.Version(),"goos":runtime.GOOS,"goarch":runtime.GOARCH,"GOWORK":os.Getenv("GOWORK")},SHA256:map[string]string{},Summary:map[string]int{"checksPassed":passed,"checksFailed":failed,"scenarios":len(r.Scenarios),"expectedCounterexamplesAndLimitations":counterexamples},Checks:r.Checks,Scenarios:r.Scenarios,Limitations:limitations(),SemanticAmbiguities:ambiguities()}
	for _,name:=range []string{"go.mod","model.go","native.go","scenarios.go","main.go","fixtures.json","expected.json"} { b,err:=os.ReadFile(name); must(err); hash:=sha256.Sum256(b); res.SHA256[name]=hex.EncodeToString(hash[:]) }
	writeJSON("actual.json",r.Actual); writeJSON("frames.json",r.Frames); writeJSON("results.json",res); must(os.WriteFile("report.md",[]byte(report(res)),0600))
	if failed>0 { if _,err:=os.Stat("failures-initial.json"); os.IsNotExist(err) { writeJSON("failures-initial.json",res) }; for _,c:=range r.Checks { if !c.Passed { fmt.Fprintf(os.Stderr,"FAIL %s: expected=%v actual=%v\n",c.Name,c.Expected,c.Actual) } } }
	data,err:=json.MarshalIndent(res.Summary,"","  "); must(err); fmt.Println(string(data))
	if failed>0 { os.Exit(1) }
}
