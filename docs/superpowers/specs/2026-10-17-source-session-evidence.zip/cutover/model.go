package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"reflect"
	"strconv"
)

type Binding struct {
	Provider string `json:"provider"`
	Authority string `json:"authority"`
	Type string `json:"type"`
	Scope map[string]string `json:"scope"`
	RepresentationID string `json:"representationId"`
	SchemaID string `json:"schemaId"`
	SchemaRevision string `json:"schemaRevision"`
}
type Address struct {
	Provider string `json:"provider"`
	Authority string `json:"authority"`
	Type string `json:"type"`
	Scope map[string]string `json:"scope"`
	ID string `json:"id"`
}
type Representation struct {
	ID string `json:"representationId"`
	Schema struct { ID string `json:"id"`; Revision string `json:"revision"` } `json:"schema"`
}
type Segment struct { Kind string `json:"kind"`; Name string `json:"name,omitempty"`; Index int `json:"index,omitempty"` }
type DocumentCoverage struct { Kind string `json:"kind"`; KnownAbsent [][]Segment `json:"knownAbsent,omitempty"` }
type Document struct { Encoding string `json:"encoding"`; Text string `json:"text"` }
type Observation struct {
	Address Address `json:"address"`
	Representation Representation `json:"representation"`
	Document Document `json:"document"`
	DocumentCoverage DocumentCoverage `json:"documentCoverage"`
	Incarnation string `json:"incarnation,omitempty"`
	Revision string `json:"sourceRevision,omitempty"`
}
type Change struct {
	Kind string `json:"kind"`
	Observation *Observation `json:"observation,omitempty"`
	Address *Address `json:"address,omitempty"`
	Incarnation string `json:"incarnation,omitempty"`
	Revision string `json:"sourceRevision,omitempty"`
}
type Coverage struct {
	Enumeration string `json:"enumeration"`
	Consistency string `json:"consistency"`
	Limitations []string `json:"limitations"`
}
type Payload struct {
	Kind string `json:"kind"`
	Mode string `json:"mode,omitempty"`
	Observations []Observation `json:"observations,omitempty"`
	Changes []Change `json:"changes,omitempty"`
	Coverage *Coverage `json:"coverage,omitempty"`
	Continuity string `json:"continuity,omitempty"`
	Reason string `json:"reason,omitempty"`
}
type Frame struct { Session string `json:"sessionId"`; Generation string `json:"generation"`; Sequence string `json:"sequence"`; Payload Payload `json:"payload"` }
type Entry struct { Observation Observation `json:"observation"`; Generation string `json:"observedGeneration"` }
type View struct {
	Generation string `json:"generation"`
	Members map[string]Entry `json:"members"`
	Coverage Coverage `json:"coverage"`
	Continuity string `json:"continuity"`
}
type Host struct {
	Binding Binding
	Session, Generation, Mode, Phase string
	Next uint64
	Stage map[string]Entry
	Published *View
	StaleCache map[string]Entry
	Synchronized bool
	Publications, IgnoredStale, IgnoredIncarnation int
	StagePeakItems, StagePeakBytes int
	MaxStageItems, MaxStageBytes int
}

func clone[T any](v T) T { b, err := json.Marshal(v); must(err); var out T; must(json.Unmarshal(b, &out)); return out }
func addressKey(a Address) string { b, err := json.Marshal(a); must(err); return string(b) }
func copyMembers(in map[string]Entry) map[string]Entry { out := make(map[string]Entry, len(in)); for k, v := range in { out[k] = v }; return out }
func newHost(b Binding, session, gen, mode string) *Host {
	h := &Host{Binding:clone(b), Session:session, StaleCache:map[string]Entry{}, MaxStageItems:16, MaxStageBytes:16384}
	h.Open(gen, mode)
	return h
}
func (h *Host) Open(gen, mode string) {
	h.Generation, h.Mode, h.Phase, h.Next = gen, mode, "opening", 1
	h.Stage = map[string]Entry{}
	h.Synchronized = false
}
func (h *Host) invalidate(reason string) error { h.Phase = "invalid"; h.Stage = nil; h.Synchronized = false; return errors.New(reason) }
func (h *Host) validateAddress(a Address) error {
	if a.ID == "" || a.Provider != h.Binding.Provider || a.Authority != h.Binding.Authority || a.Type != h.Binding.Type || !reflect.DeepEqual(a.Scope, h.Binding.Scope) { return errors.New("address selection escape") }
	return nil
}
func present(root any, path []Segment) (bool, error) {
	v := root
	for _, s := range path {
		switch s.Kind {
		case "member": obj, ok := v.(map[string]any); if !ok { return false, nil }; var found bool; v, found = obj[s.Name]; if !found { return false, nil }
		case "index": if s.Index < 0 { return false, errors.New("negative array index") }; arr, ok := v.([]any); if !ok || s.Index >= len(arr) { return false, nil }; v = arr[s.Index]
		default: return false, errors.New("invalid coverage path kind")
		}
	}
	return true, nil
}
func (h *Host) validateObservation(o Observation) error {
	if err := h.validateAddress(o.Address); err != nil { return err }
	if o.Representation.ID != h.Binding.RepresentationID || o.Representation.Schema.ID != h.Binding.SchemaID || o.Representation.Schema.Revision != h.Binding.SchemaRevision { return errors.New("representation/schema binding mismatch") }
	if o.Document.Encoding != "json" { return errors.New("unsupported document encoding") }
	dec := json.NewDecoder(bytes.NewBufferString(o.Document.Text)); dec.UseNumber()
	var body any
	if err := dec.Decode(&body); err != nil { return fmt.Errorf("invalid JSON: %w", err) }
	var extra any
	if err := dec.Decode(&extra); err != io.EOF { return errors.New("trailing document JSON") }
	if o.DocumentCoverage.Kind != "complete" && o.DocumentCoverage.Kind != "partial" { return errors.New("invalid document coverage") }
	if o.DocumentCoverage.Kind == "complete" && len(o.DocumentCoverage.KnownAbsent) > 0 { return errors.New("complete coverage has partial facts") }
	for _, p := range o.DocumentCoverage.KnownAbsent { found, err := present(body, p); if err != nil { return err }; if found { return errors.New("present/knownAbsent contradiction") } }
	return nil
}
func (h *Host) stageLimits(m map[string]Entry) error {
	b, err := json.Marshal(m); if err != nil { return err }
	if len(m) > h.MaxStageItems || len(b) > h.MaxStageBytes { return errors.New("staging limit exceeded") }
	if len(m) > h.StagePeakItems { h.StagePeakItems = len(m) }; if len(b) > h.StagePeakBytes { h.StagePeakBytes = len(b) }
	return nil
}
func validCoverage(c *Coverage) bool {
	if c == nil { return false }
	return (c.Enumeration == "exhausted" || c.Enumeration == "partial" || c.Enumeration == "unknown") && (c.Consistency == "pointInTime" || c.Consistency == "bestEffort" || c.Consistency == "unknown")
}
func (h *Host) Apply(f Frame) error {
	if f.Session != h.Session || f.Generation != h.Generation { h.IgnoredStale++; return errors.New("stale session/generation") }
	if h.Phase == "invalid" || h.Phase == "reset" || h.Phase == "finished" { return errors.New("terminal generation") }
	n, err := strconv.ParseUint(f.Sequence, 10, 64)
	if err != nil || n == 0 || strconv.FormatUint(n,10) != f.Sequence || n != h.Next { return h.invalidate("noncanonical or discontinuous source sequence") }
	if n == ^uint64(0) { return h.invalidate("sequence exhaustion") }
	p := f.Payload
	switch p.Kind {
	case "begin":
		if h.Phase != "opening" || n != 1 || p.Mode != h.Mode { return h.invalidate("invalid begin or silent mode downgrade") }; h.Phase = "snapshotting"
	case "snapshot":
		if h.Phase != "snapshotting" { return h.invalidate("snapshot outside snapshot phase") }
		next := copyMembers(h.Stage)
		for _, o := range p.Observations { if err := h.validateObservation(o); err != nil { return h.invalidate(err.Error()) }; next[addressKey(o.Address)] = Entry{clone(o),h.Generation} }
		if err := h.stageLimits(next); err != nil { return h.invalidate(err.Error()) }; h.Stage = next
	case "snapshotEnd":
		if h.Phase != "snapshotting" || !validCoverage(p.Coverage) { return h.invalidate("invalid snapshot boundary") }
		if (h.Mode == "snapshot" && p.Continuity != "notApplicable") || (h.Mode == "snapshotAndUpdates" && p.Continuity != "gapFree" && p.Continuity != "bestEffort") { return h.invalidate("invalid continuity for mode") }
		stale := map[string]Entry{}
		if p.Coverage.Enumeration != "exhausted" {
			stale = copyMembers(h.StaleCache)
			if h.Published != nil { for k,v := range h.Published.Members { stale[k] = v } }
			for k := range h.Stage { delete(stale,k) }
		}
		h.StaleCache = stale
		h.Published = &View{h.Generation,copyMembers(h.Stage),clone(*p.Coverage),p.Continuity}
		h.Stage = nil; h.Publications++; h.Synchronized = true
		if h.Mode == "snapshot" { h.Phase = "finished" } else { h.Phase = "following" }
	case "changes":
		if h.Phase != "following" || (len(p.Changes) == 0 && p.Coverage == nil) { return h.invalidate("changes outside following or no-op batch") }
		if p.Coverage != nil && !validCoverage(p.Coverage) { return h.invalidate("invalid coverage progress") }
		next := copyMembers(h.Published.Members)
		ignored := 0
		for _, c := range p.Changes {
			switch c.Kind {
			case "upsert":
				if c.Observation == nil { return h.invalidate("missing upsert observation") }; if err := h.validateObservation(*c.Observation); err != nil { return h.invalidate(err.Error()) }; next[addressKey(c.Observation.Address)] = Entry{clone(*c.Observation),h.Generation}
			case "remove":
				if c.Address == nil { return h.invalidate("missing remove address") }; if err := h.validateAddress(*c.Address); err != nil { return h.invalidate(err.Error()) }
				key := addressKey(*c.Address); old, exists := next[key]
				if exists && c.Incarnation != "" && old.Observation.Incarnation != "" && old.Observation.Incarnation != c.Incarnation { ignored++; continue }; delete(next,key)
			default: return h.invalidate("unknown source change")
			}
		}
		cov := h.Published.Coverage; if p.Coverage != nil { cov = clone(*p.Coverage) }
		h.Published = &View{h.Generation,next,cov,h.Published.Continuity}; h.Publications++; h.IgnoredIncarnation += ignored
	case "reset":
		if p.Reason != "continuityLost" && p.Reason != "overflow" && p.Reason != "bindingChanged" && p.Reason != "sourceInvalidated" { return h.invalidate("invalid reset reason") }
		h.Phase = "reset"; h.Stage = nil; h.Synchronized = false
	default: return h.invalidate("unimplemented frame kind in bounded cutover fixture")
	}
	h.Next++
	return nil
}

func stateRows(m map[string]Entry) map[string]string {
	out := map[string]string{}
	for _, e := range m { var body struct { State string `json:"state"` }; must(json.Unmarshal([]byte(e.Observation.Document.Text), &body)); out[e.Observation.Address.ID] = body.State + "|" + e.Observation.Incarnation }
	return out
}
func (h *Host) rows() map[string]string { if h.Published == nil { return map[string]string{} }; return stateRows(h.Published.Members) }
func (h *Host) staleRows() map[string]string { return stateRows(h.StaleCache) }
