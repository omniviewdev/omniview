# Throwaway acquisition cutover confirmation probe

This is executed feasibility evidence from a deterministic native-style simulator, not product implementation or a real provider/SDK/transport proof.

## Reproduction

Working directory: `/tmp/omniview-source-confirm.nmPjpd/cutover`

Exact command:

```sh
GOWORK=off go run .
```

Observed runtime: `go1.26.1 darwin/arm64`; GOWORK environment: `off`. Standard library only; `go.mod` requests Go 1.26.1.

Observed assertions: **168 passed, 0 failed**, across 25 scenario records (2 expected counterexample/limitation records). Unexpected assertions exit nonzero. Expected known-broken behavior is classified separately; it is not counted as a successful repair feature.

## Evidence and independent oracle

- `fixtures.json`: explicit native initial state, ordered mutations, opaque native cursors, weak delayed-callback schedule, provider-neutral selections and opaque-revision counterexamples.
- `expected.json`: independently authored checkpoint row states; not generated from emitted frames. Native truth is separately updated from the native history.
- `actual.json`: observed checkpoint rows plus numeric-lexeme and opaque-token controls.
- `frames.json`: exact source DTO frame traces after a JSON text boundary roundtrip, plus deliberate host rejections.
- `results.json`: every expected/actual assertion, classifications, observed limits/peaks, coverage and continuity, hashes, versions and limitations.
- `report.md`: this generated human-readable report. A first assertion failure, if encountered, is preserved in `failures-initial.json`.

## Principal findings

1. **Conditional strong profile:** immutable native cut0 stays frozen while events 1–5 accumulate under an opaque native cursor chain. Only snapshotEnd publishes cut0; the ordered replay is one host publication, then events 6–7 continue. Known incompatible-incarnation remove cannot erase the recreated value. Native truth and final host state independently equal `{a: final|a2, c: added|c1}`. The adapter, not the host, owns native ordering.
2. **Known-broken naive adapter:** subscribe → buffer update `9` → newer page `10` → snapshotEnd → replay `9` overwrites a known newer page while all source frames remain contiguous. A later membership removal is also exercised. Native truth remains `newer-page|a1`; the host ends at `older-buffered|a1`. This is an expected counterexample, explicitly bestEffort—not a repaired or gap-free feature.
3. **Coverage is not continuity:** source enumeration, source consistency, continuity and per-document field coverage are recorded separately. Exhausted point-in-time enumeration can contain a partial document. Mutable pagination is exhausted but bestEffort; contiguous delivery does not elevate it.
4. **Boundaries and isolation:** no updates before snapshotEnd, no late old snapshot pages after it, immutable replaced views, old-generation rejection, empty finite snapshots, isolated source-owned membership and partial resnapshot stale-cache separation are exercised.
5. **Failure behavior:** an opaque native cursor-chain gap invalidates an earlier gap-free claim. Item/byte startup overflow resets and frees native buffer and staging without publication; separate staging bounds reject atomically.
6. **Admission and exactness:** typed cloud/container/VM selections need no Kubernetes fields. JSON text retains `9007199254740993`, `1.2300e+04`, and `-0`; a float64 control rounds the integer. Representation/schema/scope/provider escapes and typed known-absent contradictions reject the whole ordered changes batch. Canonical decimal sequence controls reject zero, leading zeros, plus, whitespace and uint64 overflow.
7. **Explicit limitation:** a stale remove without surfaced incarnation evidence can erase a recreated host observation while native truth retains it. No generic host revision sorting or recreation repair is fabricated.

## Scenario outcomes

| Scenario | Classification | Enumeration / consistency | Continuity |
| --- | --- | --- | --- |
| strong_native_immutable_cut | simulated_feature_pass | exhausted / pointInTime | gapFree |
| weak_subscribe_list_replay | expected_counterexample_NOT_feature_pass | exhausted / bestEffort | bestEffort |
| partial_snapshot_no_promotion | simulated_feature_pass | partial / bestEffort | bestEffort |
| immutable_generation_replacement | simulated_feature_pass | exhausted / pointInTime | gapFree |
| source_owned_membership | simulated_feature_pass | exhausted / pointInTime | gapFree |
| incarnation_absent_limitation | expected_limitation_NOT_feature_pass | exhausted / bestEffort | bestEffort |
| native_gap_after_handoff | simulated_feature_pass | exhausted / pointInTime | gapFree |
| native_startup_overflow_items | simulated_feature_pass | not published | not established |
| native_startup_overflow_bytes | simulated_feature_pass | not published | not established |
| host_staging_limit_items | simulated_feature_pass | not published | not established |
| host_staging_limit_bytes | simulated_feature_pass | not published | not established |
| empty_finite_snapshot | simulated_feature_pass | exhausted / pointInTime | notApplicable |
| provider_neutral_selection_cloud | simulated_feature_pass | exhausted / pointInTime | notApplicable |
| provider_neutral_selection_container | simulated_feature_pass | exhausted / pointInTime | notApplicable |
| provider_neutral_selection_hypervisor | simulated_feature_pass | exhausted / pointInTime | notApplicable |
| phase_rejection_earlyChanges | simulated_feature_pass | not published | not established |
| phase_rejection_lateSnapshot | simulated_feature_pass | exhausted / pointInTime | gapFree |
| phase_rejection_modeDowngrade | simulated_feature_pass | not published | not established |
| coverage_dimensions_independent | simulated_feature_pass | exhausted / pointInTime | notApplicable |
| atomic_admission_representation | simulated_feature_pass | exhausted / pointInTime | gapFree |
| atomic_admission_schema | simulated_feature_pass | exhausted / pointInTime | gapFree |
| atomic_admission_scope | simulated_feature_pass | exhausted / pointInTime | gapFree |
| atomic_admission_provider | simulated_feature_pass | exhausted / pointInTime | gapFree |
| atomic_admission_knownAbsentNull | simulated_feature_pass | exhausted / pointInTime | gapFree |
| atomic_admission_knownAbsentArray | simulated_feature_pass | exhausted / pointInTime | gapFree |

A recorded published continuity describes the last valid view. Gap/reset or admission rejection sets the host unsynchronized, so it is not an active continuity claim after failure. See each scenario's phase/reset evidence.

## Observed counters and bounds

### strong_native_immutable_cut

```json
{
  "accessContext": "fixture-principal (out of band)",
  "connectionRoute": "fixture-route",
  "generation": "g1",
  "nativeEventsAccepted": 7,
  "nativeHistoryEvents": 7,
  "opaqueNativeCursor": "end?seven",
  "publications": 4,
  "schedule": [
    "capture immutable cut0 and native cursor",
    "stage first page(a)",
    "advance native events1-2 into startup buffer",
    "stage second page(b) from frozen cut0",
    "advance native events3-5 into startup buffer",
    "snapshotEnd publishes cut0",
    "replay ordered native events1-5 in one changes batch",
    "advance events6-7 after boundary"
  ],
  "selection": {
    "provider": "cloud",
    "authority": "account-7",
    "type": "compute.instance",
    "scope": {
      "region": "west"
    },
    "representationId": "instance.detail",
    "schemaId": "instance.v1",
    "schemaRevision": "rev-blue"
  },
  "snapshotCut": "cut0",
  "sourceRevisionsNeverCompared": true,
  "sourceSession": "strong",
  "stagingPeakBytes": 1171,
  "stagingPeakItems": 2,
  "startupMaxBytes": 8192,
  "startupMaxItems": 8,
  "startupPeakBytes": 1944,
  "startupPeakItems": 5,
  "trueOrderOwner": "simulated native cursor API and adapter, not host"
}
```

### native_startup_overflow_items

```json
{
  "maxBytes": 8192,
  "maxItems": 1,
  "peakBytes": 483,
  "peakItems": 1,
  "postResetBufferBytes": 0,
  "postResetBufferItems": 0,
  "postResetStageItems": 0,
  "resetReason": "overflow",
  "terminalFrames": 1
}
```

### native_startup_overflow_bytes

```json
{
  "maxBytes": 1,
  "maxItems": 8,
  "peakBytes": 0,
  "peakItems": 0,
  "postResetBufferBytes": 0,
  "postResetBufferItems": 0,
  "postResetStageItems": 0,
  "resetReason": "overflow",
  "terminalFrames": 1
}
```

### host_staging_limit_items

```json
{
  "admissionBeforeStagingCommit": true,
  "limit": "decoded-object simulation only, NOT pre-allocation wire proof",
  "maxBytes": 16384,
  "maxItems": 1,
  "phase": "invalid",
  "published": 0
}
```

### host_staging_limit_bytes

```json
{
  "admissionBeforeStagingCommit": true,
  "limit": "decoded-object simulation only, NOT pre-allocation wire proof",
  "maxBytes": 1,
  "maxItems": 16,
  "phase": "invalid",
  "published": 0
}
```

## SHA-256 source and fixture identity

- `expected.json`: `3b6a41337ca7da8fd5de89bdd41cb3ce84b25be4fe1153cfb19b23e066a65b28`
- `fixtures.json`: `2518e1112b739342d177a793ef658754183a9b4e6c9b4a7e3f5828d7dc0cd7f1`
- `go.mod`: `d57bf897fac9ca4e2a56c9a1484b2a3abcaf614e8f5a60a7922036c83e361e7a`
- `main.go`: `6ba0b89ae8944242ad1c97fede90ef0b287530d4817c7cb88126941067819634`
- `model.go`: `2a84817172babebf46d0c636ec8ebcd9286ed2e8760da1988165020bd515e736`
- `native.go`: `f4aad4bf13986d1fe0f358a40285714f731c81c4bd4e7c1b4563fbfbb5806e2b`
- `scenarios.go`: `27fea8798549aeca9b1b07577e9c44d426378711a0848757c62a34217cf388af`

## Limits

- Throwaway deterministic native-style simulator and host staging model only; NOT an actual cloud, container, hypervisor or Kubernetes provider, production adapter, SDK binding or real transport.
- Frames undergo in-process JSON marshal/unmarshal only, not IPC/TCP/gRPC/Wails; framing and pre-allocation wire limits, cancellation races, refcounts and real backpressure belong to the separate lifecycle probe.
- The strong fixture assumes native immutable snapshot/cursor-chain semantics; a real provider needs independent evidence for those semantics, cursor expiry and selection/access consistency. Simulator ordinals never reach the host and source revisions are never used to order.
- Weak subscribe/list/replay deliberately remains stale at the bounded controlled horizon. Expected counterexample checks are NOT successful recency/reconciliation feature passes. Later delayed events could heal the state but cannot erase the demonstrated regression.
- Absent-incarnation fixture intentionally withholds known native identity evidence. It demonstrates ambiguity, not a recreation-safe adapter. No UID, global order, synthetic watcher, retry or host repair is invented.
- Expected row states are independently authored in expected.json from native histories. Native truth mutates from fixtures.json independently of source frames; row projections are test diagnostics, NOT a query evaluator or result delivery.
- Source/access provenance is represented by isolated host/session bindings and out-of-band fixture principal labels, not a real authorization system. No cross-credential body merge or multi-source conflict-resolution algorithm is implemented.
- Partial snapshots publish only staged current-generation observations. Unseen old observations stay in a separate explicitly stale cache with original generations; they are not promoted into the current source view. Broader sources remain isolated. This is a private-cache demonstration, not a product stale-data policy/UI.
- Buffer bytes count serialized native packets, and staging bytes count serialized entries. These are deterministic logical bounds, not measured allocator/RSS ceilings or proof against allocating an oversized native callback before admission.
- Exact-scope selection, enumeration, one representation/schema binding and JSON text are exercised. QueryScope any/oneOf normalization (including empty oneOf), nativeQuery capability admission, denied/unsupported opens, SourceError DTOs, EOF/cancellation and coverage-progress-only changes are unexercised here.
- Document admission validates JSON, selected binding and typed present/knownAbsent contradictions. It is not a full schema/type validator, field-level authorization system, projection engine, general source-resume endpoint or durable log.
- No actual concurrency, sleep-based timing evidence, real provider I/O, query-result generation, combined SDK ingestion/evaluation/result integration, UI behavior or performance claim. Explicit step schedules establish only the simulated interleavings.

## Unclosed semantic questions / production prerequisites

- The contract intentionally leaves the product stale-data publication/retention policy open. This probe keeps stale cache entries separate and labels old published views unsynchronized during replacement; consumers are not implemented.
- Native absence of ordering/incarnation evidence cannot distinguish an old delete from a current membership remove. Stronger recency/recreation guarantees are unsupported without native proof; bestEffort is a declaration, not a repair algorithm.
- No generic source-to-source body reconciliation rule is specified. This probe preserves source membership independently rather than silently choosing a global latest observation.
- Exact domain/protobuf mapping, transport/decode accounting and real adapter ordering proofs remain production prerequisites. The simulated cursor chain is not portable sourceRevision ordering or a public resume contract.
