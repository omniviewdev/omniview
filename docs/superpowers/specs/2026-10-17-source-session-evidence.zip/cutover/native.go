package main

import (
	"encoding/json"
	"fmt"
	"sort"
)

type FixtureObject struct { ID string `json:"id"`; State string `json:"state"`; Incarnation string `json:"incarnation"`; Revision string `json:"revision"`; Document string `json:"document"` }
type FixtureStep struct { Kind string `json:"kind"`; Object FixtureObject `json:"object"`; ID string `json:"id"`; Incarnation string `json:"incarnation"`; Revision string `json:"revision"` }
type Profile struct { Profile string `json:"profile"`; Binding Binding `json:"binding"`; Initial []FixtureObject `json:"initial"`; Cursors []string `json:"cursors"`; History []FixtureStep `json:"history"` }
type OpaquePair struct { Older string `json:"older"`; Newer string `json:"newer"`; Reason string `json:"reason"` }
type Fixtures struct { Strong Profile `json:"strong"`; Weak Profile `json:"weak"`; Selections []Binding `json:"selections"`; OpaquePairs []OpaquePair `json:"opaquePairs"`; InvalidSequenceText []string `json:"invalidSequenceText"`; Schedule map[string][]string `json:"schedule"` }
func makeObservation(b Binding, f FixtureObject) Observation {
	o := Observation{Address:Address{b.Provider,b.Authority,b.Type,clone(b.Scope),f.ID}, Document:Document{"json",f.Document}, DocumentCoverage:DocumentCoverage{Kind:"complete"}, Incarnation:f.Incarnation, Revision:f.Revision}
	o.Representation.ID = b.RepresentationID; o.Representation.Schema.ID = b.SchemaID; o.Representation.Schema.Revision = b.SchemaRevision
	if o.Document.Text == "" { data,err := json.Marshal(map[string]string{"state":f.State}); must(err); o.Document.Text = string(data) }
	return o
}
func makeChange(b Binding, f FixtureStep) Change {
	if f.Kind == "upsert" { o := makeObservation(b,f.Object); return Change{Kind:"upsert",Observation:&o} }
	a := Address{b.Provider,b.Authority,b.Type,clone(b.Scope),f.ID}; return Change{Kind:f.Kind,Address:&a,Incarnation:f.Incarnation,Revision:f.Revision}
}
// Native ordinals stay inside this simulator. The adapter only receives the
// source's opaque cursor-chain contract, never an order computed from revisions.
type NativePacket struct { Previous string `json:"previousNativeCursor"`; Cursor string `json:"nativeCursor"`; Change Change `json:"change"` }
type Native struct { profile Profile; ordinal int; truth map[string]Observation; emitted int }
type NativeSnapshot struct { Cursor string; Frozen []Observation; Offset int }
func newNative(p Profile) *Native {
	if len(p.Cursors) != len(p.History)+1 { panic("fixture cursor/history mismatch") }
	seen := map[string]bool{}; for _, c := range p.Cursors { if c == "" || seen[c] { panic("fixture nonunique native cursor") }; seen[c] = true }
	n := &Native{profile:clone(p),truth:map[string]Observation{}}
	for _, f := range p.Initial { n.truth[f.ID] = makeObservation(p.Binding,f) }
	return n
}
func (n *Native) snapshot() *NativeSnapshot {
	ids := make([]string,0,len(n.truth)); for id := range n.truth { ids = append(ids,id) }; sort.Strings(ids)
	s := &NativeSnapshot{Cursor:n.profile.Cursors[n.ordinal],Frozen:make([]Observation,0,len(ids))}
	for _, id := range ids { s.Frozen = append(s.Frozen,clone(n.truth[id])) }; return s
}
func (s *NativeSnapshot) page(size int) []Observation {
	end := s.Offset+size; if end > len(s.Frozen) { end = len(s.Frozen) }; out := clone(s.Frozen[s.Offset:end]); s.Offset = end; return out
}
func (n *Native) advance(deliver func(NativePacket)) {
	if n.ordinal == len(n.profile.History) { panic("fixture history exhausted") }
	step := n.profile.History[n.ordinal]; change := makeChange(n.profile.Binding,step)
	// Truth is updated directly from native history, not materialized from source
	// frames. Conditional remove is the simulator's native incarnation semantics.
	if step.Kind == "upsert" { n.truth[step.Object.ID] = makeObservation(n.profile.Binding,step.Object) } else if step.Kind == "remove" {
		old, exists := n.truth[step.ID]; if exists && (step.Incarnation == "" || old.Incarnation == "" || old.Incarnation == step.Incarnation) { delete(n.truth,step.ID) }
	} else { panic("bad native fixture step") }
	packet := NativePacket{n.profile.Cursors[n.ordinal],n.profile.Cursors[n.ordinal+1],change}; n.ordinal++; n.emitted++
	if deliver != nil { deliver(clone(packet)) }
}
func (n *Native) rows() map[string]string { entries := map[string]Entry{}; for _,o := range n.truth { entries[addressKey(o.Address)] = Entry{Observation:o} }; return stateRows(entries) }

type Recorder struct { Frames []Frame `json:"frames"`; Rejected []string `json:"rejected"` }
type Emitter struct { Host *Host; Recorder *Recorder; Sequence uint64 }
func newEmitter(h *Host, r *Recorder) *Emitter { return &Emitter{Host:h,Recorder:r} }
func (e *Emitter) emit(p Payload) error {
	e.Sequence++
	f := Frame{e.Host.Session,e.Host.Generation,fmt.Sprint(e.Sequence),p}
	// Exercise the JSON text DTO boundary: the document is a string, not Struct
	// or an implicit float64 body. This is an in-process roundtrip, not transport.
	wire,err := json.Marshal(f); if err != nil { return err }; var received Frame; if err = json.Unmarshal(wire,&received); err != nil { return err }
	e.Recorder.Frames = append(e.Recorder.Frames,received)
	err = e.Host.Apply(received); if err != nil { e.Recorder.Rejected = append(e.Recorder.Rejected,err.Error()) }; return err
}
type Adapter struct {
	Out *Emitter
	Cursor string
	Following, Terminal bool
	Buffer []NativePacket
	BufferBytes int
	MaxItems, MaxBytes int
	PeakItems, PeakBytes, Resets, AcceptedNative int
	ResetReason string
}
func newAdapter(e *Emitter, cursor string, maxItems, maxBytes int) *Adapter { return &Adapter{Out:e,Cursor:cursor,MaxItems:maxItems,MaxBytes:maxBytes} }
func (a *Adapter) begin() { must(a.Out.emit(Payload{Kind:"begin",Mode:a.Out.Host.Mode})) }
func (a *Adapter) page(rows []Observation) { if !a.Terminal { must(a.Out.emit(Payload{Kind:"snapshot",Observations:rows})) } }
func (a *Adapter) reset(reason string) {
	if a.Terminal { return }; a.Terminal = true; a.Buffer = nil; a.BufferBytes = 0; a.Resets++; a.ResetReason = reason
	must(a.Out.emit(Payload{Kind:"reset",Reason:reason}))
}
func (a *Adapter) observe(p NativePacket) {
	if a.Terminal { return }
	if p.Previous != a.Cursor { a.reset("continuityLost"); return }
	if !a.Following || len(a.Buffer) > 0 {
		data,err := json.Marshal(p); must(err)
		if len(a.Buffer)+1 > a.MaxItems || a.BufferBytes+len(data) > a.MaxBytes { a.reset("overflow"); return }
		a.Buffer = append(a.Buffer,clone(p)); a.BufferBytes += len(data)
		if len(a.Buffer) > a.PeakItems { a.PeakItems = len(a.Buffer) }; if a.BufferBytes > a.PeakBytes { a.PeakBytes = a.BufferBytes }
	} else { must(a.Out.emit(Payload{Kind:"changes",Changes:[]Change{p.Change}})) }
	a.Cursor = p.Cursor; a.AcceptedNative++
}
func (a *Adapter) end() {
	if a.Terminal { return }
	cov := Coverage{"exhausted","pointInTime",[]string{"native immutable cut and native cursor chain simulated, not external-provider proof"}}
	must(a.Out.emit(Payload{Kind:"snapshotEnd",Coverage:&cov,Continuity:"gapFree"}))
	a.Following = true
}
func (a *Adapter) drain() {
	if a.Terminal || !a.Following { return }
	if len(a.Buffer) != 0 { changes := make([]Change,0,len(a.Buffer)); for _, p := range a.Buffer { changes = append(changes,p.Change) }; must(a.Out.emit(Payload{Kind:"changes",Changes:changes})) }
	a.Buffer = nil; a.BufferBytes = 0
}
