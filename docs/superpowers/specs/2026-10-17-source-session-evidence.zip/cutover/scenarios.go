package main

import (
	"encoding/json"
	"fmt"
	"reflect"
	"strconv"
)

type Check struct { Name string `json:"name"`; Expected any `json:"expected"`; Actual any `json:"actual"`; Passed bool `json:"passed"` }
type Scenario struct { Name string `json:"name"`; Classification string `json:"classification"`; Coverage *Coverage `json:"coverage,omitempty"`; Continuity string `json:"continuity,omitempty"`; Evidence map[string]any `json:"evidence"` }
type Run struct {
	Fixtures Fixtures
	Expected map[string]map[string]string
	Checks []Check
	Scenarios []Scenario
	Frames map[string]*Recorder
	Actual map[string]any
}
func must(err error) { if err != nil { panic(err) } }
func (r *Run) check(name string, expected, actual any) { r.Checks = append(r.Checks,Check{name,expected,actual,reflect.DeepEqual(expected,actual)}) }
func (r *Run) rows(name string, actual map[string]string) {
	expected, ok := r.Expected[name]; if !ok { panic("missing independent expectation: "+name) }
	r.check(name,expected,actual); r.Actual[name] = clone(actual)
}
func (r *Run) pair(name string, b Binding, mode string) (*Host,*Emitter) {
	h := newHost(b,name,"g1",mode); rec := &Recorder{Frames:[]Frame{},Rejected:[]string{}}; r.Frames[name] = rec; return h,newEmitter(h,rec)
}
func (r *Run) scenario(name, classification string, h *Host, evidence map[string]any) {
	s := Scenario{Name:name,Classification:classification,Evidence:evidence}
	if h != nil && h.Published != nil { cov := clone(h.Published.Coverage); s.Coverage = &cov; s.Continuity = h.Published.Continuity }
	r.Scenarios = append(r.Scenarios,s)
}
func observations(b Binding, fs ...FixtureObject) []Observation { out := make([]Observation,0,len(fs)); for _,f := range fs { out = append(out,makeObservation(b,f)) }; return out }
func upsert(o Observation) Change { return Change{Kind:"upsert",Observation:&o} }
func removal(o Observation, inc string) Change { a := clone(o.Address); return Change{Kind:"remove",Address:&a,Incarnation:inc,Revision:"native/delete-opaque"} }
func startSnapshot(e *Emitter, obs []Observation, cov Coverage, continuity string) {
	must(e.emit(Payload{Kind:"begin",Mode:e.Host.Mode})); if len(obs)>0 { must(e.emit(Payload{Kind:"snapshot",Observations:obs})) }; must(e.emit(Payload{Kind:"snapshotEnd",Coverage:&cov,Continuity:continuity}))
}
func fullCoverage() Coverage { return Coverage{"exhausted","pointInTime",[]string{}} }
func (r *Run) strong() {
	p := r.Fixtures.Strong; n := newNative(p); snap := n.snapshot(); r.rows("strong.native.cut0",n.rows())
	h,e := r.pair("strong",p.Binding,"snapshotAndUpdates"); a := newAdapter(e,snap.Cursor,8,8192); a.begin(); a.page(snap.page(1))
	n.advance(a.observe); n.advance(a.observe)
	a.page(snap.page(1))
	for range 3 { n.advance(a.observe) }
	r.rows("strong.host.beforeEnd",h.rows()); r.check("strong.no-publication-before-boundary",0,h.Publications)
	r.check("strong.native-buffer-has-five-ordered-events",5,len(a.Buffer))
	r.check("strong.frozen-second-page-is-original-b","to-remove|b1",stateRows(h.Stage)["b"])
	for _, f := range e.Recorder.Frames { r.check("strong.no-early-changes.seq"+f.Sequence,false,f.Payload.Kind=="changes") }
	a.end(); r.rows("strong.host.atEnd",h.rows()); saved := h.Published; savedRows := h.rows()
	r.check("strong.publish-once-at-boundary",1,h.Publications)
	for _,entry := range h.Published.Members { if entry.Observation.Address.ID=="a" { r.jsonControl(entry.Observation.Document.Text,p.Initial[0].Document) } }
	a.drain(); r.rows("strong.native.after5",n.rows()); r.rows("strong.host.after5",h.rows())
	r.check("strong.one-batch-one-publication",2,h.Publications); r.check("strong.initial-view-is-immutable",savedRows,stateRows(saved.Members))
	n.advance(a.observe); r.rows("strong.native.afterStaleRemove",n.rows()); r.rows("strong.host.afterStaleRemove",h.rows()); r.check("strong.known-incarnation-stale-remove-ignored",1,h.IgnoredIncarnation)
	n.advance(a.observe); r.rows("strong.native.final",n.rows()); r.rows("strong.host.final",h.rows())
	r.check("strong.independent-native-host-equality",n.rows(),h.rows()); r.check("strong.drained-native-buffer-items",0,len(a.Buffer)); r.check("strong.drained-native-buffer-bytes",0,a.BufferBytes)
	r.scenario("strong_native_immutable_cut","simulated_feature_pass",h,map[string]any{"nativeHistoryEvents":n.emitted,"nativeEventsAccepted":a.AcceptedNative,"startupPeakItems":a.PeakItems,"startupPeakBytes":a.PeakBytes,"startupMaxItems":a.MaxItems,"startupMaxBytes":a.MaxBytes,"stagingPeakItems":h.StagePeakItems,"stagingPeakBytes":h.StagePeakBytes,"publications":h.Publications,"opaqueNativeCursor":a.Cursor,"sourceRevisionsNeverCompared":true,"snapshotCut":"cut0","accessContext":"fixture-principal (out of band)","connectionRoute":"fixture-route","selection":h.Binding,"sourceSession":h.Session,"generation":h.Generation,"schedule":r.Fixtures.Schedule["strong"],"trueOrderOwner":"simulated native cursor API and adapter, not host"})
}
func (r *Run) jsonControl(received, original string) {
	r.check("json.original-document-text-preserved",original,received)
	var rounded map[string]any; must(json.Unmarshal([]byte(original),&rounded))
	defaultInteger := strconv.FormatFloat(rounded["exact"].(float64),'f',0,64)
	var exact map[string]json.RawMessage; must(json.Unmarshal([]byte(received),&exact))
	r.check("json.float64-control-rounds-unsafe-integer","9007199254740992",defaultInteger)
	r.check("json.raw-exact-integer-lexeme","9007199254740993",string(exact["exact"]))
	r.check("json.raw-exponent-and-trailing-zeros","1.2300e+04",string(exact["scaled"]))
	r.check("json.raw-negative-zero","-0",string(exact["negativeZero"]))
	r.Actual["json.numericControl"] = map[string]any{"sourceText":original,"receivedText":received,"defaultFloat64Integer":defaultInteger,"exactInteger":string(exact["exact"]),"scaledLexeme":string(exact["scaled"]),"negativeZeroLexeme":string(exact["negativeZero"])}
}
func (r *Run) weak() {
	p := r.Fixtures.Weak; n := newNative(p); h,e := r.pair("weak_naive",p.Binding,"snapshotAndUpdates")
	must(e.emit(Payload{Kind:"begin",Mode:h.Mode})); buffer := []Change{}
	n.advance(func(packet NativePacket) { buffer = append(buffer,packet.Change) })
	n.advance(nil); n.advance(nil) // Native callbacks for these commits are delayed beyond this controlled horizon.
	page := n.snapshot(); must(e.emit(Payload{Kind:"snapshot",Observations:page.page(1)})); must(e.emit(Payload{Kind:"snapshot",Observations:page.page(1)}))
	cov := Coverage{"exhausted","bestEffort",[]string{"mutable paginated enumeration; callbacks may predate page values or be delayed; no native handoff order"}}
	must(e.emit(Payload{Kind:"snapshotEnd",Coverage:&cov,Continuity:"bestEffort"})); r.rows("weak.native.page",n.rows()); r.rows("weak.host.page",h.rows())
	must(e.emit(Payload{Kind:"changes",Changes:buffer})); r.rows("weak.host.afterOldReplay",h.rows())
	n.advance(func(packet NativePacket) { must(e.emit(Payload{Kind:"changes",Changes:[]Change{packet.Change}})) })
	r.rows("weak.native.final",n.rows()); r.rows("weak.host.knownBrokenFinal",h.rows())
	r.check("weak.known-broken-naive-adapter-does-not-match-truth",false,reflect.DeepEqual(n.rows(),h.rows()))
	contiguous := true; for i,f := range e.Recorder.Frames { if f.Sequence != fmt.Sprint(i+1) { contiguous=false } }
	r.check("weak.contiguous-source-sequences-cannot-prove-recency",true,contiguous)
	r.check("weak.no-fabricated-gap-free","bestEffort",h.Published.Continuity)
	r.scenario("weak_subscribe_list_replay","expected_counterexample_NOT_feature_pass",h,map[string]any{"nativeTruth":n.rows(),"knownBrokenNaiveAdapter":h.rows(),"contiguousSourceFrames":contiguous,"bufferedOldRevision":"9","newerPageRevision":"10","delayedNativeCallbacks":2,"nativeHistoryEvents":n.emitted,"snapshotEnumeration":"exhausted relative to pages, not a consistent instant","hostRepairedOpaqueOrder":false,"horizon":"after callback1 replay and callback4 removal, before callbacks2-3","schedule":r.Fixtures.Schedule["weak"],"conclusion":"bestEffort permits honest limitation reporting; it does not repair this stale overwrite"})
}
func (r *Run) replacementAndMembership() {
	b := r.Fixtures.Strong.Binding; old := observations(b,FixtureObject{ID:"a",State:"old-generation",Incarnation:"a1"},FixtureObject{ID:"b",State:"old-cache",Incarnation:"b1"})
	h,e := r.pair("replacement",b,"snapshotAndUpdates"); startSnapshot(e,old,fullCoverage(),"gapFree"); saved := h.Published
	h.Open("g2","snapshotAndUpdates"); e.Sequence=0
	must(e.emit(Payload{Kind:"begin",Mode:h.Mode})); partial := observations(b,FixtureObject{ID:"a",State:"partial-current",Incarnation:"a1"}); must(e.emit(Payload{Kind:"snapshot",Observations:partial}))
	r.rows("replacement.stagingKeepsOld",h.rows()); r.check("replacement.old-view-labeled-unsynchronized",false,h.Synchronized)
	cov := Coverage{"partial","bestEffort",[]string{"bounded subset; omitted old members remain stale cache, not new-generation source observations"}}
	must(e.emit(Payload{Kind:"snapshotEnd",Coverage:&cov,Continuity:"bestEffort"})); r.rows("partial.current",h.rows()); r.rows("partial.staleCache",h.staleRows())
	for _,v := range h.Published.Members { r.check("partial.current-observed-generation","g2",v.Generation) }; for _,v := range h.StaleCache { r.check("partial.retained-old-generation-not-promoted","g1",v.Generation) }
	r.scenario("partial_snapshot_no_promotion","simulated_feature_pass",h,map[string]any{"currentGenerationRows":h.rows(),"separateStaleCacheRows":h.staleRows(),"staleGeneration":"g1","currentGeneration":"g2","oldPublishedViewRetainedDuringStagingOnly":true,"broaderCacheDeletionClaim":false})
	partialView := h.Published
	h.Open("g3","snapshotAndUpdates"); e.Sequence=0; fresh := observations(b,FixtureObject{ID:"c",State:"new-generation",Incarnation:"c1"}); startSnapshot(e,fresh,fullCoverage(),"gapFree")
	r.rows("replacement.newCurrent",h.rows()); r.rows("replacement.savedOldView",stateRows(saved.Members)); r.check("replacement.partial-view-immutable",r.Expected["partial.current"],stateRows(partialView.Members)); r.check("replacement.exhausted-replacement-retires-stale-cache",0,len(h.StaleCache))
	before := h.Published; late := Frame{Session:h.Session,Generation:"g2",Sequence:"9",Payload:Payload{Kind:"changes",Changes:[]Change{upsert(old[0])}}}; err := h.Apply(late)
	r.check("replacement.late-old-generation-rejected",true,err!=nil); r.check("replacement.late-generation-keeps-pointer",true,before==h.Published); r.check("replacement.late-generation-keeps-synchronized",true,h.Synchronized)
	r.scenario("immutable_generation_replacement","simulated_feature_pass",h,map[string]any{"oldViewUnmodified":stateRows(saved.Members),"newView":h.rows(),"ignoredOldGenerationFrames":h.IgnoredStale,"noStageOldMix":true})
	a,ea := r.pair("membershipA",b,"snapshotAndUpdates"); other,eb := r.pair("membershipB",b,"snapshotAndUpdates"); shared := observations(b,FixtureObject{ID:"a",State:"shared",Incarnation:"a1"}); startSnapshot(ea,shared,fullCoverage(),"gapFree"); startSnapshot(eb,shared,fullCoverage(),"gapFree")
	must(ea.emit(Payload{Kind:"changes",Changes:[]Change{removal(shared[0],"a1")}})); r.rows("membership.sourceA.afterRemove",a.rows()); r.rows("membership.sourceB.unaffected",other.rows())
	r.scenario("source_owned_membership","simulated_feature_pass",a,map[string]any{"sourceA":map[string]any{"session":a.Session,"accessContext":"principal-red","rows":a.rows()},"sourceB":map[string]any{"session":other.Session,"accessContext":"principal-blue","rows":other.rows()},"broaderMaterialization":map[string]string{"sourceB":"a still retained"},"crossCredentialBodyMerge":false,"removeMeans":"source A membership only, no global object destruction"})
}
func (r *Run) incarnationLimit() {
	b := r.Fixtures.Strong.Binding
	profile := Profile{Binding:b,Initial:[]FixtureObject{{ID:"a",State:"recreated",Incarnation:"a2",Revision:"new"}},Cursors:[]string{"native-cut","native-late"},History:[]FixtureStep{{Kind:"remove",ID:"a",Incarnation:"a1",Revision:"old-delete"}}}
	n := newNative(profile); full := n.snapshot().page(1)
	known,ek := r.pair("incarnation_known",b,"snapshotAndUpdates"); startSnapshot(ek,full,fullCoverage(),"gapFree")
	absent,ea := r.pair("incarnation_absent",b,"snapshotAndUpdates"); stripped := clone(full); stripped[0].Incarnation=""
	cov := Coverage{"exhausted","bestEffort",[]string{"native incarnation/order evidence not exposed; stale delete indistinguishable from current membership remove"}}; startSnapshot(ea,stripped,cov,"bestEffort")
	n.advance(func(packet NativePacket) { must(ek.emit(Payload{Kind:"changes",Changes:[]Change{packet.Change}})); weak := clone(packet.Change); weak.Incarnation=""; must(ea.emit(Payload{Kind:"changes",Changes:[]Change{weak}})) })
	r.rows("incarnation.knownProtected",known.rows()); r.rows("incarnation.absentHost",absent.rows()); r.rows("incarnation.absentNative",n.rows())
	r.check("incarnation.no-invention-of-recreation-safety",false,reflect.DeepEqual(n.rows(),absent.rows()))
	r.scenario("incarnation_absent_limitation","expected_limitation_NOT_feature_pass",absent,map[string]any{"nativeTruth":n.rows(),"hostWithoutNativeIncarnation":absent.rows(),"knownIncarnationProtected":known.rows(),"conclusion":"optional incarnation alone cannot provide recreation safety when absent; native adapter must supply ordering/reconciliation or declare limitation"})
}
func (r *Run) gapsAndBounds() {
	p := r.Fixtures.Strong
	n := newNative(p); s := n.snapshot(); h,e := r.pair("native_gap",p.Binding,"snapshotAndUpdates"); a := newAdapter(e,s.Cursor,8,8192); a.begin(); a.page(s.page(8)); a.end(); a.drain()
	n.advance(nil); n.advance(a.observe); r.rows("gap.lastPublished",h.rows()); r.check("gap.reset-continuity-lost","continuityLost",a.ResetReason); r.check("gap.invalidates-earlier-gap-free",false,h.Synchronized); r.check("gap.terminal-phase","reset",h.Phase)
	r.scenario("native_gap_after_handoff","simulated_feature_pass",h,map[string]any{"resetReason":a.ResetReason,"sourceSynchronized":h.Synchronized,"lastPublishedOnlyStale":true,"nativeEventsDroppedDeliberately":1,"sourceFrameSequenceStillContiguous":true,"nativeCursorChainDetectedGap":true})
	for _, bound := range []string{"items","bytes"} {
		n := newNative(p); s := n.snapshot(); h,e := r.pair("overflow_"+bound,p.Binding,"snapshotAndUpdates")
		maxItems,maxBytes := 1,8192; if bound=="bytes" { maxItems,maxBytes=8,1 }
		a := newAdapter(e,s.Cursor,maxItems,maxBytes); a.begin(); a.page(s.page(1)); n.advance(a.observe); if bound=="items" { n.advance(a.observe) }
		r.rows("overflow.current",h.rows()); r.check("overflow."+bound+".reset","overflow",a.ResetReason); r.check("overflow."+bound+".buffer-freed",0,len(a.Buffer)); r.check("overflow."+bound+".bytes-freed",0,a.BufferBytes); r.check("overflow."+bound+".stage-freed",true,h.Stage==nil); r.check("overflow."+bound+".no-publish",0,h.Publications)
		r.scenario("native_startup_overflow_"+bound,"simulated_feature_pass",h,map[string]any{"maxItems":maxItems,"maxBytes":maxBytes,"peakItems":a.PeakItems,"peakBytes":a.PeakBytes,"resetReason":a.ResetReason,"postResetBufferItems":len(a.Buffer),"postResetBufferBytes":a.BufferBytes,"postResetStageItems":len(h.Stage),"terminalFrames":a.Resets})
	}
	for _, bound := range []string{"items","bytes"} {
		h,e := r.pair("stage_limit_"+bound,p.Binding,"snapshotAndUpdates"); if bound=="items" { h.MaxStageItems=1 } else { h.MaxStageBytes=1 }
		must(e.emit(Payload{Kind:"begin",Mode:h.Mode})); obs := observations(p.Binding,p.Initial...); err := e.emit(Payload{Kind:"snapshot",Observations:obs})
		r.check("stage-limit."+bound+".rejects",true,err!=nil); r.check("stage-limit."+bound+".no-publish",0,h.Publications); r.check("stage-limit."+bound+".releases-stage",true,h.Stage==nil)
		r.scenario("host_staging_limit_"+bound,"simulated_feature_pass",h,map[string]any{"maxItems":h.MaxStageItems,"maxBytes":h.MaxStageBytes,"published":h.Publications,"phase":h.Phase,"admissionBeforeStagingCommit":true,"limit":"decoded-object simulation only, NOT pre-allocation wire proof"})
	}
}
func (r *Run) phasesAndSelection() {
	b := r.Fixtures.Strong.Binding
	h,e := r.pair("empty_snapshot",b,"snapshot"); startSnapshot(e,nil,fullCoverage(),"notApplicable"); r.rows("empty.current",h.rows()); r.check("empty.snapshot-successful-terminal","finished",h.Phase); r.check("empty.only-begin-and-end",2,len(e.Recorder.Frames)); r.scenario("empty_finite_snapshot","simulated_feature_pass",h,map[string]any{"frames":len(e.Recorder.Frames),"watcherRequired":false})
	for _,b := range r.Fixtures.Selections {
		h,e := r.pair("selection_"+b.Provider,b,"snapshot"); obs := observations(b,FixtureObject{ID:"same-native-id",State:b.Provider,Incarnation:"i1"}); startSnapshot(e,obs,fullCoverage(),"notApplicable"); r.rows("selection."+b.Provider,h.rows()); r.check("selection."+b.Provider+".exact-scope",b.Scope,obs[0].Address.Scope)
		r.scenario("provider_neutral_selection_"+b.Provider,"simulated_feature_pass",h,map[string]any{"binding":b,"noKubernetesFieldsRequired":true,"typedIdentityKey":addressKey(obs[0].Address),"observedGeneration":h.Generation})
	}
	for _,s := range r.Fixtures.InvalidSequenceText {
		h,_ := r.pair("sequence_"+strconv.Quote(s),b,"snapshot"); err := h.Apply(Frame{Session:h.Session,Generation:h.Generation,Sequence:s,Payload:Payload{Kind:"begin",Mode:"snapshot"}}); r.check("sequence.reject-"+strconv.Quote(s),true,err!=nil); r.check("sequence.no-publication-"+strconv.Quote(s),0,h.Publications)
	}
	max := "18446744073709551615"; parsed,err := strconv.ParseUint(max,10,64); r.check("sequence.uint64-max-parses-without-float",true,err==nil && strconv.FormatUint(parsed,10)==max)
	for _,kind := range []string{"earlyChanges","lateSnapshot","modeDowngrade"} {
		h,e := r.pair("phase_"+kind,b,"snapshotAndUpdates"); obs := observations(b,FixtureObject{ID:"a",State:"safe",Incarnation:"a1"}); var err error
		if kind=="modeDowngrade" { err=e.emit(Payload{Kind:"begin",Mode:"snapshot"}) } else if kind=="earlyChanges" { must(e.emit(Payload{Kind:"begin",Mode:h.Mode})); err=e.emit(Payload{Kind:"changes",Changes:[]Change{upsert(obs[0])}}) } else { startSnapshot(e,obs,fullCoverage(),"gapFree"); before:=h.Published; old:=observations(b,FixtureObject{ID:"a",State:"older-page",Incarnation:"a1"}); err=e.emit(Payload{Kind:"snapshot",Observations:old}); r.check("phase.late-older-page-does-not-mutate-view",true,before==h.Published); r.check("phase.late-older-page-does-not-overwrite","safe|a1",h.rows()["a"]) }
		r.check("phase."+kind+".rejected",true,err!=nil); r.check("phase."+kind+".unsynchronized",false,h.Synchronized)
		r.scenario("phase_rejection_"+kind,"simulated_feature_pass",h,map[string]any{"phase":h.Phase,"publications":h.Publications,"error":fmt.Sprint(err)})
	}
	for i,pair := range r.Fixtures.OpaquePairs {
		lexWrong := pair.Older > pair.Newer; oldNum,errOld:=strconv.ParseUint(pair.Older,10,64); newNum,errNew:=strconv.ParseUint(pair.Newer,10,64)
		if i<2 { r.check(fmt.Sprint("opaque.lexical-counterexample.",i),true,lexWrong) }; if i==1 { r.check("opaque.noninteger-tokens-cannot-sort-numerically",true,errOld!=nil && errNew!=nil) }; if i==2 { r.check("opaque.numeric-counterexample",true,errOld==nil && errNew==nil && oldNum>newNum) }
		r.Actual[fmt.Sprint("opaque.pair.",i)] = map[string]any{"older":pair.Older,"newer":pair.Newer,"trueNativeOrder":"older then newer (fixture-defined)","lexicalWouldChooseOlder":lexWrong,"numericParsingPossible":errOld==nil && errNew==nil,"reason":pair.Reason}
	}
}
func (r *Run) coverageAndBinding() {
	b := r.Fixtures.Strong.Binding; object := FixtureObject{ID:"a",State:"partial-fields",Incarnation:"a1",Document:"{\"state\":\"partial-fields\",\"labels\":{\"a.b\":null},\"items\":[{\"x\":1}]}"}; obs:=makeObservation(b,object)
	obs.DocumentCoverage = DocumentCoverage{Kind:"partial",KnownAbsent:[][]Segment{{{Kind:"member",Name:"labels"},{Kind:"member",Name:"missing"}},{{Kind:"member",Name:"items"},{Kind:"index",Index:1},{Kind:"member",Name:"x"}}}}
	h,e := r.pair("partial_document",b,"snapshot"); startSnapshot(e,[]Observation{obs},fullCoverage(),"notApplicable"); r.rows("coverage.partialDocument",h.rows()); r.check("coverage.source-exhausted-document-still-partial","partial",obs.DocumentCoverage.Kind)
	r.scenario("coverage_dimensions_independent","simulated_feature_pass",h,map[string]any{"sourceEnumeration":h.Published.Coverage.Enumeration,"sourceConsistency":h.Published.Coverage.Consistency,"documentCoverage":obs.DocumentCoverage,"documentText":obs.Document.Text,"continuity":h.Published.Continuity,"missingFieldIsNotDeclaredAbsentUnlessCovered":true})
	for _,bad := range []string{"representation","schema","scope","provider","knownAbsentNull","knownAbsentArray"} {
		h,e := r.pair("admission_"+bad,b,"snapshotAndUpdates"); safe:=makeObservation(b,FixtureObject{ID:"a",State:"safe",Incarnation:"a1"}); startSnapshot(e,[]Observation{safe},fullCoverage(),"gapFree"); first:=clone(safe); first.Document.Text="{\"state\":\"unsafe-first-operation\"}"; invalid:=clone(obs)
		switch bad { case "representation": invalid.Representation.ID="other"; case "schema": invalid.Representation.Schema.Revision="other"; case "scope": invalid.Address.Scope["region"]="east"; case "provider": invalid.Address.Provider="other"; case "knownAbsentNull": invalid.DocumentCoverage.KnownAbsent=[][]Segment{{{Kind:"member",Name:"labels"},{Kind:"member",Name:"a.b"}}}; case "knownAbsentArray": invalid.DocumentCoverage.KnownAbsent=[][]Segment{{{Kind:"member",Name:"items"},{Kind:"index",Index:0},{Kind:"member",Name:"x"}}} }
		before:=h.Published; err:=e.emit(Payload{Kind:"changes",Changes:[]Change{upsert(first),upsert(invalid)}})
		r.check("admission."+bad+".reject",true,err!=nil); r.rows("binding.rollback",h.rows()); r.check("admission."+bad+".batch-atomic-no-pointer-change",true,before==h.Published); r.check("admission."+bad+".no-partial-publication",1,h.Publications)
		r.scenario("atomic_admission_"+bad,"simulated_feature_pass",h,map[string]any{"error":fmt.Sprint(err),"currentRows":h.rows(),"publications":h.Publications,"coverageContradictionOrBindingFailure":bad,"previousRowsNowOnlyLabeledStale":!h.Synchronized})
	}
}
func (r *Run) execute() { r.strong(); r.weak(); r.replacementAndMembership(); r.incarnationLimit(); r.gapsAndBounds(); r.phasesAndSelection(); r.coverageAndBinding() }
