# Source lifecycle/flow confirmation probe

Reproduce exactly:

```sh
cd /tmp/omniview-source-confirm.nmPjpd/lifecycle && GOWORK=off go run .
```

Observed Go: `go1.26.1`; platform `darwin/arm64`. Standard library only.

Result: **true**, 57 cases, 1415 assertions, 0 unexpected failures. This is feasibility evidence, not product implementation.

## Artifacts and transport

`scenarios.json` is the canonical input/expected fixture manifest; `wire-inputs.json` records actual serialized payload text, prefix hex, queue admission and native generation for every attempted wire packet. `results.json` contains per-case expected/actual values, exact queue/staging/transport counters, native loopback endpoints, cleanup counters, assertions, source SHA-256 hashes and limitations. `main.go`, `probe.go`, and `go.mod` are the complete runnable source/module. Re-running overwrites actual results; any prior unexpected semantic failure is preserved as `initial-failed-results.json`.

The native endpoints here are OS-allocated TCP addresses on `127.0.0.1`, not real provider endpoints. Each case records its actual listener/provider/host addresses. Core admission, phase, sequence, size, EOF, queue-overflow, reset/reopen and stale-frame cases cross real serialized sockets. Cancel-before/pending-open cases establish sockets but deliberately never start a reader.

## Limits

- `byteOverflowCaseQueueBytes`: 2048
- `maxBatchItems`: 4
- `prefixBytes`: 4
- `processSafetyDeadlineSeconds`: 90
- `retainedSerializedObservationBytes`: 8192
- `retainedSourceCacheItems`: 8
- `socketSafetyDeadlineSeconds`: 5
- `stagedItems`: 4
- `stagedSerializedObservationBytes`: 3072
- `uncompressedFramePayloadBytes`: 8192
- `writerQueueBytesIncludingInFlight`: 16384
- `writerQueueItemsIncludingInFlight`: 2

## Exact observed aggregate measurements

- `cleanup_socketEndpointsClosedTotal`: 116
- `lateCallbacksRejectedTotal`: 2
- `lateFramesRejectedTotal`: 1
- `maxAllocatedPayload`: 2499
- `overflowCountTotal`: 2
- `payloadAllocatedBytesTotal`: 48896
- `payloadAllocationsTotal`: 118
- `queuePeakBytes`: 2503
- `queuePeakItems`: 2
- `readerStartsTotal`: 56
- `stagePeakBytes`: 2157
- `stagePeakItems`: 4
- `wireFramesTotal`: 117
- `writerStartsTotal`: 56

Each queue peak counts both queued and in-flight packets. Item saturation and byte saturation have separate scheduled cases. The byte peak is serialized transport bytes, not Go heap memory. Every case asserts final interests/reservations/handles/readers/writers/queue/staging/retained source cache are zero after final release; published outcomes are captured before releasing finite/shared state. Separate local cache/current maps prevent partial coverage from promoting stale rows.

## Cases

| Case | Classification | Expected terminal | Actual terminal | Pass |
| --- | --- | --- | --- | --- |
| finite_snapshot_success | expected-feature | finished | finished | true |
| finite_empty_snapshot | expected-feature | finished | finished | true |
| updates_boundary_ordered_batch_and_incarnation | expected-rejection-or-continuity-invalidation | reset:continuityLost | reset:continuityLost | true |
| updates_partial_coverage_progress | expected-rejection-or-continuity-invalidation | reset:sourceInvalidated | reset:sourceInvalidated | true |
| changes_before_snapshot_end | expected-rejection-or-continuity-invalidation | reset:bad-phase | reset:bad-phase | true |
| snapshot_after_updates_boundary | expected-rejection-or-continuity-invalidation | reset:bad-phase | reset:bad-phase | true |
| frame_after_finite_completion | expected-rejection-or-continuity-invalidation | reset:bad-phase | reset:bad-phase | true |
| missing_begin | expected-rejection-or-continuity-invalidation | reset:bad-phase | reset:bad-phase | true |
| duplicate_begin | expected-rejection-or-continuity-invalidation | reset:bad-phase | reset:bad-phase | true |
| sequence_gap | expected-rejection-or-continuity-invalidation | reset:sequence-gap | reset:sequence-gap | true |
| sequence_duplicate | expected-rejection-or-continuity-invalidation | reset:sequence-gap | reset:sequence-gap | true |
| sequence_overflow_text | expected-rejection-or-continuity-invalidation | reset:invalid-sequence | reset:invalid-sequence | true |
| sequence_leading_zero | expected-rejection-or-continuity-invalidation | reset:invalid-sequence | reset:invalid-sequence | true |
| sequence_plus_sign | expected-rejection-or-continuity-invalidation | reset:invalid-sequence | reset:invalid-sequence | true |
| sequence_whitespace | expected-rejection-or-continuity-invalidation | reset:invalid-sequence | reset:invalid-sequence | true |
| sequence_negative | expected-rejection-or-continuity-invalidation | reset:invalid-sequence | reset:invalid-sequence | true |
| sequence_zero | expected-rejection-or-continuity-invalidation | reset:sequence-gap | reset:sequence-gap | true |
| sequence_max_without_contiguous_history | expected-rejection-or-continuity-invalidation | reset:sequence-gap | reset:sequence-gap | true |
| wrong_session | expected-rejection-or-continuity-invalidation | reset:wrong-session | reset:wrong-session | true |
| wrong_mode_no_downgrade | expected-rejection-or-continuity-invalidation | reset:wrong-mode | reset:wrong-mode | true |
| wrong_generation_on_stream | expected-rejection-or-continuity-invalidation | reset:wrong-generation | reset:wrong-generation | true |
| wrong_address_authority | expected-rejection-or-continuity-invalidation | reset:binding | reset:binding | true |
| wrong_address_provider | expected-rejection-or-continuity-invalidation | reset:binding | reset:binding | true |
| wrong_address_type | expected-rejection-or-continuity-invalidation | reset:binding | reset:binding | true |
| scope_escape | expected-rejection-or-continuity-invalidation | reset:binding | reset:binding | true |
| wrong_representation | expected-rejection-or-continuity-invalidation | reset:binding | reset:binding | true |
| wrong_schema_revision | expected-rejection-or-continuity-invalidation | reset:binding | reset:binding | true |
| invalid_document_json | expected-rejection-or-continuity-invalidation | reset:invalid-document | reset:invalid-document | true |
| snapshot_continuity_mismatch | expected-rejection-or-continuity-invalidation | reset:invalid-continuity | reset:invalid-continuity | true |
| updates_continuity_mismatch | expected-rejection-or-continuity-invalidation | reset:invalid-continuity | reset:invalid-continuity | true |
| partial_snapshot_no_phantom_deletion_or_promotion | expected-feature | finished | finished | true |
| complete_bound_replacement_retires_old_membership | expected-feature | finished | finished | true |
| batch_item_limit | expected-rejection-or-continuity-invalidation | reset:batch-limit | reset:batch-limit | true |
| staging_item_limit | expected-rejection-or-continuity-invalidation | reset:staging-items | reset:staging-items | true |
| staging_byte_limit | expected-rejection-or-continuity-invalidation | reset:staging-bytes | reset:staging-bytes | true |
| changes_atomic_admission | expected-rejection-or-continuity-invalidation | reset:binding | reset:binding | true |
| failed_payload_terminal | expected-rejection-or-continuity-invalidation | failed:unavailable | failed:unavailable | true |
| explicit_overflow_reset | expected-rejection-or-continuity-invalidation | reset:overflow | reset:overflow | true |
| eof_before_begin | expected-rejection-or-continuity-invalidation | reset:unexpected-eof | reset:unexpected-eof | true |
| eof_before_snapshot_completion | expected-rejection-or-continuity-invalidation | reset:unexpected-eof | reset:unexpected-eof | true |
| eof_after_updates_boundary | expected-rejection-or-continuity-invalidation | reset:unexpected-eof | reset:unexpected-eof | true |
| oversized_prefix_before_allocation | expected-rejection-or-continuity-invalidation | reset:wire-limit | reset:wire-limit | true |
| truncated_prefix | expected-rejection-or-continuity-invalidation | reset:truncated-prefix | reset:truncated-prefix | true |
| truncated_payload | expected-rejection-or-continuity-invalidation | reset:truncated-payload | reset:truncated-payload | true |
| malformed_frame_json | expected-rejection-or-continuity-invalidation | reset:malformed-json | reset:malformed-json | true |
| zero_length_prefix | expected-rejection-or-continuity-invalidation | reset:wire-limit | reset:wire-limit | true |
| repeated_snapshot_address_replaces_staging | expected-feature | finished | finished | true |
| unknown_coverage_no_phantom_promotion | expected-feature | finished | finished | true |
| retained_item_limit_atomic_changes | expected-rejection-or-continuity-invalidation | reset:retention-limit | reset:retention-limit | true |
| retained_byte_limit_atomic_changes | expected-rejection-or-continuity-invalidation | reset:retention-limit | reset:retention-limit | true |
| writer_queue_item_overflow_transport_closure | expected-rejection-or-continuity-invalidation | reset:unexpected-eof | reset:unexpected-eof | true |
| writer_queue_byte_overflow_transport_closure | expected-rejection-or-continuity-invalidation | reset:unexpected-eof | reset:unexpected-eof | true |
| cancel_before_open_late_callback_no_resurrection | expected-feature | closed:cancelled | closed:cancelled | true |
| cancel_pending_open_late_callback_no_resurrection | expected-feature | closed:cancelled | closed:cancelled | true |
| cancel_while_open_staging_cleanup | expected-feature | closed:cancelled | closed:cancelled | true |
| shared_release_one_retains_final_cleans | expected-feature | closed:cancelled | closed:cancelled | true |
| reset_new_generation_resnapshot_stale_frames_rejected | expected-feature | finished | finished | true |

## Expected counterexamples (not successful provider capabilities)

- Partial snapshot with old cached member retains that member only as stale cache, not current membership or phantom deletion.
- Unexpected EOF before finite completion or after an updates boundary invalidates continuity; only EOF following finite snapshotEnd is successful.
- Full item/byte queues cannot carry a terminal reset; independent transport closure still invalidates the host, without queue reservation or custom ACK machinery.
- A known old-incarnation membership removal cannot erase a recreated observation; incompatible batches cannot partly publish.
- Late cancelled-open callbacks cannot allocate source readers; decoded old-generation frames cannot mutate a fresh generation.

## Limitations and unimplemented DTO surfaces

- Real transport means local tcp4 loopback with an uncompressed uint32-big-endian length prefix and JSON, not SDK gRPC/protobuf/Wails or a native cloud/Kubernetes provider. Native endpoints are per-case socket addresses, not real provider service URLs.
- Small trusted-host coordinator, deterministic scripted provider fixture, one bound selection/access-qualified representation; no hostile-plugin process or decoder isolation proof. Wire bound limits peer-controlled payload allocation, not every JSON decoder overhead allocation or total Go heap/RSS.
- Queue bytes include prefix and in-flight packet until write finishes. A bounded candidate serialization exists outside the queue; raw input and harness transcripts are fixtures, not bounded production ingestion. Raw/error fixture barrier contributes an intentionally zero-byte queue item but is not sent on wire. Fixture-only writer completion and host admission events schedule cases; they are not transport ACKs or product control messages.
- Source staging and retained source-cache serialized-byte bounds are enforced. Batch length is checked before full observation/change decode, but bounded frame-envelope RawMessage metadata is decoded first. Decoded Go heap overhead, processing-time budgets, native producer backpressure under OS socket-buffer saturation, throughput/latency, many-source concurrency and query-consumer lag are not measured.
- No native gap-free or point-in-time claim: all successful fixture boundaries declare bestEffort consistency; finite mode continuity is notApplicable. Contiguous frame sequences do not establish native freshness.
- Old source cache entries retained by partial/unknown replacement remain separately stale and absent from current-generation observations. This is a single-source membership prototype, not cross-source body arbitration, global object deletion or authorization-cache invalidation policy.
- Unimplemented DTO surfaces: full SourceOpen decoding/capability negotiation/nativeQuery/request validation/limits negotiation; arbitrary normalized QueryScope dimensions/any/oneOf/empty-oneOf; optional/alternative schema binding; displayName; nonempty typed DocumentCoverage.knownAbsent paths and present/absent contradiction validation; all SourceError codes other than unavailable; field-exact discriminated-union/unknown-field rejection. Supported DTO subset uses fixed provider/authority/type/scope/schema/access context and rejects unsupported knownAbsent facts.
- Canonical UInt64Text grammar, out-of-range values and max-value-without-history are exercised over TCP. A real contiguous history reaching uint64 max and arithmetic wrap branch are infeasible here and not claimed exercised.
- Cancellation/open races use host-side channel barriers; stale-frame case serializes and decodes the old frame through its socket before holding its callback until new generation admission. Some lifecycle operations are necessarily local methods; no fake in-memory transport is called IPC.
- No query evaluator/result generations/windowing, UI/JS integration, SDK bindings, credentials, real access changes, public resume, durable ACK/replay or heartbeat machinery. No automatic retries; recovery fixture explicitly performs one new-generation resnapshot.
- Only probe-owned listeners, socket endpoints, reader/writer goroutines, reservations, queued/staged/cache state are accounted. Zero active tracked workers after join is not a claim that runtime.NumGoroutine globally equals a fixed value. Socket deadlines are safety exits, never ordering evidence.
