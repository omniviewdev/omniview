package main

import (
    "encoding/binary"
    "encoding/json"
    "errors"
    "fmt"
    "io"
    "math"
    "net"
    "sort"
    "strconv"
    "strings"
    "sync"
    "time"
)

const (
    wireLimit = 8192
    batchLimit = 4
    stageItemLimit = 4
    stageByteLimit = 3072
    retainedItemLimit = 8
    retainedByteLimit = 8192
    defaultQueueItems = 2
    defaultQueueBytes = 16384
)

type Address struct {
    Provider string `json:"provider"`
    Authority string `json:"authority"`
    Type string `json:"type"`
    Scope map[string]string `json:"scope"`
    ID string `json:"id"`
}
type Schema struct { ID string `json:"id"`; Revision string `json:"revision"` }
type Representation struct { ID string `json:"representationId"`; Schema Schema `json:"schema"` }
type Document struct { Encoding string `json:"encoding"`; Text string `json:"text"` }
type DocumentCoverage struct { Kind string `json:"kind"`; KnownAbsent []json.RawMessage `json:"knownAbsent,omitempty"` }
type Observation struct {
    Address Address `json:"address"`
    Representation Representation `json:"representation"`
    Document Document `json:"document"`
    Coverage DocumentCoverage `json:"documentCoverage"`
    Incarnation string `json:"incarnation,omitempty"`
    Revision string `json:"sourceRevision,omitempty"`
    size int
}
type Coverage struct {
    Enumeration string `json:"enumeration"`
    Consistency string `json:"consistency"`
    Limitations []string `json:"limitations"`
}
type Change struct {
    Kind string `json:"kind"`
    Observation *Observation `json:"observation,omitempty"`
    Address *Address `json:"address,omitempty"`
    Incarnation string `json:"incarnation,omitempty"`
    Revision string `json:"sourceRevision,omitempty"`
}
type SourceError struct { Code string `json:"code"`; Message string `json:"message"`; RequestID string `json:"requestId"` }
type Payload struct {
    Kind string `json:"kind"`
    Mode string `json:"mode,omitempty"`
    Observations []json.RawMessage `json:"observations,omitempty"`
    Changes []json.RawMessage `json:"changes,omitempty"`
    Coverage *Coverage `json:"coverage,omitempty"`
    Continuity string `json:"continuity,omitempty"`
    Reason string `json:"reason,omitempty"`
    Message string `json:"message,omitempty"`
    Error *SourceError `json:"error,omitempty"`
}
type Frame struct {
    Session string `json:"sessionId"`
    Generation string `json:"generation"`
    Sequence string `json:"sequence"`
    Payload Payload `json:"payload"`
}
type CacheEntry struct { Observation Observation; Generation string }
type ReaderStats struct {
    Frames int `json:"wireFrames"`
    PayloadAllocations int `json:"payloadAllocations"`
    PayloadBytes int `json:"payloadAllocatedBytes"`
    MaxPayload int `json:"maxAllocatedPayload"`
    Oversized int `json:"oversizedPrefixes"`
    PrefixReads int `json:"prefixReads"`
}
type Event struct { Kind string; Generation string; Accepted bool }

type Coordinator struct {
    mu sync.Mutex
    session string
    generation string
    mode string
    phase string
    terminal string
    last uint64
    interests int
    reservations int
    handles int
    readerStarts int
    readersActive int
    lateCallbacks int
    lateFrames int
    conn net.Conn
    closed bool
    stage map[string]Observation
    stageBytes int
    stagePeakItems int
    stagePeakBytes int
    cache map[string]CacheEntry
    current map[string]Observation
    lastPublished string
    lastEnumeration string
    publicationUnits int
    ignoredIncarnation int
    reader ReaderStats
    events chan Event
    beforeApply func(string,Frame)
    wg sync.WaitGroup
}

func NewCoordinator(mode string, seeds []Observation) *Coordinator {
    c := &Coordinator{session:"session-1", mode:mode, phase:"idle", stage:map[string]Observation{}, cache:map[string]CacheEntry{}, current:map[string]Observation{}, events:make(chan Event, 32)}
    for _, o := range seeds { c.cache[key(o.Address)] = CacheEntry{o,"prior-generation"} }
    return c
}

// Reserve and attach are separate so cancellation of an asynchronous open can
// be scheduled before its callback. Only an admitted callback starts a reader.
func (c *Coordinator) Reserve(generation, mode string) bool {
    c.mu.Lock(); defer c.mu.Unlock()
    if c.closed || c.interests == 0 || c.reservations != 0 || c.conn != nil { return false }
    c.generation = generation; c.mode = mode; c.phase = "opening"; c.terminal = ""; c.last = 0
    c.reservations = 1; c.current = map[string]Observation{}; c.stage = map[string]Observation{}; c.stageBytes = 0
    return true
}
func (c *Coordinator) Acquire() bool {
    c.mu.Lock(); defer c.mu.Unlock()
    if c.closed { return false }; c.interests++; return true
}
func (c *Coordinator) Attach(generation string, conn net.Conn) bool {
    c.mu.Lock()
    if c.closed || c.interests == 0 || c.reservations != 1 || generation != c.generation || c.phase != "opening" {
        c.lateCallbacks++; c.mu.Unlock(); conn.Close(); return false
    }
    c.reservations = 0; c.handles++; c.conn = conn; c.readerStarts++; c.readersActive++
    c.wg.Add(1); c.mu.Unlock()
    go c.readLoop(generation, conn)
    return true
}
func (c *Coordinator) Release() {
    c.mu.Lock()
    if c.interests == 0 { c.mu.Unlock(); return }
    c.interests--
    if c.interests != 0 { c.mu.Unlock(); return }
    c.closed = true; c.reservations = 0
    if c.terminal == "" { c.invalidateLocked("closed:cancelled") }
    c.stage = map[string]Observation{}; c.stageBytes = 0
    c.current = map[string]Observation{}; c.cache = map[string]CacheEntry{}
    conn := c.conn; c.mu.Unlock()
    if conn != nil { conn.Close() }
}
func (c *Coordinator) invalidateLocked(reason string) {
    c.terminal = reason
    if strings.HasPrefix(reason,"failed:") { c.phase = "failed" } else if strings.HasPrefix(reason,"closed:") { c.phase = "closed" } else { c.phase = "resetRequired" }
    c.stage = map[string]Observation{}; c.stageBytes = 0; c.current = map[string]Observation{}
}
func (c *Coordinator) invalidate(generation, reason string) {
    c.mu.Lock(); defer c.mu.Unlock()
    if generation != c.generation || c.closed { return }
    if c.terminal == "" { c.invalidateLocked(reason) }
}
func (c *Coordinator) Retire(generation, reason string) {
    c.mu.Lock()
    if generation != c.generation || c.closed { c.mu.Unlock(); return }
    c.invalidateLocked(reason)
    conn := c.conn; c.conn = nil; c.reservations = 0; c.mu.Unlock()
    if conn != nil { conn.Close() }
}
func (c *Coordinator) readLoop(generation string, conn net.Conn) {
    defer c.wg.Done()
    defer func() {
        conn.Close()
        c.mu.Lock(); c.readersActive--; c.handles--; if c.conn == conn { c.conn = nil }; c.mu.Unlock()
        c.events <- Event{Kind:"reader-exit", Generation:generation}
    }()
    for {
        data, err := c.readPacket(conn)
        if err != nil {
            c.mu.Lock()
            if generation == c.generation && !c.closed && c.terminal == "" { c.invalidateLocked("reset:"+err.Error()) }
            c.mu.Unlock(); return
        }
        var frame Frame
        if err := json.Unmarshal(data,&frame); err != nil {
            c.invalidate(generation,"reset:malformed-json")
            c.events <- Event{Kind:"malformed-json",Generation:generation}; return
        }
        if c.beforeApply != nil { c.beforeApply(generation,frame) }
        accepted := c.apply(generation,frame)
        c.events <- Event{Kind:frame.Payload.Kind,Generation:generation,Accepted:accepted}
        c.mu.Lock(); terminal := c.terminal; c.mu.Unlock()
        // Finite completion remains on the socket until EOF to catch illegal
        // post-terminal frames; reset/failure immediately retires the reader.
        if terminal != "" && terminal != "finished" { return }
    }
}
func (c *Coordinator) readPacket(conn net.Conn) ([]byte,error) {
    var header [4]byte
    n,err := io.ReadFull(conn,header[:])
    c.mu.Lock(); c.reader.PrefixReads++; c.mu.Unlock()
    if err != nil { if n == 0 && errors.Is(err,io.EOF) { return nil,errors.New("unexpected-eof") }; return nil,errors.New("truncated-prefix") }
    size := binary.BigEndian.Uint32(header[:])
    if size == 0 || size > wireLimit {
        c.mu.Lock(); c.reader.Oversized++; c.mu.Unlock()
        return nil,errors.New("wire-limit")
    }
    // The peer-controlled length is admitted before the only payload make.
    data := make([]byte,int(size))
    c.mu.Lock(); c.reader.PayloadAllocations++; c.reader.PayloadBytes += len(data); c.reader.MaxPayload = max(c.reader.MaxPayload,len(data)); c.mu.Unlock()
    if _,err := io.ReadFull(conn,data); err != nil { return nil,errors.New("truncated-payload") }
    c.mu.Lock(); c.reader.Frames++; c.mu.Unlock()
    return data,nil
}
func canonicalSequence(s string) (uint64,bool) {
    if s == "" || (len(s)>1 && s[0]=='0') { return 0,false }
    for i:=range s { if s[i]<'0'||s[i]>'9' { return 0,false } }
    value,err := strconv.ParseUint(s,10,64); return value,err==nil
}
func (c *Coordinator) apply(transportGeneration string, f Frame) bool {
    c.mu.Lock(); defer c.mu.Unlock()
    // This guard also protects against a callback already scheduled by an old
    // reader. It cannot invalidate or populate the replacement generation.
    if c.closed || transportGeneration != c.generation { c.lateFrames++; return false }
    fail := func(code string) bool { c.invalidateLocked("reset:"+code); return false }
    if f.Session != c.session { return fail("wrong-session") }
    if f.Generation != c.generation { return fail("wrong-generation") }
    sequence,ok := canonicalSequence(f.Sequence); if !ok { return fail("invalid-sequence") }
    if c.last == math.MaxUint64 { return fail("sequence-overflow") }
    if sequence != c.last+1 { return fail("sequence-gap") }
    if c.terminal != "" { return fail("bad-phase") }
    p:=f.Payload
    if len(p.Observations)>batchLimit || len(p.Changes)>batchLimit { return fail("batch-limit") }
    switch p.Kind {
    case "begin":
        if c.phase!="opening" || sequence!=1 { return fail("bad-phase") }
        if p.Mode!=c.mode { return fail("wrong-mode") }
        c.phase="snapshotting"
    case "snapshot":
        if c.phase!="snapshotting" { return fail("bad-phase") }
        observations:=make([]Observation,0,len(p.Observations))
        nextBytes:=c.stageBytes; nextItems:=len(c.stage)
        // Validate the complete batch before modifying staging.
        touched:=map[string]int{}
        for _,raw:=range p.Observations {
            o,code:=decodeObservation(raw); if code!="" { return fail(code) }
            k:=key(o.Address)
            oldSize,exists:=touched[k]
            if !exists { if old,found:=c.stage[k]; found { oldSize=old.size } else { nextItems++ } }
            nextBytes += o.size-oldSize; touched[k]=o.size; observations=append(observations,o)
        }
        if nextItems>stageItemLimit { return fail("staging-items") }
        if nextBytes>stageByteLimit { return fail("staging-bytes") }
        for _,o:=range observations { c.stage[key(o.Address)]=o }
        c.stageBytes=nextBytes; c.stagePeakItems=max(c.stagePeakItems,len(c.stage)); c.stagePeakBytes=max(c.stagePeakBytes,c.stageBytes)
    case "snapshotEnd":
        if c.phase!="snapshotting" { return fail("bad-phase") }
        if p.Coverage==nil || !validCoverage(*p.Coverage) { return fail("invalid-coverage") }
        if c.mode=="snapshot" { if p.Continuity!="notApplicable" { return fail("invalid-continuity") } } else if p.Continuity!="gapFree" && p.Continuity!="bestEffort" { return fail("invalid-continuity") }
        nextCache:=map[string]CacheEntry{}
        if p.Coverage.Enumeration!="exhausted" { for k,o:=range c.cache { nextCache[k]=o } }
        for k,o:=range c.stage { nextCache[k]=CacheEntry{o,c.generation} }
        if !retainedWithinBounds(nextCache) { return fail("retention-limit") }
        c.cache=nextCache; c.current=c.stage; c.stage=map[string]Observation{}; c.stageBytes=0
        c.lastPublished=observationIDs(c.current); c.lastEnumeration=p.Coverage.Enumeration; c.publicationUnits++
        if c.mode=="snapshot" { c.phase="finished"; c.terminal="finished" } else { c.phase="following" }
    case "changes":
        if c.phase!="following" { return fail("bad-phase") }
        if p.Coverage!=nil && !validCoverage(*p.Coverage) { return fail("invalid-coverage") }
        if len(p.Changes)==0 && p.Coverage==nil { return fail("empty-changes") }
        changes:=make([]Change,0,len(p.Changes))
        for _,raw:=range p.Changes {
            var encoded struct {
                Kind string `json:"kind"`
                Observation json.RawMessage `json:"observation"`
                Address *Address `json:"address"`
                Incarnation string `json:"incarnation"`
                Revision string `json:"sourceRevision"`
            }
            if json.Unmarshal(raw,&encoded)!=nil { return fail("invalid-change") }
            change:=Change{Kind:encoded.Kind,Address:encoded.Address,Incarnation:encoded.Incarnation,Revision:encoded.Revision}
            if change.Kind=="upsert" {
                o,code:=decodeObservation(encoded.Observation); if code!="" { return fail(code) }; change.Observation=&o
            } else if change.Kind=="remove" {
                if change.Address==nil || !validAddress(*change.Address) { return fail("binding") }
            } else { return fail("invalid-change") }
            changes=append(changes,change)
        }
        nextCurrent:=make(map[string]Observation,len(c.current)); for k,o:=range c.current { nextCurrent[k]=o }
        nextCache:=make(map[string]CacheEntry,len(c.cache)); for k,o:=range c.cache { nextCache[k]=o }
        ignored:=0
        for _,change:=range changes {
            if change.Kind=="upsert" { o:=*change.Observation; k:=key(o.Address); nextCurrent[k]=o; nextCache[k]=CacheEntry{o,c.generation}; continue }
            k:=key(*change.Address)
            if old,found:=nextCache[k]; found && change.Incarnation!="" && old.Observation.Incarnation!="" && change.Incarnation!=old.Observation.Incarnation { ignored++; continue }
            delete(nextCurrent,k); delete(nextCache,k)
        }
        if !retainedWithinBounds(nextCache) { return fail("retention-limit") }
        c.current=nextCurrent; c.cache=nextCache; c.ignoredIncarnation+=ignored
        if p.Coverage!=nil { c.lastEnumeration=p.Coverage.Enumeration }
        c.lastPublished=observationIDs(c.current); c.publicationUnits++
    case "reset":
        if c.phase!="snapshotting" && c.phase!="following" { return fail("bad-phase") }
        if p.Reason!="continuityLost" && p.Reason!="overflow" && p.Reason!="bindingChanged" && p.Reason!="sourceInvalidated" { return fail("invalid-reset") }
        c.invalidateLocked("reset:"+p.Reason)
    case "failed":
        if c.phase!="opening" && c.phase!="snapshotting" && c.phase!="following" { return fail("bad-phase") }
        if p.Error==nil || p.Error.Code!="unavailable" || p.Error.RequestID!="request-1" { return fail("invalid-error") }
        c.invalidateLocked("failed:"+p.Error.Code)
    default: return fail("bad-phase")
    }
    c.last=sequence
    return true
}
func validAddress(a Address) bool {
    return a.Provider=="fixture" && a.Authority=="local-account" && a.Type=="machine" && a.ID!="" && len(a.Scope)==1 && a.Scope["environment"]=="prod"
}
func key(a Address) string {
    // Exact scope is fixed by admission in this bounded fixture. Components are
    // length delimited instead of separator joined, so opaque IDs cannot alias.
    return fmt.Sprintf("%d:%s%d:%s%d:%s%d:%s%d:%s",len(a.Provider),a.Provider,len(a.Authority),a.Authority,len(a.Type),a.Type,len(a.Scope["environment"]),a.Scope["environment"],len(a.ID),a.ID)
}
func decodeObservation(raw json.RawMessage) (Observation,string) {
    var o Observation
    if json.Unmarshal(raw,&o)!=nil { return o,"invalid-observation" }
    o.size=len(raw)
    if !validAddress(o.Address) || o.Representation.ID!="summary" || o.Representation.Schema.ID!="machine-schema" || o.Representation.Schema.Revision!="r1" { return o,"binding" }
    if o.Document.Encoding!="json" || !json.Valid([]byte(o.Document.Text)) { return o,"invalid-document" }
    if o.Coverage.Kind!="complete" && o.Coverage.Kind!="partial" { return o,"invalid-document-coverage" }
    // Typed knownAbsent path validation is deliberately not implemented. The
    // supported fixture subset rejects it instead of pretending it is checked.
    if len(o.Coverage.KnownAbsent)!=0 { return o,"unsupported-document-coverage" }
    return o,""
}
func validCoverage(c Coverage) bool {
    return (c.Enumeration=="exhausted"||c.Enumeration=="partial"||c.Enumeration=="unknown") && (c.Consistency=="pointInTime"||c.Consistency=="bestEffort"||c.Consistency=="unknown")
}
func retainedWithinBounds(cache map[string]CacheEntry) bool {
    if len(cache)>retainedItemLimit { return false }; size:=0; for _,e:=range cache { size+=e.Observation.size }; return size<=retainedByteLimit
}
func observationIDs(m map[string]Observation) string { ids:=make([]string,0,len(m)); for _,o:=range m { ids=append(ids,o.Address.ID) }; sort.Strings(ids); return strings.Join(ids,",") }
func (c *Coordinator) Snapshot() map[string]any {
    c.mu.Lock(); defer c.mu.Unlock()
    cacheIDs:=[]string{}; staleIDs:=[]string{}; retainedBytes:=0
    for _,e:=range c.cache {
        cacheIDs=append(cacheIDs,e.Observation.Address.ID); retainedBytes+=e.Observation.size
        if e.Generation!=c.generation || c.terminal!="finished" && c.phase!="following" { staleIDs=append(staleIDs,e.Observation.Address.ID) }
    }
    sort.Strings(cacheIDs); sort.Strings(staleIDs)
    text:=""; if len(c.current)==1 { for _,o:=range c.current { text=o.Document.Text } }
    return map[string]any{
        "terminal":c.terminal,"phase":c.phase,"generation":c.generation,"sequence":strconv.FormatUint(c.last,10),
        "current":observationIDs(c.current),"cache":strings.Join(cacheIDs,","),"stale":strings.Join(staleIDs,","),"lastPublished":c.lastPublished,"documentText":text,"lastEnumeration":c.lastEnumeration,
        "stagedItems":len(c.stage),"stagedBytes":c.stageBytes,"stagePeakItems":c.stagePeakItems,"stagePeakBytes":c.stagePeakBytes,
        "retainedItems":len(c.cache),"retainedBytes":retainedBytes,"publicationUnits":c.publicationUnits,"ignoredIncarnationRemoves":c.ignoredIncarnation,
        "interests":c.interests,"reservations":c.reservations,"handles":c.handles,"readerStarts":c.readerStarts,"readersActive":c.readersActive,
        "lateCallbacksRejected":c.lateCallbacks,"lateFramesRejected":c.lateFrames,"wireFrames":c.reader.Frames,"prefixReads":c.reader.PrefixReads,
        "payloadAllocations":c.reader.PayloadAllocations,"payloadAllocatedBytes":c.reader.PayloadBytes,"maxAllocatedPayload":c.reader.MaxPayload,"oversizedPrefixes":c.reader.Oversized,
    }
}

type Packet struct {
    Header [4]byte
    HeaderBytes int
    Payload []byte
    Gate <-chan struct{}
    Entered chan<- struct{}
    Written chan struct{}
}
func NewPacket(payload []byte) Packet { p:=Packet{Payload:payload,HeaderBytes:4}; binary.BigEndian.PutUint32(p.Header[:],uint32(len(payload))); return p }
func (p Packet) Size() int { return p.HeaderBytes+len(p.Payload) }
type QueueStats struct {
    PeakItems int `json:"queuePeakItems"`
    PeakBytes int `json:"queuePeakBytes"`
    CurrentItems int `json:"queueItems"`
    CurrentBytes int `json:"queueBytes"`
    Overflow int `json:"overflowCount"`
    OutOfBandClose bool `json:"outOfBandClose"`
    WriterStarts int `json:"writerStarts"`
    WriterActive int `json:"writersActive"`
    WrittenFrames int `json:"writtenPackets"`
    WrittenBytes int `json:"writtenBytes"`
}
type WriterQueue struct {
    mu sync.Mutex
    conn net.Conn
    queue []Packet
    head int
    tail int
    pending int
    maxItems int
    maxBytes int
    closed bool
    done chan struct{}
    stopped chan struct{}
    wake chan struct{}
    stats QueueStats
}
func NewWriterQueue(conn net.Conn,items,bytes int) *WriterQueue {
    q:=&WriterQueue{conn:conn,queue:make([]Packet,items),maxItems:items,maxBytes:bytes,done:make(chan struct{}),stopped:make(chan struct{}),wake:make(chan struct{},1),stats:QueueStats{WriterStarts:1,WriterActive:1}}
    go q.run(); return q
}
func (q *WriterQueue) Enqueue(p Packet) bool {
    q.mu.Lock()
    if q.closed { q.mu.Unlock(); return false }
    if q.stats.CurrentItems+1>q.maxItems || q.stats.CurrentBytes+p.Size()>q.maxBytes {
        q.stats.Overflow++; q.stats.OutOfBandClose=true; q.mu.Unlock(); q.Close(); return false
    }
    q.queue[q.tail]=p; q.tail=(q.tail+1)%q.maxItems; q.pending++; q.stats.CurrentItems++; q.stats.CurrentBytes+=p.Size()
    q.stats.PeakItems=max(q.stats.PeakItems,q.stats.CurrentItems); q.stats.PeakBytes=max(q.stats.PeakBytes,q.stats.CurrentBytes)
    q.mu.Unlock(); select { case q.wake<-struct{}{}: default: }; return true
}
func (q *WriterQueue) Close() {
    q.mu.Lock()
    if q.closed { q.mu.Unlock(); return }
    q.closed=true; q.queue=nil; q.stats.CurrentItems=0; q.stats.CurrentBytes=0; close(q.done); q.mu.Unlock()
    // Independent of queue capacity and the writer gate: terminal progress
    // never waits for a reset frame to fit into the saturated data queue.
    q.conn.Close()
}
func writeAll(w io.Writer,b []byte) (int,error) {
    total:=0; for len(b)>0 { n,err:=w.Write(b); total+=n; b=b[n:]; if err!=nil { return total,err }; if n==0 { return total,io.ErrShortWrite } }; return total,nil
}
func (q *WriterQueue) run() {
    defer close(q.stopped)
    defer func(){ q.mu.Lock(); q.stats.WriterActive=0; q.mu.Unlock() }()
    for {
        q.mu.Lock()
        if q.closed { q.mu.Unlock(); return }
        if q.pending==0 { q.mu.Unlock(); select { case <-q.done:return; case <-q.wake:continue } }
        p:=q.queue[q.head]; q.queue[q.head]=Packet{}; q.head=(q.head+1)%q.maxItems; q.pending--; q.mu.Unlock()
        if p.Entered!=nil { p.Entered<-struct{}{} }
        if p.Gate!=nil { select { case <-q.done:return; case <-p.Gate: } }
        n,err:=writeAll(q.conn,p.Header[:p.HeaderBytes]); written:=n
        if err==nil { n,err=writeAll(q.conn,p.Payload); written+=n }
        q.mu.Lock(); q.stats.WrittenBytes+=written
        if err==nil { q.stats.WrittenFrames++ }
        if !q.closed { q.stats.CurrentItems--; q.stats.CurrentBytes-=p.Size() }
        q.mu.Unlock()
        if p.Written!=nil { close(p.Written) }
        if err!=nil { q.Close(); return }
    }
}
func (q *WriterQueue) Snapshot() map[string]any {
    q.mu.Lock(); defer q.mu.Unlock()
    return map[string]any{"queuePeakItems":q.stats.PeakItems,"queuePeakBytes":q.stats.PeakBytes,"queueItems":q.stats.CurrentItems,"queueBytes":q.stats.CurrentBytes,"overflowCount":q.stats.Overflow,"outOfBandClose":q.stats.OutOfBandClose,"writerStarts":q.stats.WriterStarts,"writersActive":q.stats.WriterActive,"writtenPackets":q.stats.WrittenFrames,"writtenBytes":q.stats.WrittenBytes,"queueItemLimit":q.maxItems,"queueByteLimit":q.maxBytes}
}

type Endpoint struct { Listener string `json:"listener"`; Provider string `json:"provider"`; Host string `json:"host"` }
func SocketPair() (net.Conn,net.Conn,Endpoint,error) {
    listener,err:=net.ListenTCP("tcp4",&net.TCPAddr{IP:net.ParseIP("127.0.0.1"),Port:0}); if err!=nil { return nil,nil,Endpoint{},err }
    defer listener.Close()
    remote,err:=net.DialTCP("tcp4",nil,listener.Addr().(*net.TCPAddr)); if err!=nil { return nil,nil,Endpoint{},err }
    host,err:=listener.AcceptTCP(); if err!=nil { remote.Close(); return nil,nil,Endpoint{},err }
    deadline:=time.Now().Add(5*time.Second); remote.SetDeadline(deadline); host.SetDeadline(deadline)
    return host,remote,Endpoint{Listener:listener.Addr().String(),Provider:remote.LocalAddr().String(),Host:host.LocalAddr().String()},nil
}
