package main

import (
    "crypto/sha256"
    "encoding/binary"
    "encoding/hex"
    "encoding/json"
    "errors"
    "fmt"
    "net"
    "os"
    "path/filepath"
    "runtime"
    "sort"
    "strconv"
    "strings"
    "time"
)

type ObservationSpec struct {
    ID string `json:"id"`
    Incarnation string `json:"incarnation,omitempty"`
    Text string `json:"text,omitempty"`
    TextBytes int `json:"textBytes,omitempty"`
    Provider string `json:"provider,omitempty"`
    Authority string `json:"authority,omitempty"`
    Type string `json:"type,omitempty"`
    Scope string `json:"scope,omitempty"`
    Representation string `json:"representation,omitempty"`
    SchemaRevision string `json:"schemaRevision,omitempty"`
    DocumentCoverage string `json:"documentCoverage,omitempty"`
}
type ChangeSpec struct {
    Kind string `json:"kind"`
    ObservationSpec
}
type FrameSpec struct {
    Kind string `json:"kind"`
    Sequence string `json:"sequence,omitempty"`
    Session string `json:"sessionId,omitempty"`
    Generation string `json:"generation,omitempty"`
    Mode string `json:"mode,omitempty"`
    Enumeration string `json:"enumeration,omitempty"`
    Continuity string `json:"continuity,omitempty"`
    Reason string `json:"reason,omitempty"`
    Observations []ObservationSpec `json:"observations,omitempty"`
    Changes []ChangeSpec `json:"changes,omitempty"`
}
type Scenario struct {
    Name string `json:"name"`
    Mode string `json:"mode"`
    Special string `json:"special,omitempty"`
    Raw string `json:"raw,omitempty"`
    Seed []ObservationSpec `json:"seed,omitempty"`
    Frames []FrameSpec `json:"frames,omitempty"`
    Expected map[string]any `json:"expected"`
}
type WireInput struct {
    Scenario string `json:"scenario"`
    Generation string `json:"transportGeneration"`
    HeaderHex string `json:"headerHex"`
    Payload string `json:"payloadText"`
    QueueAccepted bool `json:"queueAccepted"`
    Note string `json:"note,omitempty"`
}
type CaseResult struct {
    Name string `json:"name"`
    Classification string `json:"classification"`
    Transport string `json:"transport"`
    Endpoints []Endpoint `json:"endpoints"`
    Expected map[string]any `json:"expected"`
    Actual map[string]any `json:"actual"`
    Passed bool `json:"passed"`
    Assertions int `json:"assertions"`
    Failures []string `json:"failures"`
}
type Report struct {
    Probe string `json:"probe"`
    Command string `json:"command"`
    GoVersion string `json:"goVersion"`
    Platform string `json:"platform"`
    SourceHashes map[string]string `json:"sourceSHA256"`
    Limits map[string]int `json:"limits"`
    Cases []CaseResult `json:"cases"`
    Assertions int `json:"assertions"`
    Passed bool `json:"passed"`
    UnexpectedFailures int `json:"unexpectedFailures"`
    Limitations []string `json:"limitations"`
    Counterexamples []string `json:"expectedCounterexamples"`
    Measurements map[string]int `json:"measurements"`
}
func fallback(s,d string) string { if s!="" { return s }; return d }
func makeObservation(spec ObservationSpec) Observation {
    text:=fallback(spec.Text,"{\"state\":\"observed\"}")
    if spec.TextBytes>0 { text="{\"padding\":\""+strings.Repeat("x",spec.TextBytes)+"\"}" }
    o:=Observation{
        Address:Address{Provider:fallback(spec.Provider,"fixture"),Authority:fallback(spec.Authority,"local-account"),Type:fallback(spec.Type,"machine"),Scope:map[string]string{"environment":fallback(spec.Scope,"prod")},ID:spec.ID},
        Representation:Representation{ID:fallback(spec.Representation,"summary"),Schema:Schema{ID:"machine-schema",Revision:fallback(spec.SchemaRevision,"r1")}},
        Document:Document{Encoding:"json",Text:text},Coverage:DocumentCoverage{Kind:fallback(spec.DocumentCoverage,"complete")},Incarnation:spec.Incarnation,Revision:"opaque:r/9-not-sortable",
    }
    data,err:=json.Marshal(o); must(err); o.size=len(data); return o
}
func makeFrame(spec FrameSpec,index int,generation,mode string) Frame {
    p:=Payload{Kind:spec.Kind}
    switch spec.Kind {
    case "begin": p.Mode=fallback(spec.Mode,mode)
    case "snapshot":
        for _,s:=range spec.Observations { data,err:=json.Marshal(makeObservation(s)); must(err); p.Observations=append(p.Observations,data) }
    case "snapshotEnd":
        p.Coverage=&Coverage{Enumeration:fallback(spec.Enumeration,"exhausted"),Consistency:"bestEffort",Limitations:[]string{"local fixture supplies no native cutover evidence"}}
        continuity:="bestEffort"; if mode=="snapshot" { continuity="notApplicable" }; p.Continuity=fallback(spec.Continuity,continuity)
    case "changes":
        for _,s:=range spec.Changes {
            o:=makeObservation(s.ObservationSpec); change:=Change{Kind:s.Kind}
            if s.Kind=="upsert" { change.Observation=&o } else { change.Address=&o.Address; change.Incarnation=s.Incarnation; change.Revision=o.Revision }
            data,err:=json.Marshal(change); must(err); p.Changes=append(p.Changes,data)
        }
        if spec.Enumeration!="" { p.Coverage=&Coverage{Enumeration:spec.Enumeration,Consistency:"bestEffort",Limitations:[]string{"fixture-only coverage progress"}} }
    case "reset": p.Reason=fallback(spec.Reason,"continuityLost"); p.Message="controlled fixture reset"
    case "failed": p.Error=&SourceError{Code:"unavailable",Message:"controlled fixture failure",RequestID:"request-1"}
    }
    return Frame{Session:fallback(spec.Session,"session-1"),Generation:fallback(spec.Generation,generation),Sequence:fallback(spec.Sequence,strconv.Itoa(index+1)),Payload:p}
}
func must(err error) { if err!=nil { panic(err) } }
func require(ok bool,message string) { if !ok { panic(message) } }

type Run struct {
    c *Coordinator
    queues []*WriterQueue
    sockets []net.Conn
    endpoints []Endpoint
    wires []WireInput
    scenario string
    extras map[string]any
}
func newRun(s Scenario) *Run {
    seeds:=make([]Observation,0,len(s.Seed)); for _,spec:=range s.Seed { seeds=append(seeds,makeObservation(spec)) }
    return &Run{c:NewCoordinator(s.Mode,seeds),scenario:s.Name,extras:map[string]any{}}
}
func (r *Run) pair() (net.Conn,net.Conn) {
    host,provider,endpoint,err:=SocketPair(); must(err)
    r.sockets=append(r.sockets,host,provider); r.endpoints=append(r.endpoints,endpoint)
    return host,provider
}
func (r *Run) open(generation,mode string,queueItems,queueBytes int) *WriterQueue {
    require(r.c.Reserve(generation,mode),"reservation unexpectedly rejected")
    host,provider:=r.pair(); require(r.c.Attach(generation,host),"open callback unexpectedly rejected")
    q:=NewWriterQueue(provider,queueItems,queueBytes); r.queues=append(r.queues,q); return q
}
func await(ch <-chan struct{},what string) {
    timer:=time.NewTimer(5*time.Second); defer timer.Stop()
    select { case <-ch: return; case <-timer.C: panic("safety timeout: "+what) }
}
func (r *Run) event(generation,kind string) Event {
    timer:=time.NewTimer(5*time.Second); defer timer.Stop()
    for { select {
        case e:=<-r.c.events:
            if e.Generation==generation && (kind==""||e.Kind==kind) { return e }
            // Expected old-generation exit events may precede a new event.
            if e.Kind!="reader-exit" { panic(fmt.Sprintf("unexpected fixture event: %+v, waiting %s/%s",e,generation,kind)) }
        case <-timer.C: panic("safety timeout: reader event "+generation+"/"+kind)
    } }
}
func (r *Run) enqueue(q *WriterQueue,p Packet,generation,note string) bool {
    accepted:=q.Enqueue(p)
    r.wires=append(r.wires,WireInput{Scenario:r.scenario,Generation:generation,HeaderHex:hex.EncodeToString(p.Header[:p.HeaderBytes]),Payload:string(p.Payload),QueueAccepted:accepted,Note:note})
    return accepted
}
func (r *Run) send(q *WriterQueue,spec FrameSpec,index int,generation,mode string) Event {
    frame:=makeFrame(spec,index,generation,mode); data,err:=json.Marshal(frame); must(err)
    require(len(data)<=wireLimit,"harness generated an unexpectedly oversized ordinary frame")
    packet:=NewPacket(data); packet.Written=make(chan struct{})
    require(r.enqueue(q,packet,generation,"serialized SourceFrame over loopback TCP"),"ordinary send unexpectedly overflowed writer queue")
    event:=r.event(generation,spec.Kind); await(packet.Written,"writer completion/accounting barrier"); return event
}
func (r *Run) finish(q *WriterQueue) { q.Close(); await(q.stopped,"writer cleanup"); r.c.wg.Wait() }
func (r *Run) cleanup() map[string]any {
    for _,q:=range r.queues { q.Close() }
    for _,conn:=range r.sockets { conn.Close() }
    for r.c.Snapshot()["interests"].(int)>0 { r.c.Release() }
    for _,q:=range r.queues { await(q.stopped,"writer cleanup") }
    r.c.wg.Wait()
    state:=r.c.Snapshot(); result:=map[string]any{}
    for _,k:=range []string{"interests","reservations","handles","readersActive","stagedItems","stagedBytes","retainedItems","retainedBytes"} { result["cleanup_"+k]=state[k] }
    result["cleanup_current"]=state["current"]
    writers:=0; queueItems:=0; queueBytes:=0
    for _,q:=range r.queues { snapshot:=q.Snapshot(); writers+=snapshot["writersActive"].(int); queueItems+=snapshot["queueItems"].(int); queueBytes+=snapshot["queueBytes"].(int) }
    result["cleanup_writersActive"]=writers; result["cleanup_queueItems"]=queueItems; result["cleanup_queueBytes"]=queueBytes
    closedSockets:=0
    for _,conn:=range r.sockets { if errors.Is(conn.SetReadDeadline(time.Now()),net.ErrClosed) { closedSockets++ } }
    result["cleanup_socketEndpointsClosed"]=closedSockets; result["cleanup_socketEndpointsExpected"]=len(r.sockets)
    return result
}
func merge(target,src map[string]any) { for k,v:=range src { target[k]=v } }
func (r *Run) actual() map[string]any {
    result:=r.c.Snapshot()
    // Per-case queue peaks are exact measured maxima, not sums of independent
    // generations. Totals are separately named for multi-generation cases.
    result["queuePeakItems"]=0; result["queuePeakBytes"]=0; result["overflowCount"]=0; result["outOfBandClose"]=false
    result["queueItemLimit"]=defaultQueueItems; result["queueByteLimit"]=defaultQueueBytes
    result["enqueuedResetFrames"]=0; result["queueItems"]=0; result["queueBytes"]=0; result["writersActive"]=0
    result["writerStarts"]=0; result["writtenPackets"]=0; result["writtenBytes"]=0
    perQueue:=[]map[string]any{}
    for _,q:=range r.queues {
        snapshot:=q.Snapshot(); perQueue=append(perQueue,snapshot)
        for _,k:=range []string{"queuePeakItems","queuePeakBytes"} { result[k]=max(result[k].(int),snapshot[k].(int)) }
        for _,k:=range []string{"overflowCount","queueItems","queueBytes","writersActive","writerStarts","writtenPackets","writtenBytes"} { result[k]=result[k].(int)+snapshot[k].(int) }
        result["outOfBandClose"]=result["outOfBandClose"].(bool)||snapshot["outOfBandClose"].(bool)
        result["queueItemLimit"]=q.maxItems; result["queueByteLimit"]=q.maxBytes
    }
    for _,wire:=range r.wires {
        if !wire.QueueAccepted { continue }; var frame Frame
        if json.Unmarshal([]byte(wire.Payload),&frame)==nil && frame.Payload.Kind=="reset" { result["enqueuedResetFrames"]=result["enqueuedResetFrames"].(int)+1 }
    }
    result["queues"]=perQueue; merge(result,r.extras); return result
}
func runOrdinary(r *Run,s Scenario) {
    require(r.c.Acquire(),"initial acquire rejected")
    q:=r.open("generation-1",s.Mode,defaultQueueItems,defaultQueueBytes)
    if s.Raw!="" {
        var packet Packet
        switch s.Raw {
        case "oversized": packet=NewPacket(nil); binary.BigEndian.PutUint32(packet.Header[:],wireLimit+1)
        case "truncated-prefix": packet=NewPacket(nil); packet.HeaderBytes=2
        case "truncated-payload": packet=NewPacket([]byte("{}")); binary.BigEndian.PutUint32(packet.Header[:],20)
        case "malformed-json": packet=NewPacket([]byte("{bad"))
        case "zero-length": packet=NewPacket(nil)
        default: panic("unknown raw fixture")
        }
        require(r.enqueue(q,packet,"generation-1","intentional "+s.Raw),"raw frame unexpectedly overflowed")
        // Wait for the single packet to be written, without closing it before
        // transmission. A gate on a subsequent empty packet is a writer-side
        // fixture barrier, not a wire acknowledgment or protocol feature.
        entered:=make(chan struct{},1); gate:=make(chan struct{})
        barrier:=NewPacket(nil); barrier.HeaderBytes=0; barrier.Gate=gate; barrier.Entered=entered
        require(q.Enqueue(barrier),"barrier unexpectedly overflowed")
        await(entered,"raw packet write barrier")
        q.Close(); close(gate)
        r.finish(q); return
    }
    for index,spec:=range s.Frames {
        r.send(q,spec,index,"generation-1",s.Mode)
        state:=r.c.Snapshot()
        if terminal:=state["terminal"].(string); terminal!=""&&terminal!="finished" { break }
    }
    r.finish(q)
}
func runQueueOverflow(r *Run,s Scenario) {
    require(r.c.Acquire(),"initial acquire rejected")
    byteLimit:=defaultQueueBytes; if s.Special=="queue-bytes" { byteLimit=2048 }
    q:=r.open("generation-1",s.Mode,defaultQueueItems,byteLimit)
    r.send(q,FrameSpec{Kind:"begin"},0,"generation-1",s.Mode)
    r.send(q,FrameSpec{Kind:"snapshotEnd"},1,"generation-1",s.Mode)
    entered:=make(chan struct{},1); gate:=make(chan struct{})
    spec:=FrameSpec{Kind:"changes",Changes:[]ChangeSpec{{Kind:"upsert",ObservationSpec:ObservationSpec{ID:"blocked"}}}}
    if s.Special=="queue-bytes" { spec.Changes[0].TextBytes=1000 }
    frame:=makeFrame(spec,2,"generation-1",s.Mode); data,err:=json.Marshal(frame); must(err)
    packet:=NewPacket(data); packet.Gate=gate; packet.Entered=entered
    require(r.enqueue(q,packet,"generation-1","writer holds this packet in flight before writing"),"first blocked packet rejected")
    await(entered,"writer entered blocked packet")
    other:=NewPacket(data)
    accepted:=r.enqueue(q,other,"generation-1","full queue exercise; terminal uses socket closure, not data queue")
    if s.Special=="queue-items" {
        require(accepted,"second item unexpectedly rejected")
        require(!r.enqueue(q,other,"generation-1","expected item overflow"),"item overflow unexpectedly accepted")
    } else { require(!accepted,"byte overflow unexpectedly accepted") }
    expectedPeak:=packet.Size(); if s.Special=="queue-items" { expectedPeak*=2 }
    r.extras["expectedQueuePeakBytes"]=expectedPeak
    // Do not release gate: independent Close must unblock the writer and cause
    // the reader to classify lost following continuity through the real socket.
    r.finish(q)
}
func runCancelled(r *Run,s Scenario) {
    require(r.c.Acquire(),"initial acquire rejected")
    generation:="generation-1"
    if s.Special=="cancel-before-open" {
        r.c.Release(); r.extras["reserveAfterCancellationRejected"]=!r.c.Reserve(generation,s.Mode)
        host,remote:=r.pair(); require(!r.c.Attach(generation,host),"late callback resurrected cancelled source"); remote.Close(); return
    }
    if s.Special=="cancel-pending-open" {
        require(r.c.Reserve(generation,s.Mode),"pending open reserve rejected")
        host,remote:=r.pair()
        // Native socket establishment is complete, but the host open callback
        // is explicitly held until after pending-interest cancellation.
        require(r.c.Snapshot()["reservations"].(int)==1,"pending reservation missing")
        r.c.Release(); require(!r.c.Attach(generation,host),"late pending callback resurrected source"); remote.Close(); return
    }
    if s.Special=="shared" { require(r.c.Acquire(),"second interest rejected") }
    q:=r.open(generation,s.Mode,defaultQueueItems,defaultQueueBytes)
    r.send(q,FrameSpec{Kind:"begin"},0,generation,s.Mode)
    if s.Special=="shared" {
        r.c.Release(); state:=r.c.Snapshot()
        r.extras["retainedAfterFirstRelease"]=state["interests"].(int)==1&&state["handles"].(int)==1&&state["terminal"]==""
    }
    r.send(q,FrameSpec{Kind:"snapshot",Observations:[]ObservationSpec{{ID:"a"}}},1,generation,s.Mode)
    if s.Special=="shared" { r.send(q,FrameSpec{Kind:"snapshotEnd"},2,generation,s.Mode) }
    r.c.Release(); r.finish(q)
    r.extras["reacquireAfterFinalReleaseRejected"]=!r.c.Acquire()
}
func runReopen(r *Run,s Scenario) {
    require(r.c.Acquire(),"initial acquire rejected")
    decoded:=make(chan struct{},1); releaseCallback:=make(chan struct{})
    released:=false
    defer func(){ if !released { close(releaseCallback) } }()
    r.c.beforeApply=func(generation string,frame Frame) {
        if generation=="generation-1" && frame.Sequence=="4" { decoded<-struct{}{}; <-releaseCallback }
    }
    oldQ:=r.open("generation-1",s.Mode,defaultQueueItems,defaultQueueBytes)
    r.send(oldQ,FrameSpec{Kind:"begin"},0,"generation-1",s.Mode)
    r.send(oldQ,FrameSpec{Kind:"snapshot",Observations:[]ObservationSpec{{ID:"old"}}},1,"generation-1",s.Mode)
    r.send(oldQ,FrameSpec{Kind:"snapshotEnd"},2,"generation-1",s.Mode)
    stale:=makeFrame(FrameSpec{Kind:"changes",Changes:[]ChangeSpec{{Kind:"upsert",ObservationSpec:ObservationSpec{ID:"poison"}}}},3,"generation-1",s.Mode)
    bytes,err:=json.Marshal(stale); must(err)
    require(r.enqueue(oldQ,NewPacket(bytes),"generation-1","decoded over the old socket, callback held until generation replacement"),"old stale frame enqueue failed")
    await(decoded,"old-generation frame decoded before callback")
    r.c.Retire("generation-1","reset:continuityLost")
    retired:=r.c.Snapshot(); r.extras["retiredGenerationCurrent"]=retired["current"]; r.extras["retiredGenerationStale"]=retired["stale"]
    newQ:=r.open("generation-2","snapshot",defaultQueueItems,defaultQueueBytes)
    r.send(newQ,FrameSpec{Kind:"begin"},0,"generation-2","snapshot")
    close(releaseCallback); released=true
    event:=r.event("generation-1","changes"); require(!event.Accepted,"old generation callback was accepted")
    r.event("generation-1","reader-exit")
    r.send(newQ,FrameSpec{Kind:"snapshot",Observations:[]ObservationSpec{{ID:"new"}}},1,"generation-2","snapshot")
    r.send(newQ,FrameSpec{Kind:"snapshotEnd"},2,"generation-2","snapshot")
    oldQ.Close(); await(oldQ.stopped,"retired writer cleanup"); r.finish(newQ)
}
func execute(s Scenario) (result CaseResult,wires []WireInput) {
    r:=newRun(s)
    result=CaseResult{Name:s.Name,Classification:"expected-feature",Transport:"real tcp4 127.0.0.1 length-prefixed JSON",Expected:s.Expected,Failures:[]string{}}
    if terminal,ok:=s.Expected["terminal"].(string); ok && (strings.HasPrefix(terminal,"reset:")||strings.HasPrefix(terminal,"failed:")) { result.Classification="expected-rejection-or-continuity-invalidation" }
    defer func() {
        if problem:=recover(); problem!=nil { result.Failures=append(result.Failures,fmt.Sprint(problem)) }
        result.Actual=r.actual(); result.Endpoints=r.endpoints; wires=r.wires
        cleanup:=r.cleanup(); merge(result.Actual,cleanup)
        assert:=func(ok bool,message string) { result.Assertions++; if !ok { result.Failures=append(result.Failures,message) } }
        for k,expected:=range s.Expected { e,_:=json.Marshal(expected); a,_:=json.Marshal(result.Actual[k]); assert(string(e)==string(a),fmt.Sprintf("%s expected %s, actual %s",k,e,a)) }
        for _,k:=range []string{"cleanup_interests","cleanup_reservations","cleanup_handles","cleanup_readersActive","cleanup_stagedItems","cleanup_stagedBytes","cleanup_retainedItems","cleanup_retainedBytes","cleanup_writersActive","cleanup_queueItems","cleanup_queueBytes"} { assert(result.Actual[k]==0,k+" must equal zero") }
        assert(result.Actual["cleanup_current"]=="","final release retains no current observations")
        assert(result.Actual["cleanup_socketEndpointsClosed"]==result.Actual["cleanup_socketEndpointsExpected"],"socket endpoints are not all observably closed")
        if expected,ok:=result.Actual["expectedQueuePeakBytes"]; ok { assert(result.Actual["queuePeakBytes"]==expected,"queue byte accounting differs from exact admitted serialized packet bytes") }
        for _,bound:=range []struct{key string; limit int}{{"stagePeakItems",stageItemLimit},{"stagePeakBytes",stageByteLimit},{"maxAllocatedPayload",wireLimit},{"retainedItems",retainedItemLimit},{"retainedBytes",retainedByteLimit}} {
            value:=result.Actual[bound.key].(int); assert(value>=0&&value<=bound.limit,fmt.Sprintf("%s=%d exceeds bound %d",bound.key,value,bound.limit))
        }
        for _,q:=range r.queues {
            stats:=q.Snapshot(); assert(stats["queuePeakItems"].(int)<=q.maxItems,"queue item peak exceeded limit"); assert(stats["queuePeakBytes"].(int)<=q.maxBytes,"queue byte peak exceeded limit")
            assert(stats["queueItems"].(int)==0&&stats["queueBytes"].(int)==0,"queue accounting not empty after cleanup")
        }
        assert(len(r.endpoints)>0,"fixture did not establish real native loopback endpoints")
        if s.Special=="cancel-before-open" { assert(result.Actual["reserveAfterCancellationRejected"]==true,"cancelled reservation resurrected") }
        if s.Special=="cancel-open"||s.Special=="shared" { assert(result.Actual["reacquireAfterFinalReleaseRejected"]==true,"final release allowed resurrection") }
        result.Passed=len(result.Failures)==0
    }()
    switch s.Special {
    case "": runOrdinary(r,s)
    case "queue-items","queue-bytes": runQueueOverflow(r,s)
    case "cancel-before-open","cancel-pending-open","cancel-open","shared": runCancelled(r,s)
    case "reopen": runReopen(r,s)
    default: panic("unknown special fixture "+s.Special)
    }
    return
}
func writeJSON(name string,value any) { data,err:=json.MarshalIndent(value,"","  "); must(err); must(os.WriteFile(name,append(data,'\n'),0600)) }
func main() {
    // Safety deadline only. All intentional interleavings use channels/events;
    // the deadline is never counted as an observed ordering success.
    watchdog:=time.AfterFunc(90*time.Second,func(){ fmt.Fprintln(os.Stderr,"unexpected safety timeout"); os.Exit(2) }); defer watchdog.Stop()
    data,err:=os.ReadFile("scenarios.json"); must(err); var scenarios []Scenario; must(json.Unmarshal(data,&scenarios))
    cwd,err:=os.Getwd(); must(err)
    report:=Report{Probe:"source lifecycle/flow loopback confirmation",Command:"cd "+cwd+" && GOWORK=off go run .",GoVersion:runtime.Version(),Platform:runtime.GOOS+"/"+runtime.GOARCH,Passed:true,SourceHashes:map[string]string{},Limits:map[string]int{"uncompressedFramePayloadBytes":wireLimit,"prefixBytes":4,"maxBatchItems":batchLimit,"writerQueueItemsIncludingInFlight":defaultQueueItems,"writerQueueBytesIncludingInFlight":defaultQueueBytes,"byteOverflowCaseQueueBytes":2048,"stagedItems":stageItemLimit,"stagedSerializedObservationBytes":stageByteLimit,"retainedSourceCacheItems":retainedItemLimit,"retainedSerializedObservationBytes":retainedByteLimit,"socketSafetyDeadlineSeconds":5,"processSafetyDeadlineSeconds":90},Measurements:map[string]int{}}
    report.Limitations=[]string{
        "Real transport means local tcp4 loopback with an uncompressed uint32-big-endian length prefix and JSON, not SDK gRPC/protobuf/Wails or a native cloud/Kubernetes provider. Native endpoints are per-case socket addresses, not real provider service URLs.",
        "Small trusted-host coordinator, deterministic scripted provider fixture, one bound selection/access-qualified representation; no hostile-plugin process or decoder isolation proof. Wire bound limits peer-controlled payload allocation, not every JSON decoder overhead allocation or total Go heap/RSS.",
        "Queue bytes include prefix and in-flight packet until write finishes. A bounded candidate serialization exists outside the queue; raw input and harness transcripts are fixtures, not bounded production ingestion. Raw/error fixture barrier contributes an intentionally zero-byte queue item but is not sent on wire. Fixture-only writer completion and host admission events schedule cases; they are not transport ACKs or product control messages.",
        "Source staging and retained source-cache serialized-byte bounds are enforced. Batch length is checked before full observation/change decode, but bounded frame-envelope RawMessage metadata is decoded first. Decoded Go heap overhead, processing-time budgets, native producer backpressure under OS socket-buffer saturation, throughput/latency, many-source concurrency and query-consumer lag are not measured.",
        "No native gap-free or point-in-time claim: all successful fixture boundaries declare bestEffort consistency; finite mode continuity is notApplicable. Contiguous frame sequences do not establish native freshness.",
        "Old source cache entries retained by partial/unknown replacement remain separately stale and absent from current-generation observations. This is a single-source membership prototype, not cross-source body arbitration, global object deletion or authorization-cache invalidation policy.",
        "Unimplemented DTO surfaces: full SourceOpen decoding/capability negotiation/nativeQuery/request validation/limits negotiation; arbitrary normalized QueryScope dimensions/any/oneOf/empty-oneOf; optional/alternative schema binding; displayName; nonempty typed DocumentCoverage.knownAbsent paths and present/absent contradiction validation; all SourceError codes other than unavailable; field-exact discriminated-union/unknown-field rejection. Supported DTO subset uses fixed provider/authority/type/scope/schema/access context and rejects unsupported knownAbsent facts.",
        "Canonical UInt64Text grammar, out-of-range values and max-value-without-history are exercised over TCP. A real contiguous history reaching uint64 max and arithmetic wrap branch are infeasible here and not claimed exercised.",
        "Cancellation/open races use host-side channel barriers; stale-frame case serializes and decodes the old frame through its socket before holding its callback until new generation admission. Some lifecycle operations are necessarily local methods; no fake in-memory transport is called IPC.",
        "No query evaluator/result generations/windowing, UI/JS integration, SDK bindings, credentials, real access changes, public resume, durable ACK/replay or heartbeat machinery. No automatic retries; recovery fixture explicitly performs one new-generation resnapshot.",
        "Only probe-owned listeners, socket endpoints, reader/writer goroutines, reservations, queued/staged/cache state are accounted. Zero active tracked workers after join is not a claim that runtime.NumGoroutine globally equals a fixed value. Socket deadlines are safety exits, never ordering evidence.",
    }
    report.Counterexamples=[]string{
        "Partial snapshot with old cached member retains that member only as stale cache, not current membership or phantom deletion.",
        "Unexpected EOF before finite completion or after an updates boundary invalidates continuity; only EOF following finite snapshotEnd is successful.",
        "Full item/byte queues cannot carry a terminal reset; independent transport closure still invalidates the host, without queue reservation or custom ACK machinery.",
        "A known old-incarnation membership removal cannot erase a recreated observation; incompatible batches cannot partly publish.",
        "Late cancelled-open callbacks cannot allocate source readers; decoded old-generation frames cannot mutate a fresh generation.",
    }
    for _,name:=range []string{"go.mod","main.go","probe.go","scenarios.json"} { content,err:=os.ReadFile(name); must(err); sum:=sha256.Sum256(content); report.SourceHashes[name]=hex.EncodeToString(sum[:]) }
    allWires:=[]WireInput{}
    for _,scenario:=range scenarios {
        result,wires:=execute(scenario); report.Cases=append(report.Cases,result); report.Assertions+=result.Assertions; allWires=append(allWires,wires...)
        if !result.Passed { report.Passed=false; report.UnexpectedFailures+=len(result.Failures) }
        for _,key:=range []string{"queuePeakItems","queuePeakBytes","stagePeakItems","stagePeakBytes","maxAllocatedPayload"} { report.Measurements[key]=max(report.Measurements[key],result.Actual[key].(int)) }
        for _,key:=range []string{"wireFrames","payloadAllocations","payloadAllocatedBytes","readerStarts","writerStarts","lateFramesRejected","lateCallbacksRejected","overflowCount","cleanup_socketEndpointsClosed"} { report.Measurements[key+"Total"]+=result.Actual[key].(int) }
    }
    if previous,err:=os.ReadFile("results.json"); err==nil {
        var prior Report
        if json.Unmarshal(previous,&prior)==nil && !prior.Passed { if _,err:=os.Stat("initial-failed-results.json"); os.IsNotExist(err) { must(os.WriteFile("initial-failed-results.json",previous,0600)) } }
    }
    writeJSON("wire-inputs.json",allWires); writeJSON("results.json",report)
    var text strings.Builder
    fmt.Fprintf(&text,"# Source lifecycle/flow confirmation probe\n\nReproduce exactly:\n\n```sh\n%s\n```\n\nObserved Go: `%s`; platform `%s`. Standard library only.\n\nResult: **%t**, %d cases, %d assertions, %d unexpected failures. This is feasibility evidence, not product implementation.\n\n## Artifacts and transport\n\n`scenarios.json` is the canonical input/expected fixture manifest; `wire-inputs.json` records actual serialized payload text, prefix hex, queue admission and native generation for every attempted wire packet. `results.json` contains per-case expected/actual values, exact queue/staging/transport counters, native loopback endpoints, cleanup counters, assertions, source SHA-256 hashes and limitations. `main.go`, `probe.go`, and `go.mod` are the complete runnable source/module. Re-running overwrites actual results; any prior unexpected semantic failure is preserved as `initial-failed-results.json`.\n\nThe native endpoints here are OS-allocated TCP addresses on `127.0.0.1`, not real provider endpoints. Each case records its actual listener/provider/host addresses. Core admission, phase, sequence, size, EOF, queue-overflow, reset/reopen and stale-frame cases cross real serialized sockets. Cancel-before/pending-open cases establish sockets but deliberately never start a reader.\n\n## Limits\n\n",report.Command,report.GoVersion,report.Platform,report.Passed,len(report.Cases),report.Assertions,report.UnexpectedFailures)
    keys:=make([]string,0,len(report.Limits)); for k:=range report.Limits { keys=append(keys,k) }; sort.Strings(keys)
    for _,k:=range keys { fmt.Fprintf(&text,"- `%s`: %d\n",k,report.Limits[k]) }
    text.WriteString("\n## Exact observed aggregate measurements\n\n")
    keys=keys[:0]; for k:=range report.Measurements { keys=append(keys,k) }; sort.Strings(keys)
    for _,k:=range keys { fmt.Fprintf(&text,"- `%s`: %d\n",k,report.Measurements[k]) }
    text.WriteString("\nEach queue peak counts both queued and in-flight packets. Item saturation and byte saturation have separate scheduled cases. The byte peak is serialized transport bytes, not Go heap memory. Every case asserts final interests/reservations/handles/readers/writers/queue/staging/retained source cache are zero after final release; published outcomes are captured before releasing finite/shared state. Separate local cache/current maps prevent partial coverage from promoting stale rows.\n\n## Cases\n\n| Case | Classification | Expected terminal | Actual terminal | Pass |\n| --- | --- | --- | --- | --- |\n")
    for _,c:=range report.Cases { fmt.Fprintf(&text,"| %s | %s | %v | %v | %t |\n",c.Name,c.Classification,c.Expected["terminal"],c.Actual["terminal"],c.Passed) }
    text.WriteString("\n## Expected counterexamples (not successful provider capabilities)\n\n"); for _,s:=range report.Counterexamples { text.WriteString("- "+s+"\n") }
    text.WriteString("\n## Limitations and unimplemented DTO surfaces\n\n"); for _,s:=range report.Limitations { text.WriteString("- "+s+"\n") }
    if report.UnexpectedFailures>0 { text.WriteString("\n## Unexpected failures\n\n"); for _,c:=range report.Cases { for _,failure:=range c.Failures { fmt.Fprintf(&text,"- `%s`: %s\n",c.Name,failure) } } }
    must(os.WriteFile(filepath.Join(cwd,"report.md"),[]byte(text.String()),0600))
    fmt.Printf("lifecycle: passed=%t cases=%d assertions=%d unexpectedFailures=%d go=%s\n",report.Passed,len(report.Cases),report.Assertions,report.UnexpectedFailures,report.GoVersion)
    if !report.Passed { for _,c:=range report.Cases { for _,failure:=range c.Failures { fmt.Printf("FAIL %s: %s\n",c.Name,failure) } }; os.Exit(1) }
}
