module source-lifecycle-probe

go 1.26.1
