# Parent source-session verification

Accepted contract: docs/superpowers/specs/2026-10-17-source-session-contract.md. These artifacts are throwaway investigation evidence, not production source/read-model code.

## Actually executed by parent

- From cutover/: `GOWORK=off go run .` -> 168 assertions passed, 0 failed, 25 scenarios; two are explicitly expected counterexample/limitation records rather than native capabilities.
- From lifecycle/: `GOWORK=off go run -race .` -> passed=true, 57 cases, 1415 assertions, zero unexpected failures; process exit 0 and no race detector report observed. That finite workload does not prove race freedom for every schedule. Original agent run used `GOWORK=off go run .` with the same assertion/case counts. Runtime Go go1.26.1 darwin/arm64, standard library only.
- Parent inspected source/fixture hashes, case classifications, real socket endpoints and cleanup/queue counters, and the read-before-allocation and independent-close implementation paths.

## Interpretation

Cutover's strong fixture assumes a true native immutable snapshot/cursor chain and independently authored expected native histories. It is conditional adapter feasibility, not evidence that any actual cloud API supplies those guarantees. The weak subscribe/list/buffer/replay fixture really returns stale data under contiguous source frame numbers; missing incarnation evidence really permits an old remove to erase a recreated host view. Neither is hidden as a successful fix.

The lifecycle probe actually uses OS tcp4 loopback, 4-byte big-endian lengths and JSON. Oversized length prefixes are rejected before allocating a payload buffer (not before every possible Go allocation). Item and byte overflow use independent socket closure, not a reset waiting for space in the full queue. Queue accounting includes in-flight serialized packets; peaks and source staging are logical serialized-byte counts, not Go heap/RSS or production performance measurements.

Measured lifecycle aggregate: 117 decoded wire frames; 116 socket endpoints observably closed; queue peak 2 items / 2503 bytes; staged peak 4 observations / 2157 serialized bytes. Every final case asserts zero probe-owned reservations/handles/readers/writers/queues/staging/retained cache. Two late open callbacks and one already-decoded stale-generation frame were rejected. Actual endpoints and individual limits are in results.json/report.md.

Partial/unknown replacement preserves unseen old observations only in separate stale cache with old generation provenance; they are not promoted into current-generation published rows. Source-owned membership removal does not destroy another source's data. Authorization/access invalidation is not implemented or proven by fixture principal labels.

## Do not copy prototype internals as architecture

The fixture transcript retains frames/historical views for evidence, not as a bounded production replay log. Small clone/staging routines, native simulator history and exhaustive fixture comparisons are not performance guidance. Production must separately measure allocation/retention and avoid inventory-wide work per small update.

Lifecycle's admission notifications and writer gates are fixture-only scheduling barriers, not a product ACK/control protocol. This probe does not establish cancellation of an arbitrarily saturated notification/consumer path. Production control/termination paths must remain independently cancellable and bounded, including diagnostics.

The finite receiver deliberately waits for EOF after snapshotEnd to observe illegal post-terminal fixture frames. The contract's finite boundary itself establishes success. Do not infer that holding a completed source socket until remote EOF is required or that a stalled peer's finite-handle retirement was proven; production teardown must be explicit and bounded.

No full SourceOpen negotiation/nativeQuery admission, general QueryScope any/oneOf/empty-oneOf normalization, strict exhaustive DTO union validation, every SourceError code or general schema adapter was exercised. Cutover checks selected typed knownAbsent contradictions; lifecycle rejects unsupported nonempty knownAbsent paths. Those are different supported probe subsets, not one integrated protocol implementation.

No real native provider, SDK gRPC/protobuf/Wails binding, query evaluator/result-generation/window pipeline, UI/JS behavior, many-source load or production latency/RSS was exercised. Both probes remain independent. Real SDK transport conformance and integrated ingestion -> query result/reset proof are next implementation gates; no custom replay/resume/heartbeat subsystem is justified by this evidence.

## Reproduction

Run the commands above from their subdirectories; outputs regenerate results/reports. Modules are stdlib-only and fixtures/source identities are recorded. Archive excludes executables/caches. The shared contract.md preserves original probe expectations. Known counterexamples and unexercised surfaces must remain visible when interpreting passing assertions.
