package main

import (
	"encoding/json"
	"fmt"
	"sort"
	"strconv"
	"strings"
	"sync"

	"cel.dev/cel-go/cel"
	"cel.dev/cel-go/common/types"
)

// Throwaway host integration, not a general planner, ABI or production index.
const windowSize = 2
const resultQueueItems = 2
const resultQueueBytes = 4096
const controlBytes = 1024

type Row struct {
	Key   string `json:"key"`
	ID    string `json:"id"`
	Rank  string `json:"rank"`
	Title string `json:"title"`
}
type orderedRow struct {
	Row
	rank int64
}
type ResultFrame struct {
	Lease          string `json:"lease"`
	Generation     string `json:"generation"`
	Sequence       string `json:"sequence"`
	Kind           string `json:"kind"`
	Rows           []Row  `json:"rows,omitempty"`
	NextGeneration string `json:"nextGeneration,omitempty"`
	Reason         string `json:"reason,omitempty"`
}
type query struct {
	id, wanted, generation, pending  string
	epoch, sequence                  uint64
	members                          map[string]orderedRow
	order                            []orderedRow
	last                             []Row
	queue                            [][]byte
	queueBytes, peakItems, peakBytes int
	control                          *ResultFrame
	paused                           bool
	evaluations, publications        int
}
type Trace struct {
	Op         string          `json:"op"`
	Lease      string          `json:"lease,omitempty"`
	Generation string          `json:"generation,omitempty"`
	Data       json.RawMessage `json:"data,omitempty"`
	Name       string          `json:"name,omitempty"`
}
type Engine struct {
	mu                                                   sync.Mutex
	source                                               *Coordinator
	sourceGeneration                                     string
	synced                                               bool
	program                                              cel.Program
	queries                                              map[string]*query
	trace                                                []Trace
	compiled, evaluations, overflow, discarded, peakRows int
	incrementalEvaluations                               int
	batches                                              []map[string]any
	failure                                              error
}

func newEngine(c *Coordinator) (*Engine, error) {
	env, err := cel.NewEnv(cel.Variable("resource", cel.MapType(cel.StringType, cel.DynType)), cel.Variable("wanted", cel.StringType))
	if err != nil {
		return nil, err
	}
	a, issues := env.Compile("has(resource.state) && resource.state == wanted")
	if issues.Err() != nil {
		return nil, issues.Err()
	}
	if a.OutputType() != cel.BoolType {
		return nil, fmt.Errorf("predicate is not checked bool")
	}
	p, err := env.Program(a, cel.CostLimit(10000))
	if err != nil {
		return nil, err
	}
	e := &Engine{source: c, program: p, compiled: 1, queries: map[string]*query{}}
	c.afterApply = e.afterFrame
	c.afterTerminal = e.afterTerminal
	return e, nil
}
func resultGeneration(id string, epoch uint64) string { return fmt.Sprintf("result-%s-%d", id, epoch) }
func (e *Engine) Open(id, wanted string) string {
	e.mu.Lock()
	defer e.mu.Unlock()
	if e.queries[id] != nil || !e.source.Acquire() {
		panic("invalid lease open")
	}
	q := &query{id: id, wanted: wanted, epoch: 1, generation: resultGeneration(id, 1), members: map[string]orderedRow{}}
	e.queries[id] = q
	e.trace = append(e.trace, Trace{Op: "open", Lease: id, Generation: q.generation})
	return q.generation
}
func (e *Engine) Close(id string) {
	e.mu.Lock()
	defer e.mu.Unlock()
	if e.queries[id] == nil {
		return
	}
	delete(e.queries, id)
	e.trace = append(e.trace, Trace{Op: "close", Lease: id})
	e.source.Release()
}
func (e *Engine) Bind(generation string) {
	e.mu.Lock()
	defer e.mu.Unlock()
	e.sourceGeneration = generation
	e.synced = false
}
func (e *Engine) reset(q *query, reason string) {
	e.discarded += len(q.queue)
	q.queue = nil
	q.queueBytes = 0
	q.paused = true
	if q.control != nil {
		q.pending = q.control.NextGeneration
		return
	}
	q.epoch++
	q.pending = resultGeneration(q.id, q.epoch)
	q.sequence++
	f := ResultFrame{Lease: q.id, Generation: q.generation, Sequence: strconv.FormatUint(q.sequence, 10), Kind: "reset", NextGeneration: q.pending, Reason: reason}
	data, err := json.Marshal(f)
	if err != nil || len(data) > controlBytes {
		panic("unbounded reset control")
	}
	q.control = &f
}
func (e *Engine) invalidate(reason string) {
	if !e.synced {
		return
	}
	e.synced = false
	for _, q := range e.queries {
		e.reset(q, reason)
		q.members = map[string]orderedRow{}
		q.order = nil
		q.last = nil
	}
}
func (e *Engine) afterTerminal(generation string) {
	c := e.source
	c.mu.Lock()
	current, terminal := c.generation, c.terminal
	c.mu.Unlock()
	e.mu.Lock()
	defer e.mu.Unlock()
	if generation != current || generation != e.sourceGeneration {
		return
	}
	if terminal != "" && terminal != "finished" {
		e.invalidate(terminal)
	}
}
func (e *Engine) afterFrame(generation string, f Frame, accepted bool) {
	c := e.source
	c.mu.Lock()
	current, phase, terminal := c.generation, c.phase, c.terminal
	view, changes := c.current, c.appliedChanges
	c.mu.Unlock()
	e.mu.Lock()
	defer e.mu.Unlock()
	if generation != current || generation != e.sourceGeneration {
		return
	}
	if !accepted || phase == "resetRequired" || phase == "failed" {
		e.invalidate(terminal)
		return
	}
	if f.Payload.Kind != "snapshotEnd" && f.Payload.Kind != "changes" {
		return
	}
	ids := make([]string, 0, len(e.queries))
	for id := range e.queries {
		ids = append(ids, id)
	}
	sort.Strings(ids)
	before := e.evaluations
	if f.Payload.Kind == "snapshotEnd" {
		e.synced = true
		for _, id := range ids {
			q := e.queries[id]
			q.members = map[string]orderedRow{}
			q.order = nil
			for _, o := range view {
				if err := e.evaluate(q, key(o.Address), o, true); err != nil {
					e.failure = err
					return
				}
			}
			e.publish(q, true)
		}
	} else {
		touched := map[string]struct{}{}
		for _, ch := range changes {
			if ch.Kind == "upsert" {
				touched[key(ch.Observation.Address)] = struct{}{}
			} else {
				touched[key(*ch.Address)] = struct{}{}
			}
		}
		for _, id := range ids {
			q := e.queries[id]
			for k := range touched {
				o, exists := view[k]
				if err := e.evaluate(q, k, o, exists); err != nil {
					e.failure = err
					return
				}
			}
			if !q.paused {
				e.publish(q, false)
			}
		}
		e.incrementalEvaluations += e.evaluations - before
		e.batches = append(e.batches, map[string]any{"sourceGeneration": generation, "sourceSequence": f.Sequence, "touchedResources": len(touched), "activeQueries": len(ids), "CELInvocations": e.evaluations - before})
	}
}
func less(a, b orderedRow) bool {
	if a.rank != b.rank {
		return a.rank < b.rank
	}
	return a.Key < b.Key
}
func (e *Engine) evaluate(q *query, k string, o Observation, exists bool) error {
	// Remove the previous membership/index entry before inserting its replacement.
	if _, found := q.members[k]; found {
		for i, row := range q.order {
			if row.Key == k {
				copy(q.order[i:], q.order[i+1:])
				q.order = q.order[:len(q.order)-1]
				break
			}
		}
		delete(q.members, k)
	}
	if !exists {
		return nil
	}
	var body map[string]any
	d := json.NewDecoder(strings.NewReader(o.Document.Text))
	d.UseNumber()
	if err := d.Decode(&body); err != nil {
		return err
	}
	q.evaluations++
	e.evaluations++
	v, _, err := e.program.Eval(map[string]any{"resource": body, "wanted": q.wanted})
	if err != nil {
		return err
	}
	b, ok := v.(types.Bool)
	if !ok {
		return fmt.Errorf("nonbool result %v", v)
	}
	if !bool(b) {
		return nil
	}
	n, ok := body["rank"].(json.Number)
	if !ok {
		return fmt.Errorf("rank not exact integer")
	}
	rank, err := n.Int64()
	if err != nil {
		return err
	}
	title, ok := body["title"].(string)
	if !ok {
		return fmt.Errorf("title not string")
	}
	row := orderedRow{Row: Row{Key: k, ID: o.Address.ID, Rank: strconv.FormatInt(rank, 10), Title: title}, rank: rank}
	q.members[k] = row
	at := sort.Search(len(q.order), func(i int) bool { return !less(q.order[i], row) })
	q.order = append(q.order, orderedRow{})
	copy(q.order[at+1:], q.order[at:])
	q.order[at] = row
	return nil
}
func (q *query) window() []Row {
	n := min(windowSize, len(q.order))
	out := make([]Row, n)
	for i := range n {
		out[i] = q.order[i].Row
	}
	return out
}
func (q *query) windowUnchanged() bool {
	n := min(windowSize, len(q.order))
	if len(q.last) != n {
		return false
	}
	for i := range n {
		if q.last[i] != q.order[i].Row {
			return false
		}
	}
	return true
}
func (e *Engine) publish(q *query, snapshot bool) {
	if !snapshot && q.windowUnchanged() {
		return
	}
	rows := q.window()
	if snapshot {
		if q.pending != "" {
			q.generation = q.pending
			q.pending = ""
		}
		q.sequence = 0
		q.paused = false
	}
	q.sequence++
	kind := "replace"
	if snapshot {
		kind = "snapshot"
	}
	f := ResultFrame{Lease: q.id, Generation: q.generation, Sequence: strconv.FormatUint(q.sequence, 10), Kind: kind, Rows: rows}
	data, err := json.Marshal(f)
	if err != nil {
		panic(err)
	}
	e.peakRows = max(e.peakRows, len(rows))
	if len(q.queue)+1 > resultQueueItems || q.queueBytes+len(data) > resultQueueBytes {
		e.overflow++
		e.discarded++
		e.reset(q, "consumerOverflow")
		return
	}
	q.queue = append(q.queue, data)
	q.queueBytes += len(data)
	q.peakItems = max(q.peakItems, len(q.queue))
	q.peakBytes = max(q.peakBytes, q.queueBytes)
	q.publications++
	q.last = append(q.last[:0], rows...)
}
func (e *Engine) Resume(id string) {
	e.mu.Lock()
	defer e.mu.Unlock()
	q := e.queries[id]
	if !e.synced || q == nil || !q.paused {
		panic("invalid resnapshot")
	}
	e.publish(q, true)
}
func (e *Engine) Drain(id string) [][]byte {
	e.mu.Lock()
	defer e.mu.Unlock()
	q := e.queries[id]
	if q == nil {
		return nil
	}
	out := make([][]byte, 0, len(q.queue)+1)
	if q.control != nil {
		data, err := json.Marshal(q.control)
		if err != nil {
			panic(err)
		}
		out = append(out, data)
		q.control = nil
	}
	out = append(out, q.queue...)
	q.queue = nil
	q.queueBytes = 0
	for _, data := range out {
		e.trace = append(e.trace, Trace{Op: "frame", Lease: id, Data: json.RawMessage(data)})
	}
	return out
}
func (e *Engine) InjectStale(id string, f ResultFrame) []byte {
	data, err := json.Marshal(f)
	if err != nil {
		panic(err)
	}
	e.mu.Lock()
	defer e.mu.Unlock()
	e.trace = append(e.trace, Trace{Op: "frame", Lease: id, Data: json.RawMessage(data)})
	return data
}
func (e *Engine) Metrics() map[string]any {
	e.mu.Lock()
	defer e.mu.Unlock()
	if e.failure != nil {
		panic(e.failure)
	}
	qs := map[string]any{}
	for id, q := range e.queries {
		qs[id] = map[string]any{"generation": q.generation, "sequence": q.sequence, "members": len(q.members), "CELInvocations": q.evaluations, "publishedFrames": q.publications, "peakQueuedItems": q.peakItems, "peakQueuedBytes": q.peakBytes, "queuedItems": len(q.queue), "queuedBytes": q.queueBytes, "paused": q.paused}
	}
	return map[string]any{"compiledPrograms": e.compiled, "CELInvocations": e.evaluations, "incrementalCELInvocations": e.incrementalEvaluations, "consumerOverflows": e.overflow, "discardedDeliveryFrames": e.discarded, "maxDeliveredRows": e.peakRows, "activeQueries": len(e.queries), "sourceGeneration": e.sourceGeneration, "queries": qs, "batches": e.batches}
}

// Passive reference client: apply bounded replacements; never evaluate/filter/sort.
type Replica struct {
	ID             string
	Generation     string
	Expected       string
	Sequence       uint64
	Synced, Closed bool
	Rows           []Row
	Ignored        int
}

func (r *Replica) Apply(data []byte) error {
	var f ResultFrame
	if err := json.Unmarshal(data, &f); err != nil {
		return err
	}
	if r.Closed || f.Lease != r.ID {
		r.Ignored++
		return nil
	}
	seq, ok := canonicalSequence(f.Sequence)
	if !ok || seq == 0 {
		return fmt.Errorf("invalid result sequence")
	}
	if f.Kind == "reset" {
		if f.Generation != r.Generation {
			r.Ignored++
			return nil
		}
		if f.NextGeneration == "" || f.NextGeneration == r.Generation {
			return fmt.Errorf("invalid reset target")
		}
		r.Sequence = seq
		r.Expected = f.NextGeneration
		r.Synced = false
		r.Rows = nil
		return nil
	}
	if f.Kind == "snapshot" {
		if f.Generation != r.Expected {
			r.Ignored++
			return nil
		}
		if seq != 1 {
			return fmt.Errorf("snapshot sequence")
		}
		r.Generation = f.Generation
		r.Expected = ""
		r.Sequence = 1
		r.Synced = true
	} else if f.Kind == "replace" {
		if f.Generation != r.Generation || !r.Synced {
			r.Ignored++
			return nil
		}
		if seq != r.Sequence+1 {
			r.Rows = nil
			r.Synced = false
			return fmt.Errorf("result gap")
		}
		r.Sequence = seq
	} else {
		return fmt.Errorf("unknown result frame")
	}
	if len(f.Rows) > windowSize {
		return fmt.Errorf("unbounded window")
	}
	r.Rows = f.Rows
	return nil
}
func (r *Replica) State() map[string]any {
	rows := []string{}
	for _, row := range r.Rows {
		rows = append(rows, row.ID+":"+row.Rank+":"+row.Title)
	}
	return map[string]any{"rows": rows, "generation": r.Generation, "sequence": strconv.FormatUint(r.Sequence, 10), "synced": r.Synced, "closed": r.Closed, "ignoredFrames": r.Ignored}
}
