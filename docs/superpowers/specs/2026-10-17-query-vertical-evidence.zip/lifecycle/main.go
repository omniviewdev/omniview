package main

import (
	"encoding/json"
	"fmt"
	"os"
	"runtime"
	"strconv"
	"time"
)

type check struct {
	Name     string `json:"name"`
	Expected any    `json:"expected"`
	Actual   any    `json:"actual"`
	Pass     bool   `json:"pass"`
}
type runner struct {
	c           *Coordinator
	e           *Engine
	clients     map[string]*Replica
	expected    map[string]map[string]map[string]any
	checks      []check
	checkpoints map[string]any
	frames      []Frame
	endpoints   []Endpoint
	queues      []*WriterQueue
}

func encoded(v any) []byte {
	data, err := json.Marshal(v)
	if err != nil {
		panic(err)
	}
	return data
}
func writeJSON(file string, v any) {
	data, err := json.MarshalIndent(v, "", "  ")
	if err != nil {
		panic(err)
	}
	if err = os.WriteFile(file, data, 0600); err != nil {
		panic(err)
	}
}
func (r *runner) assert(name string, want, actual any) {
	r.checks = append(r.checks, check{name, want, actual, string(encoded(want)) == string(encoded(actual))})
}
func (r *runner) drain(id string) {
	for _, data := range r.e.Drain(id) {
		if err := r.clients[id].Apply(data); err != nil {
			panic(err)
		}
	}
}
func (r *runner) checkpoint(name string) {
	actual := map[string]any{}
	for _, id := range []string{"A", "B"} {
		state := r.clients[id].State()
		actual[id] = state
		for field, want := range r.expected[name][id] {
			r.assert(name+"/"+id+"/"+field, want, state[field])
		}
	}
	r.checkpoints[name] = actual
	r.e.mu.Lock()
	r.e.trace = append(r.e.trace, Trace{Op: "checkpoint", Name: name})
	r.e.mu.Unlock()
}
func (r *runner) event(generation, kind string) {
	safety := time.NewTimer(3 * time.Second)
	defer safety.Stop()
	for {
		select {
		case event := <-r.c.events:
			if event.Generation == generation && event.Kind == kind {
				return
			}
		case <-safety.C:
			panic("safety timeout waiting for " + generation + "/" + kind)
		}
	}
}
func (r *runner) openSource(generation string) *WriterQueue {
	r.e.Bind(generation)
	if !r.c.Reserve(generation, "snapshotAndUpdates") {
		panic("source reservation failed")
	}
	host, remote, endpoint, err := SocketPair()
	if err != nil {
		panic(err)
	}
	r.endpoints = append(r.endpoints, endpoint)
	if !r.c.Attach(generation, host) {
		panic("source attachment failed")
	}
	queue := NewWriterQueue(remote, 2, 16384)
	r.queues = append(r.queues, queue)
	return queue
}
func (r *runner) send(queue *WriterQueue, generation string, seq int, p Payload) {
	f := Frame{Session: "session-1", Generation: generation, Sequence: strconv.Itoa(seq), Payload: p}
	r.frames = append(r.frames, f)
	if !queue.Enqueue(NewPacket(encoded(f))) {
		panic("unexpected source writer overflow")
	}
	r.event(generation, p.Kind)
}
func observation(id, state string, rank int64, title string) Observation {
	return Observation{Address: Address{Provider: "fixture", Authority: "local-account", Type: "machine", Scope: map[string]string{"environment": "prod"}, ID: id}, Representation: Representation{ID: "summary", Schema: Schema{ID: "machine-schema", Revision: "r1"}}, Document: Document{Encoding: "json", Text: fmt.Sprintf(`{"state":%q,"rank":%d,"title":%q}`, state, rank, title)}, Coverage: DocumentCoverage{Kind: "complete"}, Incarnation: "inc-" + id, Revision: "opaque:" + title}
}
func snapshot(observations ...Observation) Payload {
	raw := []json.RawMessage{}
	for _, o := range observations {
		raw = append(raw, encoded(o))
	}
	return Payload{Kind: "snapshot", Observations: raw}
}
func upsert(o Observation) Change { return Change{Kind: "upsert", Observation: &o} }
func remove(id string) Change {
	a := observation(id, "", 0, "").Address
	return Change{Kind: "remove", Address: &a, Incarnation: "inc-" + id}
}
func updates(changes ...Change) Payload {
	raw := []json.RawMessage{}
	for _, ch := range changes {
		raw = append(raw, encoded(ch))
	}
	return Payload{Kind: "changes", Changes: raw}
}
func boundary() Payload {
	return Payload{Kind: "snapshotEnd", Continuity: "bestEffort", Coverage: &Coverage{Enumeration: "exhausted", Consistency: "bestEffort", Limitations: []string{"scripted source, not a native ordering guarantee"}}}
}
func main() {
	expectedData, err := os.ReadFile("expected.json")
	if err != nil {
		panic(err)
	}
	c := NewCoordinator("snapshotAndUpdates", nil)
	engine, err := newEngine(c)
	if err != nil {
		panic(err)
	}
	r := &runner{c: c, e: engine, clients: map[string]*Replica{}, checkpoints: map[string]any{}}
	if err = json.Unmarshal(expectedData, &r.expected); err != nil {
		panic(err)
	}
	for _, request := range []struct{ id, wanted string }{{"A", "ready"}, {"B", "stopped"}} {
		g := engine.Open(request.id, request.wanted)
		r.clients[request.id] = &Replica{ID: request.id, Generation: g, Expected: g}
	}
	q1 := r.openSource("source-epoch-alpha")
	r.send(q1, "source-epoch-alpha", 1, Payload{Kind: "begin", Mode: "snapshotAndUpdates"})
	r.send(q1, "source-epoch-alpha", 2, snapshot(observation("a", "ready", 30, "a"), observation("b", "stopped", 20, "b"), observation("c", "ready", 10, "c"), observation("d", "ready", 15, "d")))
	r.drain("A")
	r.drain("B")
	r.checkpoint("staged")
	r.send(q1, "source-epoch-alpha", 3, boundary())
	r.drain("A")
	r.drain("B")
	r.checkpoint("initial")
	r.assert("one acquisition for two bound queries", 1, c.Snapshot()["readerStarts"])
	r.assert("two source interests", 2, c.Snapshot()["interests"])
	r.send(q1, "source-epoch-alpha", 4, updates(upsert(observation("b", "ready", 5, "b"))))
	r.drain("A")
	r.drain("B")
	r.checkpoint("enter")
	r.send(q1, "source-epoch-alpha", 5, updates(upsert(observation("a", "ready", 1, "a"))))
	r.drain("A")
	r.drain("B")
	r.checkpoint("reorder")
	r.send(q1, "source-epoch-alpha", 6, updates(remove("a")))
	r.drain("A")
	r.drain("B")
	r.checkpoint("delete")
	r.send(q1, "source-epoch-alpha", 7, updates(upsert(observation("d", "stopped", 7, "d")), upsert(observation("c", "stopped", 8, "c"))))
	r.drain("A")
	r.drain("B")
	r.checkpoint("atomic")
	r.send(q1, "source-epoch-alpha", 8, updates(upsert(observation("e", "ready", 5, "e"))))
	r.drain("A")
	r.drain("B")
	r.checkpoint("tie")
	r.send(q1, "source-epoch-alpha", 9, updates(upsert(observation("b", "ready", 50, "b"))))
	r.drain("A")
	r.drain("B")
	r.checkpoint("priority")
	r.send(q1, "source-epoch-alpha", 10, updates(upsert(observation("e", "ready", 5, "renamed-e"))))
	r.drain("A")
	r.drain("B")
	r.checkpoint("projection")
	r.send(q1, "source-epoch-alpha", 12, updates(upsert(observation("b", "stopped", 0, "must-not-publish"))))
	r.drain("A")
	r.drain("B")
	r.checkpoint("reset")
	c.wg.Wait()
	q1.Close()
	<-q1.stopped
	q2 := r.openSource("source-epoch-beta")
	r.send(q2, "source-epoch-beta", 1, Payload{Kind: "begin", Mode: "snapshotAndUpdates"})
	r.send(q2, "source-epoch-beta", 2, snapshot(observation("x", "stopped", 2, "x"), observation("y", "ready", 9, "y")))
	r.send(q2, "source-epoch-beta", 3, boundary())
	r.drain("A")
	r.drain("B")
	r.checkpoint("recovered")
	// Already-scheduled old callbacks are local negative controls, not a new wire stream.
	stale := Frame{Session: "session-1", Generation: "source-epoch-alpha", Sequence: "13", Payload: updates(upsert(observation("z", "ready", 0, "poison")))}
	accepted := c.apply("source-epoch-alpha", stale)
	engine.afterFrame("source-epoch-alpha", stale, accepted)
	r.assert("stale source callback rejected", false, accepted)
	poison := ResultFrame{Lease: "A", Generation: "result-A-1", Sequence: "1", Kind: "snapshot", Rows: []Row{{Key: "poison", ID: "poison", Rank: "0", Title: "poison"}}}
	if err = r.clients["A"].Apply(engine.InjectStale("A", poison)); err != nil {
		panic(err)
	}
	r.checkpoint("stale-result")
	// A drains normally; B deliberately leaves its bounded result queue unread.
	for i, rank := range []int64{3, 4, 5} {
		r.send(q2, "source-epoch-beta", 4+i, updates(upsert(observation("x", "stopped", rank, "x"))))
		r.drain("A")
	}
	r.drain("B")
	r.checkpoint("slow-overflow")
	r.assert("overflow is per consumer", 1, engine.Metrics()["consumerOverflows"])
	r.assert("slow consumer did not reopen source", 2, c.Snapshot()["readerStarts"])
	r.assert("slow consumer retained shared interests", 2, c.Snapshot()["interests"])
	engine.Resume("B")
	r.drain("B")
	r.checkpoint("resumed")
	engine.Close("A")
	r.clients["A"].Closed = true
	r.clients["A"].Synced = false
	r.clients["A"].Rows = nil
	r.checkpoint("one-closed")
	r.assert("one close retains shared source", 1, c.Snapshot()["interests"])
	r.assert("source reader remains active", 1, c.Snapshot()["readersActive"])
	r.send(q2, "source-epoch-beta", 7, updates(upsert(observation("y", "stopped", 9007199254740992, "y")), upsert(observation("x", "stopped", 9007199254740993, "x"))))
	r.drain("B")
	r.checkpoint("remaining-consumer")
	r.assert("typed values reused one compiled program", 1, engine.Metrics()["compiledPrograms"])
	r.assert("bounded delivered rows", 2, engine.Metrics()["maxDeliveredRows"])
	r.assert("only touched-resource CEL work", 22, engine.Metrics()["incrementalCELInvocations"])
	r.assert("total CEL work", 34, engine.Metrics()["CELInvocations"])
	metricsBeforeClose := engine.Metrics()
	engine.Close("B")
	r.clients["B"].Closed = true
	r.clients["B"].Synced = false
	r.clients["B"].Rows = nil
	c.wg.Wait()
	q2.Close()
	<-q2.stopped
	r.checkpoint("closed")
	sourceFinal := c.Snapshot()
	for _, field := range []string{"interests", "reservations", "handles", "readersActive", "retainedItems", "retainedBytes", "stagedItems", "stagedBytes"} {
		r.assert("cleanup source "+field, 0, sourceFinal[field])
	}
	r.assert("cleanup query handles", 0, engine.Metrics()["activeQueries"])
	for i, q := range r.queues {
		stats := q.Snapshot()
		for _, field := range []string{"queueItems", "queueBytes", "writersActive"} {
			r.assert(fmt.Sprintf("cleanup writer %d %s", i, field), 0, stats[field])
		}
	}
	failed := 0
	for _, c := range r.checks {
		if !c.Pass {
			failed++
		}
	}
	result := map[string]any{"scope": "throwaway TCP source -> host CEL -> bounded JSON windows -> passive clients", "goVersion": runtime.Version(), "celPin": "cel.dev/cel-go v0.32.0", "assertions": len(r.checks), "unexpectedFailures": failed, "checkpoints": r.checkpoints, "checks": r.checks, "engine": metricsBeforeClose, "sourceFinal": sourceFinal, "sourceEndpoints": r.endpoints, "sourceInputFrames": len(r.frames), "limits": map[string]any{"windowRows": windowSize, "consumerQueueItems": resultQueueItems, "consumerQueueBytes": resultQueueBytes, "reservedControlBytes": controlBytes}, "limitations": []string{"Scripted native source and local TCP, not actual SDK/provider/gRPC/Wails.", "In-process bounded serialized JSON result queues; passive Bun consumer replays the emitted trace, not a result network socket or actual UI.", "CEL predicate uses string state and typed bound wanted; ordering uses Go exact int64, not unsafe mixed CEL numeric comparisons.", "Baseline source uses small full-map clones; integration is not production allocation/throughput proof.", "No full schema/authoring, authorization changes, general planner/index/cursor, result-count or multi-source federation implemented.", "Reset target generation is a probe protocol choice, not a frozen public ABI; control handshake and arbitrary repeated overlapping recovery require further conformance.", "Source fixture event channels are explicit test schedule barriers, not product ACK messages."}}
	writeJSON("results.json", result)
	writeJSON("client-trace.json", engine.trace)
	writeJSON("source-frames.json", r.frames)
	fmt.Printf("vertical: assertions=%d unexpectedFailures=%d checkpoints=%d sourceOpens=%v CELPrograms=%v CELInvocations=%v\n", len(r.checks), failed, len(r.checkpoints), sourceFinal["readerStarts"], metricsBeforeClose["compiledPrograms"], metricsBeforeClose["CELInvocations"])
	if failed > 0 {
		writeJSON("initial-failed-results.json", result)
		os.Exit(1)
	}
}
