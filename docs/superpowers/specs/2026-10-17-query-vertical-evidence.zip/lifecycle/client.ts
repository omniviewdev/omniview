import { readFileSync, writeFileSync } from 'node:fs';
import { isDeepStrictEqual } from 'node:util';

type Row = {key:string; id:string; rank:string; title:string};
type Frame = {lease:string;generation:string;sequence:string} & (
 | {kind:'reset';nextGeneration:string}
 | {kind:'snapshot'|'replace';rows:Row[]}
);
type Event = {op:'open';lease:string;generation:string} | {op:'close';lease:string} | {op:'frame';lease:string;data:Frame} | {op:'checkpoint';name:string};
type State = {rows:string[];generation:string;sequence:string;synced:boolean;closed:boolean};
type Client = {generation:string;expected:string;sequence:bigint;synced:boolean;closed:boolean;rows:Row[];ignored:number};
type Check = {name:string;expected:unknown;actual:unknown;pass:boolean};
function record(v:unknown):Record<string,unknown>{if(typeof v!=='object'||v===null||Array.isArray(v))throw Error('Expected object');return Object.fromEntries(Object.entries(v));}
function text(v:unknown):string{if(typeof v!=='string')throw Error('Expected string');return v;}
function list(v:unknown):unknown[]{if(!Array.isArray(v))throw Error('Expected array');return v;}
function parseRow(v:unknown):Row{const r=record(v);return {key:text(r.key),id:text(r.id),rank:text(r.rank),title:text(r.title)};}
function parseFrame(v:unknown):Frame{
 const f=record(v), base={lease:text(f.lease),generation:text(f.generation),sequence:text(f.sequence)};
 if(f.kind==='reset')return {...base,kind:'reset',nextGeneration:text(f.nextGeneration)};
 if(f.kind==='snapshot'||f.kind==='replace')return {...base,kind:f.kind,rows:f.rows===undefined?[]:list(f.rows).map(parseRow)};
 throw Error('Unknown result frame');
}
function parseEvent(v:unknown):Event{
 const e=record(v);switch(e.op){case 'open':return {op:'open',lease:text(e.lease),generation:text(e.generation)};case 'close':return {op:'close',lease:text(e.lease)};case 'frame':return {op:'frame',lease:text(e.lease),data:parseFrame(e.data)};case 'checkpoint':return {op:'checkpoint',name:text(e.name)};default:throw Error('Unknown trace operation');}
}
function parseExpectation(v:unknown):Partial<State>{
 const input=record(v),out:Partial<State>={};for(const [key,value]of Object.entries(input)){
  switch(key){case 'rows':out.rows=list(value).map(text);break;case 'generation':out.generation=text(value);break;case 'sequence':out.sequence=text(value);break;case 'synced':if(typeof value!=='boolean')throw Error('Expected bool');out.synced=value;break;case 'closed':if(typeof value!=='boolean')throw Error('Expected bool');out.closed=value;break;default:throw Error('Unknown expectation key');}
 }return out;
}
const expected:Record<string,Record<string,Partial<State>>>={};
const rawExpected:unknown=JSON.parse(readFileSync('expected.json','utf8'));
for(const [name,value]of Object.entries(record(rawExpected))){const byClient:Record<string,Partial<State>>={};for(const [id,fields]of Object.entries(record(value)))byClient[id]=parseExpectation(fields);expected[name]=byClient;}
const rawTrace:unknown=JSON.parse(readFileSync('client-trace.json','utf8'));
const trace=list(rawTrace).map(parseEvent);
const clients=new Map<string,Client>();const checks:Check[]=[];
let checkpoints=0,frames=0,maxRows=0,integerStrings=0;
function check(name:string,want:unknown,actual:unknown){checks.push({name,expected:want,actual,pass:isDeepStrictEqual(want,actual)});}
function client(id:string):Client{const c=clients.get(id);if(!c)throw Error('Unknown lease');return c;}
// Passive consumer: no resource schema, predicate, sorting or inventory.
for(const event of trace){
 if(event.op==='open')clients.set(event.lease,{generation:event.generation,expected:event.generation,sequence:0n,synced:false,closed:false,rows:[],ignored:0});
 else if(event.op==='close'){const c=client(event.lease);c.closed=true;c.synced=false;c.rows=[];}
 else if(event.op==='frame'){
  frames++;const f=event.data,c=client(event.lease);if(c.closed||f.lease!==event.lease){c.ignored++;continue;}
  if(!/^[1-9][0-9]*$/.test(f.sequence))throw Error('Noncanonical sequence');const seq=BigInt(f.sequence);if(seq>18446744073709551615n)throw Error('Sequence overflow');
  if(f.kind==='reset'){if(f.generation!==c.generation){c.ignored++;continue;}if(!f.nextGeneration||f.nextGeneration===c.generation||seq<=c.sequence)throw Error('Invalid recovery control');c.sequence=seq;c.expected=f.nextGeneration;c.synced=false;c.rows=[];continue;}
  if(f.kind==='snapshot'){if(f.generation!==c.expected){c.ignored++;continue;}if(seq!==1n)throw Error('Snapshot sequence');c.generation=f.generation;c.expected='';c.sequence=seq;c.synced=true;}
  else {if(f.generation!==c.generation||!c.synced){c.ignored++;continue;}if(seq!==c.sequence+1n)throw Error('Result gap');c.sequence=seq;}
  if(f.rows.length>2)throw Error('Unbounded result');const keys=new Set<string>();for(const row of f.rows){if(keys.has(row.key))throw Error('Duplicate row key');keys.add(row.key);if(!/^(0|-[1-9][0-9]*|[1-9][0-9]*)$/.test(row.rank))throw Error('Lossy integer transport');const rank=BigInt(row.rank);if(rank < -9223372036854775808n||rank>9223372036854775807n)throw Error('Rank overflow');integerStrings++;}
  maxRows=Math.max(maxRows,f.rows.length);c.rows=f.rows;
 }else{
  checkpoints++;const wanted=expected[event.name];if(!wanted)throw Error('Unexpected checkpoint');for(const [id,fields]of Object.entries(wanted)){const c=client(id);const state:State={rows:c.rows.map(r=>`${r.id}:${r.rank}:${r.title}`),generation:c.generation,sequence:c.sequence.toString(),synced:c.synced,closed:c.closed};for(const [key,value]of Object.entries(fields)){const actual:Record<string,unknown>=record(state);check(`${event.name}/${id}/${key}`,value,actual[key]);}}
 }
}
check('all expected checkpoints',Object.keys(expected).length,checkpoints);check('bounded maximum result rows',2,maxRows);check('stale old-generation snapshot ignored',1,client('A').ignored);for(const [id,c]of clients)check(`final closed client ${id}`,true,c.closed);
const failures=checks.filter(c=>!c.pass);const result={runtime:`Bun ${Bun.version}`,scope:'passive validated JSON trace replay; no query filtering/sorting',checkpoints,frames,integerStrings,maxRows,assertions:checks.length,unexpectedFailures:failures.length,checks};writeFileSync('client-results.json',JSON.stringify(result,null,2));console.log(JSON.stringify({checkpoints,frames,integerStrings,maxRows,assertions:checks.length,unexpectedFailures:failures.length}));if(failures.length)process.exit(1);
