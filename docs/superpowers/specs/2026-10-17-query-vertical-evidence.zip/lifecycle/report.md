# Integrated source → CEL → result-window proof

Throwaway integration evidence, not product code, frozen API or production index/planner. No repository runtime/SDK/plugin code changed. This is one sequential integration slice, not independent agent claims stitched together.

## Reproduce

From this directory after extraction:

```sh
GOWORK=off go run -race .
bun run client.ts
```

Parent executed this after final code changes. Observed Go go1.26.1 darwin/arm64; no Go race report; native exit 0. Client-results.json records actual Bun runtime (Bun 1.1.20 in this environment). Native: 127 assertions, zero unexpected failures, 17 checkpoints. Passive JS: 105 assertions, zero unexpected failures, 17 checkpoints, 19 serialized result frames, maximum two rows per frame.

Go modules pin cel.dev/cel-go v0.32.0 and transitive checksums. Source transport starts from source-session-evidence.zip:lifecycle/probe.go, adding post-application/terminal callbacks and the admitted change set. The byte-framed TCP/parser/phase/admission/sharing implementation is the previously exercised fixture, not the production SDK. Source snapshots and admitted changes reach CEL through those callbacks before fixture notification events, not through manually assigned expected client rows.

## Independent expectations

expected.json was authored before the executable integration: source staging invisible; initial sorted windows; predicate enter/exit; ordering and projection changes; deletion; a two-resource atomic batch; identity tie-break; source sequence-gap reset; new-generation recovery; stale snapshot rejection; slow result consumer overflow; local resnapshot without source reopen; one consumer close; adjacent large exact ranks; final cleanup.

main.go scripts 18 actual serialized source frames over two loopback TCP pairs: one initial acquisition generation shared by both queries, then one intentional reset/recovery generation shared again. Source selection is the provider-neutral fixture machine type, not Kubernetes. Native source consistency is explicitly bestEffort; this proves no actual provider's handoff guarantee.

Go and JavaScript independently compare passive client states to expected.json. They do not derive expected rows from CEL outputs or source-frame replay. Results and client-results preserve each expected/actual check. The JS client runtime-validates parsed trace/row fields, applies snapshots/replacements/reset controls, checks sequence/generation and bounded row count, and never loads inventory, evaluates a predicate or sorts rows. It replays emitted JSON trace, not a live result network socket or a real UI.

## Observed integration behavior

- One checked CEL program (`has(resource.state) && resource.state == wanted`) is compiled once. Queries A/B supply separately declared string binding values ready/stopped, never interpolated into source.
- Both queries use one source reader per source generation and two interests. Query source generations and result generations are deliberately different identities and have different sequence progress.
- Initial CEL evaluation covers each acquired observation for each query. Following updates evaluate only distinct touched extant resources per active query; removes update membership without rerunning a predicate on nonexistent data. Measured 34 CEL invocations total: 12 initial/resnapshot invocations and 22 following-update invocations. This is a deterministic work count, not a benchmark.
- The host maintains membership and exact-int64 rank order with canonical identity tie-break; clients receive a bounded whole-window replacement, at most two rows. Small slice insertion/removal is a prototype index, not a scalable data-structure decision.
- Two source mutations in one batch publish one final window transition per affected query, not intermediate per-resource windows. Projection-only title changes deliver a replacement even when membership/order are unchanged. Unchanged windows emit no replacement and do not allocate a result window to compare it.
- A source frame gap resets both query results; clients clear current rows, accept only the announced fresh result-generation snapshot, and ignore the injected old-generation snapshot. One old source callback is a local negative control; other source reset/update traffic crosses actual TCP.
- The result queue is bounded at two messages / 4096 serialized data bytes, with one separately bounded 1024-byte reset control. Query B overflow discarded three stale/missed data frames and reset B only. Query A remained synchronized. B rebuilt its result snapshot from the maintained host query state under a new result generation, with no source reopen. Byte limit is enforced but this scenario provokes item saturation, not an independent result-byte-saturation case.
- Closing A leaves one source interest and B continues receiving results. B's final batch orders exact integer ranks 9007199254740992 and 9007199254740993 correctly and transports them as decimal strings to JS; JS cannot silently collapse them as numbers. CEL itself performs only string predicates here, so this does not close the separate mixed-numeric dependency gate.
- Final close leaves zero source interests, reservations, handles, active readers, retained/staged observations/bytes, writer items/bytes/active workers and query handles. Probe transcript retention is an intentional evidence artifact, not a runtime cache policy.

## Important limits and protocol choices

- No actual SDK/gRPC/protobuf/Wails, provider API, DOM/UI, schema discovery/type-service, authoring/builder reverse conversion, access-context mutation, general QuerySpec/cursor/count/grouping/federation or production performance measured.
- Full source coordinator uses small whole-map clones inherited from the fixture. That is not approval for inventory-wide copies per update. Query membership is incrementally maintained, but its sorted slice can shift matching rows; no 50k-object latency, memory or cancellation claim is made.
- Fixed complete source representation, one access/authority/type/scope and simple valid body schema only. CEL/body/order failure handling is fail-fast in the probe, not the public structured error/partial-result contract. No hostile-client or cross-credential isolation claim.
- Results travel through bounded in-process serialized JSON queues. The source wire uses real TCP; result consumer process replays a saved JSON trace. This is neither two-process live result delivery nor loss/reconnect proof for the eventual bridge.
- Reset carries a probe-specific nextGeneration target so clients cannot accept arbitrary stale snapshots while awaiting recovery. The out-of-band overflow control can intentionally skip lost data sequence numbers. These are explicit prototype protocol choices, not a frozen public DTO. Repeated overlapping resets, reattachment, duplicate controls and actual transport-control ordering still require contract/conformance work.
- Test-only source notification channels and explicit send/apply barriers schedule deterministic input. They are not product ACKs, cannot establish independently saturated diagnostic-channel shutdown safety, and are not timing/performance evidence.
- This workload's race detector reported no races; it does not prove every concurrency schedule. Scalar callback error paths, result-byte overflow, refresh without preceding source reset and multiple sources were not exercised.

## Artifacts

probe.go, query.go, main.go, client.ts, expected.json, go.mod, go.sum are the exact executable inputs. results.json contains native checks/checkpoints, incremental work and cleanup data; client-trace.json is emitted result JSON events; source-frames.json records source input; client-results.json is the separately executed passive client evidence. No binaries/caches are included.

## Recommendation

The isolated language/schema/source evidence now has one bounded combined path. Consolidate accepted contracts and probe-specific gaps into reviewable implementation packets rather than adding another universal engine or shipping this temporary code. Freeze identity/binding/source/result/error ownership and wire mapping before SDK changes; then preserve the roadmap's separate SDK boundary, source/schema, read-model/query/lease/runtime and provider integration changes. Numeric dependency readiness remains independent.
