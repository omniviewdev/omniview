package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"os"
	"runtime"
	"strings"

	"cel.dev/cel-go/cel"
)

type Observation struct {
	Name        string `json:"name"`
	Expression  string `json:"expression,omitempty"`
	Resource    string `json:"resource,omitempty"`
	Expected    string `json:"expected"`
	Actual      string `json:"actual"`
	Detail      string `json:"detail,omitempty"`
	CheckedType string `json:"checkedType,omitempty"`
	Assertion   bool   `json:"assertion"`
}
type Probe struct {
	fixture      Fixture
	catalog      *Catalog
	observations []Observation
}

func (p *Probe) eval(name, resource, expression, expected string) {
	r := p.fixture.Resources[resource]
	root := cel.DynType
	if r.Schema != "" {
		root = p.catalog.celType(p.catalog.defs[r.Schema])
	}
	obs := Observation{Name: name, Resource: resource, Expression: expression, Expected: expected}
	env, err := cel.NewEnv(cel.CustomTypeProvider(p.catalog), cel.CustomTypeAdapter(p.catalog), cel.Variable("resource", root), cel.ParserRecursionLimit(64), cel.ParserExpressionSizeLimit(4096))
	if err != nil {
		panic(err)
	}
	ast, issues := env.Compile(expression)
	if issues != nil && issues.Err() != nil {
		obs.Actual = "check-error"
		obs.Detail = issues.Err().Error()
	} else {
		obs.CheckedType = ast.OutputType().String()
		admitted, err := p.catalog.admit(r)
		if err != nil {
			obs.Actual = "admission-error"
			obs.Detail = err.Error()
		} else {
			program, err := env.Program(ast, cel.CostLimit(10000))
			if err != nil {
				panic(err)
			}
			out, _, err := program.Eval(map[string]any{"resource": admitted})
			if err != nil {
				obs.Actual = "eval-error"
				obs.Detail = err.Error()
				if strings.Contains(err.Error(), "hydration-needed") {
					obs.Actual = "hydration-needed"
				}
			} else {
				obs.Actual = fmt.Sprint(out)
			}
		}
	}
	obs.Assertion = obs.Actual == obs.Expected
	p.observations = append(p.observations, obs)
}
func (p *Probe) admission(name string, r Representation, expected, detailContains string) {
	value, err := p.catalog.admit(r)
	actual := "admitted"
	detail := ""
	if err != nil {
		actual = "admission-error"
		detail = err.Error()
	} else {
		detail = fmt.Sprint(value.Type())
	}
	p.observations = append(p.observations, Observation{Name: name, Expected: expected, Actual: actual, Detail: detail, Assertion: actual == expected && (detailContains == "" || strings.Contains(detail, detailContains))})
}
func rawRepresentation(schema, raw string) Representation {
	var data any
	d := json.NewDecoder(strings.NewReader(raw))
	d.UseNumber()
	if err := d.Decode(&data); err != nil {
		panic(err)
	}
	return Representation{Schema: schema, Complete: true, Data: data}
}
func (p *Probe) catalogAdmission(name string, defs map[string]*Schema, want string) {
	_, err := newCatalog(defs)
	actual := "admitted"
	detail := ""
	if err != nil {
		actual = "schema-error"
		detail = err.Error()
	}
	p.observations = append(p.observations, Observation{Name: name, Expected: want, Actual: actual, Detail: detail, Assertion: actual == want})
}
func main() {
	source, err := os.ReadFile("fixtures.json")
	if err != nil {
		panic(err)
	}
	var fixture Fixture
	decoder := json.NewDecoder(bytes.NewReader(source))
	decoder.UseNumber()
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&fixture); err != nil {
		panic(err)
	}
	catalog, err := newCatalog(fixture.Definitions)
	if err != nil {
		panic(err)
	}
	p := &Probe{fixture: fixture, catalog: catalog}
	tag := `has(resource.tags) && resource.tags.exists(t, t.key == "env" && t.value == "prod")`
	p.eval("cloud same-element true", "cloudGood", tag, "true")
	p.eval("cloud cross-element false", "cloudCross", tag, "false")
	p.eval("guarded actual absence", "cloudAbsent", tag, "false")
	p.eval("same guarded expression incomplete needs hydration", "cloudSummary", tag, "hydration-needed")
	p.eval("summary explicit absence metadata", "summaryKnownAbsent", tag, "false")
	p.eval("has complete absence", "cloudAbsent", `has(resource.tags)`, "false")
	p.eval("has summary not false absence", "cloudSummary", `has(resource.tags)`, "hydration-needed")
	p.eval("unguarded absent is error", "cloudAbsent", `resource.tags.size() > 0`, "eval-error")
	p.eval("dynamic cast cannot bypass incomplete presence", "cloudSummary", `has(dyn(resource).tags)`, "hydration-needed")
	p.eval("dynamic index cannot bypass incomplete access", "cloudSummary", `dyn(resource)["tags"].size() > 0`, "hydration-needed")
	p.eval("dynamic index cannot invent schema field", "cloudGood", `dyn(resource)["typo"] == null`, "eval-error")
	p.eval("known field typo rejected statically", "cloudGood", `resource.tgas.size() > 0`, "check-error")
	p.eval("nested known field typo rejected statically", "cloudGood", `resource.tags.exists(t, t.kee == "env")`, "check-error")
	p.eval("known type mismatch rejected statically", "cloudGood", `resource.generation == "9007199254740993"`, "check-error")
	p.eval("container arbitrary map keys", "container", `resource.labels["unanticipated/key"] == "accepted" && resource.labels["app.kubernetes.io/name"] == "frontend"`, "true")
	p.eval("nested container maps", "container", `resource.networks["bridge"]["IPAddress"] == "10.0.0.2"`, "true")
	p.eval("typed map wrong value comparison rejected", "container", `resource.labels["key"] == 1`, "check-error")
	p.eval("arbitrary missing map key guarded", "container", `!("unprovided/key" in resource.labels)`, "true")
	p.eval("VM scope and typed hardware", "vm", `resource.scope == "node-a/local" && resource.hardware.cpu >= 8 && resource.hardware.memory == 17179869184u`, "true")
	p.eval("VM opaque dynamic navigation", "vm", `resource.opaque["vendor.key"].enabled && resource.opaque.serial == "000001"`, "true")
	p.eval("VM typed hardware typo", "vm", `resource.hardware.cpus > 0`, "check-error")
	p.eval("VM opaque typo is runtime not static", "vm", `resource.opaque.typo == true`, "eval-error")
	p.eval("Kubernetes nested same-element correlation", "kube", `resource.spec.containers.exists(c, c.name == "web" && c.ports.exists(p, p.name == "http" && p.containerPort == 8080))`, "true")
	p.eval("Kubernetes cross-container control", "kube", `resource.spec.containers.exists(c, c.name == "web" && c.ports.exists(p, p.name == "metrics" && p.containerPort == 9090))`, "false")
	p.eval("Kubernetes nested type error", "kube", `resource.spec.containers.exists(c, c.ports.exists(p, p.containerPort == "8080"))`, "check-error")
	p.eval("nullable explicit null has true", "discoveredNull", `has(resource.nickname) && resource.nickname == null`, "true")
	p.eval("nullable omitted has false", "discoveredAbsent", `!has(resource.nickname)`, "true")
	p.eval("nullable primitive preserves static domain", "discoveredNull", `resource.nickname + 1 == 2`, "check-error")
	p.eval("nullable primitive still needs null guard", "discoveredNull", `resource.nickname.startsWith("a")`, "eval-error")
	p.eval("nullable complex null short circuit", "discoveredNull", `resource.detail != null && resource.detail.cpu > 0`, "false")
	p.eval("nullable complex guarded real object", "discoveredAbsent", `resource.detail != null && resource.detail.cpu == 4`, "true")
	p.eval("nullable complex dyn typo not static guarantee", "discoveredAbsent", `resource.detail.typo == 4`, "eval-error")
	p.eval("union string guarded branch", "discoveredNull", `type(resource.variant) == string && resource.variant.startsWith("a")`, "true")
	p.eval("union int guarded branch", "discoveredAbsent", `type(resource.variant) == int && resource.variant > 5`, "true")
	p.eval("union dyn runtime wrong branch", "discoveredNull", `resource.variant > 5`, "eval-error")
	p.eval("timestamp instant nanoseconds preserved", "discoveredNull", `resource.seen == timestamp("2026-10-17T23:02:03.123456789Z")`, "true")
	p.eval("recursive lazy ref nested typed traversal", "tree", `resource.children.exists(c, c.name == "leaf" && !has(c.children))`, "true")
	p.eval("recursive typo still statically rejected", "tree", `resource.children.exists(c, c.typo == "leaf")`, "check-error")
	p.eval("no schema bounded dynamic real evaluation", "fallback", `resource.vendor.arbitrary.exists(x, x.value == 5) && resource.integer == 9007199254740993`, "true")
	p.eval("no schema typo only runtime", "fallback", `resource.typo == 5`, "eval-error")
	p.eval("exact int64 upper adjacent value", "cloudGood", `resource.generation == 9007199254740993 && resource.generation != 9007199254740992`, "true")
	p.eval("uint64 max exact", "cloudGood", `resource.unsigned == 18446744073709551615u`, "true")
	p.eval("typed mixed-domain comparison rejected", "cloudGood", `resource.generation == resource.ratio`, "check-error")
	p.eval("typed mixed-domain literal rejected", "cloudGood", `resource.generation == 9007199254740992.0`, "check-error")
	p.eval("dynamic mixed-domain false equality unsafe", "cloudGood", `dyn(resource.generation) == resource.ratio`, "true")
	p.eval("dynamic mixed-domain literal false equality unsafe", "cloudGood", `dyn(resource.generation) == 9007199254740992.0`, "true")
	p.eval("dynamic resource cannot bypass numeric issue", "cloudGood", `dyn(resource).generation == dyn(resource).ratio`, "true")
	for name, raw := range map[string]string{
		"input unknown field rejected":          `{"id":"x","generation":1,"extra":true}`,
		"input wrong tag element type rejected": `{"id":"x","generation":1,"tags":[{"key":"env","value":2}]}`,
		"input missing required rejected":       `{"id":"x"}`,
		"input null nonnullable rejected":       `{"id":"x","generation":1,"tags":null}`,
		"int64 fraction lexical rejection":      `{"id":"x","generation":1.0}`,
		"int64 exponent lexical rejection":      `{"id":"x","generation":1e3}`,
		"int64 positive overflow rejected":      `{"id":"x","generation":9223372036854775808}`,
		"int64 negative overflow rejected":      `{"id":"x","generation":-9223372036854775809}`,
		"uint64 overflow rejected":              `{"id":"x","generation":0,"unsigned":18446744073709551616}`,
		"uint64 negative rejected":              `{"id":"x","generation":0,"unsigned":-1}`,
		"double overflow rejected":              `{"id":"x","generation":0,"ratio":1e400}`,
	} {
		p.admission(name, rawRepresentation("Cloud", raw), "admission-error", "")
	}
	p.admission("int64 minimum and maximum admitted", rawRepresentation("Cloud", `{"id":"x","generation":-9223372036854775808,"unsigned":0}`), "admitted", "")
	p.admission("int64 maximum admitted", rawRepresentation("Cloud", `{"id":"x","generation":9223372036854775807}`), "admitted", "")
	p.admission("wrong union branch rejected", rawRepresentation("Discovered", `{"name":"x","variant":true}`), "admission-error", "union")
	p.admission("wrong nullable nonnull type rejected", rawRepresentation("Discovered", `{"name":"x","variant":"ok","nickname":42}`), "admission-error", "expected string")
	p.admission("typed map admission cannot be bypassed by expression", rawRepresentation("Container", `{"name":"x","labels":{"x":4},"networks":{}}`), "admission-error", "expected string")
	p.admission("opaque subtree still bounded and lexical", rawRepresentation("VM", `{"scope":"x","hardware":{"cpu":1,"memory":1},"opaque":{"bad":9223372036854775808}}`), "admission-error", "int64 out of range")
	p.admission("fallback huge integer does not silently double", rawRepresentation("", `{"large":9223372036854775808}`), "admission-error", "int64 out of range")
	partial := fixture.Resources["fallback"]
	partial.Complete = false
	p.admission("incomplete fallback refuses false absence", partial, "admission-error", "hydration-needed")
	partial = fixture.Resources["container"]
	partial.Complete = false
	p.admission("incomplete typed maps require hydration", partial, "admission-error", "hydration-needed")
	contradiction := fixture.Resources["cloudGood"]
	contradiction.KnownAbsent = []string{"resource.tags"}
	p.admission("representation metadata contradiction rejected", contradiction, "admission-error", "contradicts")
	// Bounds are host admission limits, independent of CEL traversal cost.
	nested := any(map[string]any{"name": "leaf"})
	for range 14 {
		nested = map[string]any{"name": "node", "children": []any{nested}}
	}
	p.admission("recursive data depth bound", Representation{Schema: "Tree", Complete: true, Data: nested}, "admission-error", "bound")
	large := make([]any, 65)
	for i := range large {
		large[i] = json.Number("1")
	}
	p.admission("fallback collection bound", Representation{Complete: true, Data: large}, "admission-error", "cardinality")
	wide := map[string]any{}
	for i := range 64 {
		row := make([]any, 9)
		for j := range row {
			row[j] = json.Number("1")
		}
		wide[fmt.Sprint(i)] = row
	}
	p.admission("fallback total node bound", Representation{Complete: true, Data: wide}, "admission-error", "bound")
	p.admission("fallback string bound", Representation{Complete: true, Data: strings.Repeat("x", maxString+1)}, "admission-error", "string bound")
	p.catalogAdmission("unresolved reference rejected", map[string]*Schema{"Broken": {Kind: "ref", Ref: "missing"}}, "schema-error")
	p.catalogAdmission("ref-only cycle rejected", map[string]*Schema{"A": {Kind: "ref", Ref: "B"}, "B": {Kind: "ref", Ref: "A"}}, "schema-error")
	p.catalogAdmission("decimal schema unsupported explicitly", map[string]*Schema{"Decimal": {Kind: "decimal"}}, "schema-error")
	failures := 0
	for _, o := range p.observations {
		if !o.Assertion {
			failures++
		}
	}
	adapterSource, err := os.ReadFile("adapter.go")
	if err != nil {
		panic(err)
	}
	result := map[string]any{"engine": "cel.dev/cel-go v0.32.0", "go": runtime.Version(), "description": fixture.Description, "bounds": map[string]int{"maxDepth": maxDepth, "maxNodes": maxNodes, "maxCollection": maxCollection, "maxStringBytes": maxString, "maxDefinitions": 32}, "adapterImplementation": map[string]int{"bytes": len(adapterSource), "lines": bytes.Count(adapterSource, []byte("\n"))}, "observations": p.observations, "assertionFailures": failures, "observationCount": len(p.observations)}
	output, err := json.MarshalIndent(result, "", "  ")
	if err != nil {
		panic(err)
	}
	if err = os.WriteFile("results.json", append(output, '\n'), 0600); err != nil {
		panic(err)
	}
	fmt.Printf("CEL schema confirmation: %d observations, %d assertion failures; results.json written\n", len(p.observations), failures)
	if failures != 0 {
		for _, o := range p.observations {
			if !o.Assertion {
				fmt.Printf("FAIL %s: expected=%s actual=%s detail=%s\n", o.Name, o.Expected, o.Actual, o.Detail)
			}
		}
		os.Exit(1)
	}
}
