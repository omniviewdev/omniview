# Catalog-shaped CEL adapter confirmation

## Result and reproduction

This is an isolated feasibility harness, not a product implementation. It reads a bounded normalized catalog-shaped schema fixture and resource JSON, performs schema-driven admission, supplies a custom `types.Provider` / `types.Adapter` and generic `ref.Val` object to the real CEL checker/evaluator. There are **no per-resource Go structs, source rewrites, provider-specific CEL functions, or custom expression interpreter**. It does not pretend the current Omniview catalog already exports this dialect.

Final observed execution:

```text
CEL schema confirmation: 75 observations, 0 assertion failures; results.json written
```

Executed with Go `go1.26.1`; module declares Go 1.25.0. Reproduce from this directory:

```sh
GOWORK=off go mod download
GOWORK=off go run .
```

`go.mod` and `go.sum` pin the complete resolved dependency graph. Direct dependency: `cel.dev/cel-go v0.32.0`. Indirect pins: `cel.dev/expr v0.25.1`, `github.com/antlr4-go/antlr/v4 v4.13.1`, `go.yaml.in/yaml/v3 v3.0.4`, `golang.org/x/exp v0.0.0-20240823005443-9b4947da3948`, `google.golang.org/genproto/googleapis/api` and `/rpc v0.0.0-20240826202546-f6391c0de4c7`, `google.golang.org/protobuf v1.36.10`.

Artifacts: `fixtures.json` contains actual schema definitions and resource representations; `adapter.go` contains the normalized dialect/provider/admission/value adapter; `main.go` contains the real CEL observation runner and adversarial admission inputs; `results.json` records every expected/actual/assertion, checked result type where compilation succeeded, and actual diagnostic details. A passing assertion sometimes confirms an unsafe limitation or expected rejection, not universal support.

Preparation used `GOWORK=off go mod tidy` and one `gofmt` pass. The first compile exposed a Go interface-return mismatch (`ref.Type` is not itself statically `ref.Val`), corrected by returning the concrete CEL type. The first runnable corpus also disproved an assumption that known int/double equality would check: the checker rejected both typed cases. Expectations were corrected to record that stronger static guarantee, and explicit dynamic cases were added to expose the actual mixed-domain failure. Final execution above passed all 75 observations. No product tests/builds were run and no product files were edited.

## Concrete integration

The fixture dialect supports bool/string/int64/uint64/double/timestamp, closed objects with optional fields, string-keyed maps, lists, nullable values, bounded union branches, dynamic branches, and named references. Objects are named structurally from the schema registry, not generated Go resource types. Primitive nullable values use CEL's `NewNullableType`; nullable object/list/map/timestamp cases weaken to `dyn` in this adapter, as do unions and opaque/no-schema branches. Every value is recursively admitted before activation is handed to CEL, including dynamic maps and values later accessed via `dyn(...)` or indexing.

The provider advertises known object types and fields through `FindStructType`, `FindStructFieldNames` and `FindStructFieldType`. Field types drive actual CEL checking. The adapter recognizes admitted `ref.Val` values and otherwise delegates to CEL's default adapter; lists/maps use CEL's native list/map value adapters. Generic catalog objects implement CEL `Indexer` and `FieldTester` traits. Resource construction through CEL object literals is deliberately rejected by the provider rather than providing a path around host admission. The harness uses native `env.Compile`, `env.Program`, and `program.Eval`.

### Presence and completeness require a deliberate runtime path

Completeness is representation metadata (`complete`, `knownAbsent`) separate from `data`. A missing optional field in a complete representation is absent; missing in an incomplete representation is unavailable unless explicitly marked known-absent. Null is an actual admitted value, never absence. Contradictory present/known-absent metadata is rejected.

Crucially, CEL's `types.FieldType.IsSet` callback has signature `func(any) bool`. Its optimized field qualifier cannot return a hydration-needed error. This provider supplies static `FieldType.Type` but intentionally leaves optimized `IsSet` / `GetFrom` callbacks nil, selecting CEL's existing generic traits path instead. `traits.FieldTester.IsSet` returns a CEL value and can propagate a CEL error. This is an optimization constraint, not another interpreter and not a performance claim.

The **same** actual expression:

```cel
has(resource.tags) && resource.tags.exists(t, t.key == "env" && t.value == "prod")
```

returns false for complete `cloudAbsent`, hydration-needed for incomplete `cloudSummary`, and false for `summaryKnownAbsent`. Standalone `has(resource.tags)` also returns hydration-needed, not false, for the summary. `has(dyn(resource).tags)` and `dyn(resource)["tags"].size() > 0` propagate hydration-needed too. The runtime retains the catalog object when cast to dyn; dynamic lookup cannot turn it into an unvalidated raw map. An unknown catalog field accessed through dyn is a runtime error instead of invented absence.

Incomplete map/no-schema representations are intentionally narrower: admission returns a hydration-needed diagnostic rather than pretending arbitrary missing keys are absent. This harness does not implement per-map-key completeness. Present map subtrees in an incomplete whole representation also require hydration. It performs no provider RPC/hydration scheduling; the diagnostic is the host-visible result indicating missing information. Only evaluated accesses need hydration, so CEL short-circuiting is preserved.

## Measured coverage and static guarantees

- **Cloud tags:** correlated `exists` accepts env=prod on one tag and rejects the cross-element env=dev/owner=prod false positive. Unknown fields on root and tag elements fail real checking.
- **Container maps:** quoted label keys and nested arbitrary network keys evaluate; map value comparisons retain string types; wrong map values are rejected at admission. Arbitrary map keys are intentionally not finite known fields.
- **VM:** scope remains ordinary data, hardware fields are typed, opaque vendor data is explicitly dynamic. Hardware typos are checker errors; opaque typos are runtime errors. This does not implement scope/access authority.
- **Kubernetes shape:** two-level container/port `exists` correlation succeeds; cross-container counterexample remains false; nested numeric/string mismatch fails checking.
- **Discovered schema:** optional omitted versus present-null stays distinct. Nullable string retains a wrapper-string checker domain, rejecting addition to int. A string operation on null can nevertheless check and fail at runtime: nullable is not automatic null-flow safety. Nullable complex object traversal uses dyn; null guard short-circuits correctly, actual object traversal succeeds, and typo detection is runtime-only. Union string/int branches work with explicit type guards; bool is rejected at admission and unguarded wrong-domain comparison fails at runtime.
- **Timestamp:** timezone-normalized instant comparison preserves nine fractional digits in the exercised value.
- **Recursive references:** named reference edges remain lazy, including `Tree -> list<Tree>`, rather than eagerly expanding infinitely. Nested field checking and guarded leaf traversal work; recursive payload depth is bounded. Ref-only cycles and unresolved references are rejected.
- **No schema:** complete dynamic resource maps/lists run actual CEL, preserve an exact admitted int64, and retain bounded admission. Unknown fields cannot be diagnosed statically; missing unguarded accesses fail at runtime.
- **Contradictions/bounds:** unknown closed-object data fields, wrong nested types, missing required complete fields, null for nonnullable values, metadata contradictions, numeric overflow, excessive recursion, cardinality, total node count, strings, and unsupported decimal schemas are rejected.

Static guarantee scope: finite known object fields and typed scalar/list/map operations are checked. Optionality does not make unguarded missing access safe. Map key existence, runtime presence, union branch validity at each use, nullable complex shape, dynamic branch field names, and numeric safety after dyn escape are **not** universal static guarantees. Admission separately guarantees the supplied runtime shape, not validity of every possible expression.

## Numeric evidence: important remaining failure

JSON is decoded using `json.Decoder.UseNumber` and schema admission examines the lexeme. Signed/unsigned integers require canonical decimal integer syntax, range-check to int64/uint64, and reject fractional/exponent syntax rather than coercing. The fixtures prove adjacent values above 2^53 remain distinct, int64 min/max and uint64 max are admitted exactly, and overflows are rejected. No-schema integer lexemes exceeding int64 are rejected, not silently admitted as double. Doubles are finite binary64 values, with no promise of arbitrary decimal precision. Decimal is unsupported.

Known `int` versus `double` equality is rejected by the default checker in this environment. However, **admission precision is insufficient once dyn erases the checker domain**. For exact generation `9007199254740993` and double ratio `9007199254740992.0`, both of these actually return true:

```cel
dyn(resource.generation) == resource.ratio
dyn(resource.generation) == 9007199254740992.0
```

Casting the whole resource to dyn also exposes this failure. These are recorded expected-unsafe observations, not hidden or rewritten comparisons. This harness does not claim the catalog adapter alone establishes a safe production numeric expression profile. A host expression-admission rule or deliberately restricted expression surface is still required around dynamic mixed-domain numeric operations; the separate binding harness investigates that gate. This adapter does not implement an ad-hoc evaluator or silently coerce exact fields to mask the problem.

## Size, bounds, and limitations

Measured `adapter.go`: **497 lines / 13,352 bytes**, including the fixture schema DTOs, schema validation/registration, provider and adapter, generic object traits, completeness semantics, and recursive numeric/shape admission. This is more than simply registering a Go type; completeness, schema normalization and admission policy are real host responsibilities. `main.go` is separate experiment/observation code, not counted as adapter code. No performance estimates or performance benchmarks were made.

Bounds exercised: max data/schema depth 12, total admission/schema nodes 512, collection/object field cardinality 64, string/key bytes 16,384, named definitions 32, union branches 2–4; CEL parse recursion 64, source 4,096 characters, evaluation cost limit 10,000. These are throwaway constants, not recommended production budgets. This in-memory experiment is not a wire-stream byte-budget proof, deadline/cancellation proof, cardinality-aware static cost proof, or memory benchmark.

Not delivered or claimed: current product-catalog ingestion; full JSON Schema/OpenAPI normalization; arbitrary `oneOf`/`anyOf`/discriminators or overlapping union design; external/remote refs; recursive schema authoring navigation; heterogeneous target schema joins; unknown-versus-null CEL abstract interpretation; partial map/list completeness; hydration RPCs or caching; editor recovery/completions; cross-version checked artifact trust; a complete safe numeric expression profile; object equality conformance; provider access/scope policy or pushdown equivalence; real provider/cluster integration; IPC/JavaScript precision validation. The recursive and union fixtures establish this bounded native adapter path, not an invented universal schema solution.

## Source anchors reviewed

- Prior experiment: repository `docs/superpowers/specs/2026-10-17-query-language-comparison.md`, especially sections 3.1 and 3.2; archived CEL module pins in `2026-10-17-query-language-evidence.zip`.
- Canonical implementation: https://github.com/cel-expr/cel-go/tree/v0.32.0
- Provider interfaces: https://github.com/cel-expr/cel-go/blob/v0.32.0/common/types/provider.go
- Generic versus optimized presence path: https://github.com/cel-expr/cel-go/blob/v0.32.0/interpreter/attributes.go (`NewQualifier`, `fieldQualifier.QualifyIfPresent`, generic `FieldTester` dispatch).
- Primitive-only nullable API: https://github.com/cel-expr/cel-go/blob/v0.32.0/common/types/types.go (`NewNullableType`).
