# Tagged CEL binding confirmation

## Reproduce

From this directory:

```sh
GOWORK=off go build -o evaluator . && bun run driver.ts
```

Initial executed command (one full harness run after implementation):

```sh
gofmt -w main.go && GOWORK=off go mod tidy && GOWORK=off go build -o evaluator . && bun run driver.ts
```

Observed: exit **0**, `{"summary":{"checks":124,"failures":0,"goExit":0}}`, no evaluator stderr. Runtime: **Go 1.26.1**, **Bun 1.1.20**. Direct dependency **cel.dev/cel-go v0.32.0**; exact transitive versions/checksums are preserved in `go.mod` and `go.sum`.

`driver.ts` really serializes tagged requests, writes them to the compiled Go subprocess, consumes its JSON responses and asserts exact tagged values/booleans with `isDeepStrictEqual`. `requests.jsonl`, `responses.jsonl`, and `results.json` preserve every request, response and assertion. Unexpected stage/value/id/count/process outcomes make the driver exit nonzero. Rejection assertions preserve actual CEL/host error messages. This is a native subprocess/JSON feasibility path, **not Wails, product IPC, a real catalog or provider integration**. No product files were changed.

## Successfully asserted controls

- Exact decimal-string int64 transport at min/max, zero, negative high values, 2^53−1, 2^53, 2^53+1; uint64 zero, high adjacent values, max. CEL result integers return as strings and remain distinct in the JS consumer.
- Recursive declaration/value checking; missing, extra, wrong-kind, malformed payloads, unsupported tags, unknown object properties and duplicate JSON keys reject. Integer overflow, `-0`, plus sign, leading zero, whitespace, fractions, exponent notation and JSON-number integer values reject without coercion.
- Finite binary64 extremes/subnormal, booleans and Unicode strings round-trip. JSON serializes NaN/±Infinity to null and Go rejects those wrong payloads; a raw JSON `1e309` number is rejected as unrepresentable. Nonfinite CEL output (`1.0 / 0.0`) is rejected at result encoding. JS negative-zero serializes as zero; this harness explicitly asserts that normal JSON normalization rather than claiming preservation of a sign bit.
- RFC3339 timezone offsets normalize to UTC; nine fractional digits round-trip and compare distinctly from adjacent nanoseconds. CEL range 0001–9999, invalid calendar/leap-second/timezone cases, normalized instants outside range, missing timezone and >9 fractional digits reject. The precision precheck prevents Go's timestamp parser silently truncating excess fractional digits.
- Explicit null survives, but omission remains an admission error. Typed empty lists/maps retain declared element/value types even with no elements; invalid element method calls fail checking. Nested list/map/list/nullable-uint values round-trip, including empty collections and max uint64.
- Malicious source-looking strings remain activation data, not interpolated CEL source.
- Exercised declaration-depth, collection-cardinality, string-byte, total admitted-node and expression-byte bounds reject.
- CEL signed/unsigned arithmetic overflow and literal overflow appear as their actual eval/check errors, not false predicate results.

## Blocking/unsupported findings — not semantic successes

**124 expected control outcomes do not mean 124 product requirements passed. Five controls deliberately reproduce unsafe mathematical answers.** They record `semanticExpected` separately from the historical reproduction expectation and set `knownUnsafeSemanticMismatch: true`:

| Case | Mathematical expected | Actual CEL v0.32.0 |
| --- | --- | --- |
| dynamic double 9007199254740992 == int64 9007199254740993; raw profile | false | true |
| dynamic double 9007199254740992 < int64 9007199254740993; raw profile | true | false |
| same equality with CrossTypeNumericComparisons(false) | false | true |
| same ordering with CrossTypeNumericComparisons(false) | true | false |
| statically typed int64 9007199254740993 > double 9007199254740992 with cross-type option enabled | true | false |

This is not only unsafe JSON integer decoding: these requests intentionally admit an exact int64 and an exactly representable double independently, yet CEL's mixed comparator rounds the int64 to double. The pinned source explains it: `common/types/compare.go:23–45` converts `Int`/`Uint` to `Double` before comparing. `cel/cel_test.go:419–454` explicitly demonstrates that disabling cross-type numeric checking does not disable runtime comparisons of dyn operands.

**Options-only result:** `cel.CrossTypeNumericComparisons(false)` rejects statically typed `(int, double)` equality/ordering in the exercised cases; it does **not** make untyped/dynamic resource comparisons safe. A profile that promises unrestricted dynamic-resource mixed-domain comparisons with exact mathematical integer semantics is **not confirmed and fails these cases**. No replacement interpreter or claim of a numeric adapter fix is supplied.

### Feasible conservative admission strategy

The harness's default `strict` profile uses the real CEL checker with cross-type comparisons disabled, then inspects its native typed AST before constructing the normal CEL program. It rejects equality, ordering, membership and indexing whose operand types contain `dyn`/`any`/type parameters (recursively in collections); direct null equality remains allowed. This is **admission, not another evaluator**. Six exercised unsafe dynamic operation/escape controls reject at `numeric_admission` rather than emit wrong answers; static exact int ordering and explicit same-domain `int(resource.n)` comparison controls evaluate correctly.

Trade-off: this is deliberately conservative, rejecting benign dynamic string comparisons/indexing too. Schema-typed resource fields can avoid that restriction, but integration with the sibling catalog harness was not exercised here. Explicit user conversions (`double(exactInt)`, `int(fractionalDouble)`) retain CEL's normal possibly lossy conversion semantics; this guard is not a proof of arbitrary numerical intent or a way to recover precision already lost upstream. A production unrestricted dynamic profile remains a blocker unless its semantics are narrowed/admitted or a separately validated exact numeric adapter is developed.

### Nullable static guarantees

- `nullable(bool|string|int64|uint64|double)` uses CEL's actual `NullableType` primitive wrappers. The executed nullable-int controls accept both null and int, reject a string-only method statically, but **null arithmetic still checks and then errors at evaluation** (`no such overload: _+_`). No flow-sensitive null safety is claimed.
- CEL documents `NullableType` as primitive-only (`cel/decls.go:118–121`, `common/types/types.go:508`). This harness deliberately uses `dyn` for nullable timestamp/list/map and nested nullable wrappers instead of pretending they have full static union types. Host recursive admission remains strict, but CEL checking loses the underlying type at that nullable boundary. The executed nullable-list `startsWith` control compiles and errors at evaluation. Nullable timestamp null is exercised; the dyn strategy's every timestamp/map operation is not exhaustively tested.
- Therefore the approved recursive DTO is transport/admission-feasible, **not uniformly statically typed in this implementation**. Full nullable collection/timestamp typing is unresolved, not hidden as successful schema checking.

## Settings and boundaries

Configured experiment settings: JSON-lines scanner ≤1 MiB per line; raw JSON nesting ≤64; declarations ≤128; declaration/value recursion ≤24; declaration node budget 4096; shared binding+resource value node budget 4096; collection cardinality ≤1024; string/map-key bytes ≤65536; expression bytes ≤16384; parser recursion ≤64; CEL runtime cost limit 100000. Tests explicitly exercise only the bounds named above; scanner-limit handling is configured but not a tested case. An overlong scanner line emits an input error and exits nonzero; it does not attempt unsafe line recovery.

Result serialization is tagged and preserves integer/timestamp precision. The evaluator permits nonboolean expressions solely to test round-trip precision; this does not establish the final boolean-only resource-predicate profile. Requests carry declarations separately from bindings, but program caching/reuse, Wails generation, platform/browser transport, completion, catalog registration and production scheduling were not exercised. Decimal arithmetic remains unsupported. Source is a retained throwaway feasibility harness, not product code.
