package main

import (
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"os"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"time"

	"cel.dev/cel-go/cel"
	"cel.dev/cel-go/common/ast"
	"cel.dev/cel-go/common/types"
	"cel.dev/cel-go/common/types/ref"
	"cel.dev/cel-go/common/types/traits"
)

const maxDepth = 24
const maxNodes = 4096
const maxItems = 1024
const maxString = 65536
const maxLine = 1048576

var signed = regexp.MustCompile(`^(0|-[1-9][0-9]*|[1-9][0-9]*)$`)
var unsigned = regexp.MustCompile(`^(0|[1-9][0-9]*)$`)
var ident = regexp.MustCompile(`^[A-Za-z_][A-Za-z0-9_]*$`)
var timestamp = regexp.MustCompile(`^([0-9]{4})-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(\.[0-9]{1,9})?(Z|[+-]([01][0-9]|2[0-3]):[0-5][0-9])$`)
var reserved = map[string]bool{"resource": true, "true": true, "false": true, "null": true, "in": true, "as": true, "break": true, "const": true, "continue": true, "else": true, "for": true, "function": true, "if": true, "import": true, "let": true, "loop": true, "namespace": true, "package": true, "return": true, "var": true, "void": true, "while": true, "dyn": true, "int": true, "uint": true, "double": true, "bool": true, "string": true, "timestamp": true, "duration": true, "bytes": true, "type": true, "size": true, "has": true}

type BindingType struct {
	Kind  string
	Child *BindingType
}
type budget struct{ nodes int }

func (b *budget) take(depth int) error {
	b.nodes++
	if depth > maxDepth {
		return fmt.Errorf("depth exceeds %d", maxDepth)
	}
	if b.nodes > maxNodes {
		return fmt.Errorf("nodes exceed %d", maxNodes)
	}
	return nil
}
func object(v any) (map[string]any, error) {
	m, ok := v.(map[string]any)
	if !ok || m == nil {
		return nil, fmt.Errorf("expected object")
	}
	return m, nil
}
func fields(m map[string]any, required ...string) error {
	if len(m) != len(required) {
		return fmt.Errorf("unexpected/missing object fields")
	}
	for _, k := range required {
		if _, ok := m[k]; !ok {
			return fmt.Errorf("missing field %s", k)
		}
	}
	return nil
}

// Decode recursively with token-level duplicate detection, not Unmarshal's last-key-wins.
func jsonValue(d *json.Decoder, depth int) (any, error) {
	if depth > 64 {
		return nil, fmt.Errorf("JSON depth exceeds 64")
	}
	t, e := d.Token()
	if e != nil {
		return nil, e
	}
	switch delim := t.(type) {
	case json.Delim:
		switch delim {
		case '{':
			m := map[string]any{}
			for d.More() {
				k, e := d.Token()
				if e != nil {
					return nil, e
				}
				key, ok := k.(string)
				if !ok {
					return nil, fmt.Errorf("object key is not string")
				}
				if _, found := m[key]; found {
					return nil, fmt.Errorf("duplicate key %q", key)
				}
				v, e := jsonValue(d, depth+1)
				if e != nil {
					return nil, e
				}
				m[key] = v
			}
			_, e = d.Token()
			return m, e
		case '[':
			a := []any{}
			for d.More() {
				v, e := jsonValue(d, depth+1)
				if e != nil {
					return nil, e
				}
				a = append(a, v)
			}
			_, e = d.Token()
			return a, e
		default:
			return nil, fmt.Errorf("unexpected delimiter")
		}
	}
	return t, nil
}
func parseJSON(line []byte) (map[string]any, error) {
	d := json.NewDecoder(bytes.NewReader(line))
	d.UseNumber()
	v, e := jsonValue(d, 0)
	if e != nil {
		return nil, e
	}
	if _, e = d.Token(); e != io.EOF {
		return nil, fmt.Errorf("trailing JSON input")
	}
	return object(v)
}
func parseType(v any, b *budget, depth int) (*BindingType, error) {
	if e := b.take(depth); e != nil {
		return nil, e
	}
	m, e := object(v)
	if e != nil {
		return nil, e
	}
	k, ok := m["kind"].(string)
	if !ok {
		return nil, fmt.Errorf("type kind must be string")
	}
	t := &BindingType{Kind: k}
	switch k {
	case "bool", "string", "int64", "uint64", "double", "timestamp":
		e = fields(m, "kind")
	case "list", "map", "nullable":
		childKey := "value"
		if k == "list" {
			childKey = "element"
		}
		if e = fields(m, "kind", childKey); e == nil {
			t.Child, e = parseType(m[childKey], b, depth+1)
		}
	default:
		e = fmt.Errorf("unsupported type kind %q", k)
	}
	return t, e
}
func (t *BindingType) celType() *cel.Type {
	switch t.Kind {
	case "bool":
		return cel.BoolType
	case "string":
		return cel.StringType
	case "int64":
		return cel.IntType
	case "uint64":
		return cel.UintType
	case "double":
		return cel.DoubleType
	case "timestamp":
		return cel.TimestampType
	case "list":
		return cel.ListType(t.Child.celType())
	case "map":
		return cel.MapType(cel.StringType, t.Child.celType())
	case "nullable":
		switch t.Child.Kind {
		case "bool", "string", "int64", "uint64", "double":
			return cel.NullableType(t.Child.celType())
		default:
			return cel.DynType
		}
	}
	panic("validated type")
}
func bound(v any, t *BindingType, b *budget, depth int) (any, error) {
	if e := b.take(depth); e != nil {
		return nil, e
	}
	m, e := object(v)
	if e != nil {
		return nil, e
	}
	k, ok := m["kind"].(string)
	if !ok {
		return nil, fmt.Errorf("bound kind must be string")
	}
	if k == "null" {
		if e = fields(m, "kind"); e != nil {
			return nil, e
		}
		if t != nil && t.Kind != "nullable" {
			return nil, fmt.Errorf("explicit null requires nullable declaration")
		}
		return nil, nil
	}
	if e = fields(m, "kind", "value"); e != nil {
		return nil, e
	}
	if t != nil {
		for t.Kind == "nullable" {
			t = t.Child
		}
		if t.Kind != k {
			return nil, fmt.Errorf("expected kind %s, got %s", t.Kind, k)
		}
	}
	x := m["value"]
	switch k {
	case "bool":
		r, ok := x.(bool)
		if !ok {
			return nil, fmt.Errorf("bool value must be boolean")
		}
		return r, nil
	case "string":
		r, ok := x.(string)
		if !ok || len(r) > maxString {
			return nil, fmt.Errorf("string value invalid or exceeds byte bound")
		}
		return r, nil
	case "int64", "uint64":
		s, ok := x.(string)
		if !ok {
			return nil, fmt.Errorf("integer value must be canonical decimal string")
		}
		if k == "int64" {
			if !signed.MatchString(s) {
				return nil, fmt.Errorf("noncanonical signed integer")
			}
			r, e := strconv.ParseInt(s, 10, 64)
			return r, e
		}
		if !unsigned.MatchString(s) {
			return nil, fmt.Errorf("noncanonical unsigned integer")
		}
		r, e := strconv.ParseUint(s, 10, 64)
		return r, e
	case "double":
		n, ok := x.(json.Number)
		if !ok {
			return nil, fmt.Errorf("double must be JSON number")
		}
		r, e := n.Float64()
		if e != nil || math.IsNaN(r) || math.IsInf(r, 0) {
			return nil, fmt.Errorf("double must be finite and representable")
		}
		return r, nil
	case "timestamp":
		s, ok := x.(string)
		if !ok || !timestamp.MatchString(s) {
			return nil, fmt.Errorf("timestamp requires RFC3339 timezone and at most 9 fractional digits")
		}
		r, e := time.Parse(time.RFC3339Nano, s)
		if e != nil {
			return nil, e
		}
		r = r.UTC()
		if r.Year() < 1 || r.Year() > 9999 {
			return nil, fmt.Errorf("timestamp UTC instant out of CEL range")
		}
		return r, nil
	case "list":
		a, ok := x.([]any)
		if !ok || len(a) > maxItems {
			return nil, fmt.Errorf("list invalid or exceeds %d items", maxItems)
		}
		out := make([]any, len(a))
		for i, v := range a {
			var child *BindingType
			if t != nil {
				child = t.Child
			}
			out[i], e = bound(v, child, b, depth+1)
			if e != nil {
				return nil, fmt.Errorf("list[%d]: %w", i, e)
			}
		}
		return out, nil
	case "map":
		a, e := object(x)
		if e != nil || len(a) > maxItems {
			return nil, fmt.Errorf("map invalid or exceeds %d items", maxItems)
		}
		out := make(map[string]any, len(a))
		for key, v := range a {
			if len(key) > maxString {
				return nil, fmt.Errorf("map key too long")
			}
			var child *BindingType
			if t != nil {
				child = t.Child
			}
			out[key], e = bound(v, child, b, depth+1)
			if e != nil {
				return nil, fmt.Errorf("map[%q]: %w", key, e)
			}
		}
		return out, nil
	default:
		return nil, fmt.Errorf("unknown bound kind %q", k)
	}
}
func hasDyn(t *types.Type) bool {
	if t == nil || t.Kind() == types.DynKind || t.Kind() == types.AnyKind || t.Kind() == types.TypeParamKind {
		return true
	}
	for _, p := range t.Parameters() {
		if hasDyn(p) {
			return true
		}
	}
	return false
}

// Type-driven AST admission, not an interpreter. Conservative dyn comparison ban
// includes equality, ordering, membership and indexing, including aggregate elements.
func numericAdmission(a *cel.Ast) error {
	var failure error
	native := a.NativeRep()
	ast.PostOrderVisit(native.Expr(), ast.NewExprVisitor(func(e ast.Expr) {
		if failure != nil || e.Kind() != ast.CallKind {
			return
		}
		c := e.AsCall()
		fn := c.FunctionName()
		switch fn {
		case "_==_", "_!=_", "_<_", "_<=_", "_>_", "_>=_", "@in", "_in_", "_[_]":
		default:
			return
		}
		args := c.Args()
		if (fn == "_==_" || fn == "_!=_") && len(args) == 2 {
			if native.GetType(args[0].ID()).Kind() == types.NullTypeKind || native.GetType(args[1].ID()).Kind() == types.NullTypeKind {
				return
			}
		}
		for _, arg := range args {
			t := native.GetType(arg.ID())
			if hasDyn(t) {
				failure = fmt.Errorf("strict profile rejects %s with dynamic operand type %s; use catalog typing or explicit same-domain conversion", fn, t)
				return
			}
		}
	}))
	return failure
}
func encode(v ref.Val) (map[string]any, error) {
	wrap := func(k string, x any) map[string]any { return map[string]any{"kind": k, "value": x} }
	switch x := v.(type) {
	case types.Null:
		return map[string]any{"kind": "null"}, nil
	case types.Bool:
		return wrap("bool", bool(x)), nil
	case types.String:
		return wrap("string", string(x)), nil
	case types.Int:
		return wrap("int64", strconv.FormatInt(int64(x), 10)), nil
	case types.Uint:
		return wrap("uint64", strconv.FormatUint(uint64(x), 10)), nil
	case types.Double:
		if math.IsNaN(float64(x)) || math.IsInf(float64(x), 0) {
			return nil, fmt.Errorf("CEL returned nonfinite double")
		}
		return wrap("double", float64(x)), nil
	case types.Timestamp:
		return wrap("timestamp", x.Time.UTC().Format(time.RFC3339Nano)), nil
	case traits.Lister:
		a := make([]any, 0)
		it := x.Iterator()
		for it.HasNext() == types.True {
			encoded, e := encode(it.Next())
			if e != nil {
				return nil, e
			}
			a = append(a, encoded)
		}
		return wrap("list", a), nil
	case traits.Mapper:
		m := map[string]any{}
		it := x.Iterator()
		for it.HasNext() == types.True {
			key := it.Next()
			s, ok := key.(types.String)
			if !ok {
				return nil, fmt.Errorf("result map key is not string")
			}
			encoded, e := encode(x.Get(key))
			if e != nil {
				return nil, e
			}
			m[string(s)] = encoded
		}
		return wrap("map", m), nil
	default:
		return nil, fmt.Errorf("unsupported CEL result type %s", v.Type())
	}
}
func evaluate(line []byte) map[string]any {
	r := map[string]any{"goVersion": runtime.Version()}
	fail := func(stage string, e error) map[string]any { r["stage"] = stage; r["error"] = e.Error(); return r }
	request, e := parseJSON(line)
	if e != nil {
		// Invalid JSON cannot be trusted for activation, but retrieve id solely for pairing diagnostic.
		var envelope struct {
			ID string `json:"id"`
		}
		_ = json.Unmarshal(line, &envelope)
		r["id"] = envelope.ID
		return fail("input", e)
	}
	r["id"] = request["id"]
	for k := range request {
		switch k {
		case "id", "declarations", "bindings", "expression", "profile", "resource", "semanticExpected", "rawDuplicate":
		default:
			return fail("input", fmt.Errorf("unknown request field %s", k))
		}
	}
	expr, ok := request["expression"].(string)
	if !ok || len(expr) > 16384 {
		return fail("input", fmt.Errorf("expression invalid or exceeds 16384 bytes"))
	}
	profile := "strict"
	if p, ok := request["profile"].(string); ok {
		profile = p
	}
	if profile != "strict" && profile != "checked" && profile != "raw" {
		return fail("input", fmt.Errorf("unknown profile"))
	}
	decls, e := object(request["declarations"])
	if e != nil || len(decls) > 128 {
		return fail("declaration", fmt.Errorf("declarations invalid or exceeds 128"))
	}
	opts := []cel.EnvOption{cel.CrossTypeNumericComparisons(profile == "raw"), cel.Variable("resource", cel.MapType(cel.StringType, cel.DynType)), cel.ParserRecursionLimit(64), cel.ParserExpressionSizeLimit(16384)}
	ts := map[string]*BindingType{}
	static := map[string]string{}
	db := &budget{}
	for name, v := range decls {
		if !ident.MatchString(name) || reserved[name] {
			return fail("declaration", fmt.Errorf("invalid or reserved parameter identifier %q", name))
		}
		t, e := parseType(v, db, 0)
		if e != nil {
			return fail("declaration", fmt.Errorf("%s: %w", name, e))
		}
		ts[name] = t
		ct := t.celType()
		opts = append(opts, cel.Variable(name, ct))
		static[name] = ct.String()
	}
	r["staticTypes"] = static
	r["profile"] = profile
	bindings, e := object(request["bindings"])
	if e != nil {
		return fail("admission", e)
	}
	if len(bindings) != len(ts) {
		return fail("admission", fmt.Errorf("missing/extra binding count"))
	}
	activation := map[string]any{}
	vb := &budget{}
	for name, v := range bindings {
		t, ok := ts[name]
		if !ok {
			return fail("admission", fmt.Errorf("extra binding %s", name))
		}
		activation[name], e = bound(v, t, vb, 0)
		if e != nil {
			return fail("admission", fmt.Errorf("%s: %w", name, e))
		}
	}
	activation["resource"] = map[string]any{}
	if v, ok := request["resource"]; ok {
		activation["resource"], e = bound(v, nil, vb, 0)
		if e != nil {
			return fail("admission", fmt.Errorf("resource: %w", e))
		}
		if _, ok := activation["resource"].(map[string]any); !ok {
			return fail("admission", fmt.Errorf("resource must be map"))
		}
	}
	env, e := cel.NewEnv(opts...)
	if e != nil {
		return fail("compile", e)
	}
	a, issues := env.Compile(expr)
	if issues.Err() != nil {
		return fail("compile", issues.Err())
	}
	r["outputType"] = a.OutputType().String()
	if profile == "strict" {
		if e = numericAdmission(a); e != nil {
			return fail("numeric_admission", e)
		}
	}
	program, e := env.Program(a, cel.CostLimit(100000))
	if e != nil {
		return fail("program", e)
	}
	v, _, e := program.Eval(activation)
	if e != nil {
		return fail("eval", e)
	}
	encoded, e := encode(v)
	if e != nil {
		return fail("result_encoding", e)
	}
	r["stage"] = "result"
	r["value"] = encoded
	return r
}
func main() {
	s := bufio.NewScanner(os.Stdin)
	s.Buffer(make([]byte, 65536), maxLine)
	out := json.NewEncoder(os.Stdout)
	for s.Scan() {
		if strings.TrimSpace(s.Text()) == "" {
			continue
		}
		if e := out.Encode(evaluate(s.Bytes())); e != nil {
			fmt.Fprintln(os.Stderr, e)
			os.Exit(1)
		}
	}
	if e := s.Err(); e != nil {
		_ = out.Encode(map[string]any{"stage": "input", "error": e.Error()})
		os.Exit(1)
	}
}
