// Real Bun -> JSON-lines -> Go -> JSON -> Bun consumer. No Wails/IPC claim.
import { isDeepStrictEqual } from 'node:util';
type Json = null | boolean | number | string | Json[] | { [key: string]: Json };
type JsonObject = { [key: string]: Json };
type Expected = { stage: string; value?: Json };
const scalar = (kind: string) => ({kind});
const list = (element: Json) => ({kind:'list',element});
const map = (value: Json) => ({kind:'map',value});
const nullable = (value: Json) => ({kind:'nullable',value});
const val = (kind: string, value?: Json): JsonObject => kind === 'null' ? {kind} : {kind,value:value ?? null};
const I=scalar('int64'), U=scalar('uint64'), D=scalar('double'), S=scalar('string'), B=scalar('bool'), T=scalar('timestamp');
const cases: {request: JsonObject & {id:string}; expected: Expected}[]=[];
function add(id: string, declarations: Json, bindings: Json, expression: string, expected: Expected, extra: JsonObject={}) {
  cases.push({request:{id,declarations,bindings,expression,...extra}, expected});
}
function exact(id: string, type: Json, value: Json, expected=value) {add(id,{p:type},{p:value},'p',{stage:'result',value:expected});}
function reject(id: string, type: Json, value: Json, stage='admission', extra: JsonObject={}) {add(id,{p:type},{p:value},'p',{stage},extra);}
for(const s of ['-9223372036854775808','9223372036854775807','9007199254740991','9007199254740992','9007199254740993','-9007199254740993','0']) exact('int-roundtrip-'+s,I,val('int64',s));
for(const s of ['0','9007199254740992','9007199254740993','18446744073709551615']) exact('uint-roundtrip-'+s,U,val('uint64',s));
for(const s of ['9223372036854775808','-9223372036854775809','01','-0','+1','1.0','1e3',' 1','1 ','','--1']) reject('bad-int-'+JSON.stringify(s),I,val('int64',s));
for(const s of ['18446744073709551616','-1','-0','00','+1','1.5','1e2',' 1']) reject('bad-uint-'+JSON.stringify(s),U,val('uint64',s));
reject('integer-as-JSON-number',I,val('int64',9007199254740992));
for(const n of [0,-0,0.125,Number.MAX_VALUE,Number.MIN_VALUE]) exact('finite-double-'+(Object.is(n,-0)?'negative-zero':String(n)),D,val('double',n),val('double',n===0?0:n));
reject('double-overflow-json',D,val('double','__RAW_INFINITY__'));
reject('double-string',D,val('double','1.25'));
for(const n of [NaN,Infinity,-Infinity]) reject('JS-nonfinite-serialized-null-'+String(n),D,val('double',n));
reject('unknown-value-tag',I,val('decimal','1'));
reject('bool-no-coercion',B,val('bool','true'));
reject('string-no-coercion',S,val('string',1));
reject('scalar-no-list-coercion',list(I),val('int64','1'));
reject('malformed-list-payload',list(I),val('list',{}));
reject('malformed-map-payload',map(I),val('map',[]));
exact('bool',B,val('bool',true)); exact('string',S,val('string','雪🌱'));
const malicious='x\" || true || p == \"x';
add('malicious-string-is-data',{p:S},{p:val('string',malicious)},'p == "trusted"',{stage:'result',value:val('bool',false)});
exact('timestamp-nanosecond-timezone',T,val('timestamp','2026-10-17T21:22:23.123456789+05:30'),val('timestamp','2026-10-17T15:52:23.123456789Z'));
exact('timestamp-min',T,val('timestamp','0001-01-01T00:00:00Z'));
exact('timestamp-max',T,val('timestamp','9999-12-31T23:59:59.999999999Z'));
for(const s of ['2026-10-17T00:00:00','2026-10-17','0000-01-01T00:00:00Z','10000-01-01T00:00:00Z','2026-10-17T00:00:00.1234567891Z','2026-10-17T00:00:60Z','2026-10-17T00:00:00+24:00','0001-01-01T00:00:00+01:00','9999-12-31T23:59:59-01:00']) reject('bad-time-'+s,T,val('timestamp',s));
add('timestamp-equal-instant',{p:T},{p:val('timestamp','2026-10-17T21:22:23.123456789+05:30')},'p == timestamp("2026-10-17T15:52:23.123456789Z")',{stage:'result',value:val('bool',true)});
add('timestamp-subnanosecond-distinct',{p:T},{p:val('timestamp','2026-10-17T00:00:00.123456789Z')},'p != timestamp("2026-10-17T00:00:00.123456788Z")',{stage:'result',value:val('bool',true)});
exact('nullable-int-null',nullable(I),val('null'));
exact('nullable-int-value',nullable(I),val('int64','7'));
exact('nullable-list-null',nullable(list(I)),val('null'));
exact('nullable-list-value',nullable(list(I)),val('list',[val('int64','7')]));
exact('nullable-timestamp-null',nullable(T),val('null'));
add('nullable-is-explicit-null',{p:nullable(I)},{p:val('null')},'p == null',{stage:'result',value:val('bool',true)});
add('nullable-missing-is-not-null',{p:nullable(I)},{},'p == null',{stage:'admission'});
reject('nonnullable-null',I,val('null'));
reject('nullable-wrong-kind',nullable(I),val('double',1));
add('nullable-null-arithmetic-observed',{p:nullable(I)},{p:val('null')},'p + 1',{stage:'eval'});
add('nullable-primitive-static-check',{p:nullable(I)},{p:val('int64','1')},'p.startsWith("x")',{stage:'compile'});
add('nullable-collection-static-gap',{p:nullable(list(I))},{p:val('list',[])},'p.startsWith("x")',{stage:'eval'});
exact('typed-empty-list',list(I),val('list',[]));
exact('typed-empty-map',map(I),val('map',{}));
exact('nested-typed-collections',list(map(list(nullable(U)))),val('list',[val('map',{a:val('list',[val('uint64','18446744073709551615'),val('null')]),empty:val('list',[])})]));
reject('nested-wrong-type',list(map(list(I))),val('list',[val('map',{a:val('list',[val('double',1)])})]));
add('empty-list-retains-static-type',{p:list(I)},{p:val('list',[])},'p.exists(x, x.startsWith("x"))',{stage:'compile'});
add('empty-map-retains-static-type',{p:map(I)},{p:val('map',{})},'p["x"].startsWith("x")',{stage:'compile'});
add('wrong-binding-type',{p:I},{p:val('string','1')},'p',{stage:'admission'});
add('extra-binding',{p:I},{p:val('int64','1'),q:val('int64','2')},'p',{stage:'admission'});
add('missing-binding',{p:I},{},'p',{stage:'admission'});
add('invalid-name',{'not.valid':I},{'not.valid':val('int64','1')},'true',{stage:'declaration'});
for (const name of ['resource','true','null','in','dyn']) add('reserved-name-'+name,{[name]:I},{[name]:val('int64','1')},'true',{stage:'declaration'});
add('unknown-declaration-kind',{p:{kind:'decimal'}},{p:val('string','1')},'p',{stage:'declaration'});
add('extra-declaration-property',{p:{kind:'int64',element:I}},{p:val('int64','1')},'p',{stage:'declaration'});
add('nullable-null-inner-invalid',{p:nullable({kind:'null'})},{p:val('null')},'p',{stage:'declaration'});
add('duplicate-declaration-json',{p:I},{p:val('int64','1')},'p',{stage:'input'}, {rawDuplicate:true});
reject('extra-value-property',I,{kind:'int64',value:'1',extra:2});
reject('null-with-value',nullable(I),{kind:'null',value:null});
let nestedType:Json=I, nestedValue:Json=val('int64','1');
for(let n=0;n<26;n++){nestedType=list(nestedType); nestedValue=val('list',[nestedValue]);}
add('declaration-depth-bound',{p:nestedType},{p:nestedValue},'p',{stage:'declaration'});
add('collection-size-bound',{p:list(I)},{p:val('list',Array.from({length:1025},()=>val('int64','1')))},'p',{stage:'admission'});
add('string-size-bound',{p:S},{p:val('string','x'.repeat(65537))},'p',{stage:'admission'});
add('node-budget-bound',{p:list(list(I))},{p:val('list',Array.from({length:5},()=>val('list',Array.from({length:900},()=>val('int64','1')))))},'p',{stage:'admission'});
add('expression-size-bound',{}, {},' '.repeat(16385)+'true',{stage:'input'});
add('int-arithmetic-overflow',{}, {},'9223372036854775807 + 1',{stage:'eval'});
add('uint-arithmetic-overflow',{}, {},'18446744073709551615u + 1u',{stage:'eval'});
add('CEL-int-literal-overflow',{}, {},'9223372036854775808',{stage:'compile'});
add('CEL-uint-literal-overflow',{}, {},'18446744073709551616u',{stage:'compile'});
add('double-result-nonfinite',{}, {},'1.0 / 0.0',{stage:'result_encoding'});
// Reproduce prior unsafe result; the mathematically correct expected answer is false.
for(const profile of ['raw','checked']) {
 add(profile+'-unsafe-dynamic-equality',{exact:I},{exact:val('int64','9007199254740993')},'resource.n == exact',{stage:'result',value:val('bool',true)},{profile,resource:val('map',{n:val('double',9007199254740992)}),semanticExpected:val('bool',false)});
 add(profile+'-unsafe-dynamic-ordering',{exact:I},{exact:val('int64','9007199254740993')},'resource.n < exact',{stage:'result',value:val('bool',false)},{profile,resource:val('map',{n:val('double',9007199254740992)}),semanticExpected:val('bool',true)});
}
add('typed-default-mixed-equality',{p:I,q:D},{p:val('int64','9007199254740993'),q:val('double',9007199254740992)},'p == q',{stage:'compile'},{profile:'checked'});
add('typed-default-mixed-ordering',{p:I,q:D},{p:val('int64','9007199254740993'),q:val('double',9007199254740992)},'p > q',{stage:'compile'},{profile:'checked'});
add('typed-optin-mixed-ordering-unsafe',{p:I,q:D},{p:val('int64','9007199254740993'),q:val('double',9007199254740992)},'p > q',{stage:'result',value:val('bool',false)},{profile:'raw',semanticExpected:val('bool',true)});
add('strict-dynamic-numeric-rejected',{exact:I},{exact:val('int64','9007199254740993')},'resource.n == exact',{stage:'numeric_admission'},{resource:val('map',{n:val('double',9007199254740992)})});
add('strict-dyn-escape-rejected',{p:I},{p:val('int64','9007199254740993')},'dyn(p) == 9007199254740992.0',{stage:'numeric_admission'});
add('strict-dynamic-aggregate-rejected',{p:list(I)},{p:val('list',[val('int64','9007199254740993')])},'dyn(p) == [9007199254740992.0]',{stage:'numeric_admission'});
add('strict-dynamic-ordering-rejected',{p:I},{p:val('int64','1')},'resource.n < p',{stage:'numeric_admission'},{resource:val('map',{n:val('double',0)})});
add('strict-dynamic-membership-rejected',{p:I},{p:val('int64','9007199254740993')},'p in resource.ns',{stage:'numeric_admission'},{resource:val('map',{ns:val('list',[val('double',9007199254740992)])})});
add('strict-dynamic-index-rejected',{p:map(I)},{p:val('map',{a:val('int64','1')})},'p[resource.key] == 1',{stage:'numeric_admission'},{resource:val('map',{key:val('string','a')})});
add('strict-explicit-same-domain',{p:I},{p:val('int64','9007199254740993')},'int(resource.n) < p',{stage:'result',value:val('bool',true)},{resource:val('map',{n:val('double',9007199254740992)})});
add('strict-exact-resource-admission',{p:I},{p:val('int64','9007199254740993')},'int(resource.n) == p',{stage:'result',value:val('bool',true)},{resource:val('map',{n:val('int64','9007199254740993')})});
add('strict-static-exact-ordering',{p:I,q:I},{p:val('int64','9007199254740993'),q:val('int64','9007199254740992')},'p > q',{stage:'result',value:val('bool',true)});
add('strict-null-presence-allowed',{}, {},'has(resource.n) && resource.n == null',{stage:'result',value:val('bool',true)},{resource:val('map',{n:val('null')})});
const payload = cases.map(({request})=> {
 let line=JSON.stringify(request);
 if(request.rawDuplicate) line=line.replace('"declarations":{','"declarations":{"p":{"kind":"double"},');
 return line.replace('"__RAW_INFINITY__"','1e309');
}).join('\n')+'\n';
await Bun.write(new URL('requests.jsonl',import.meta.url),payload);
const proc=Bun.spawn(['./evaluator'],{cwd:import.meta.dir,stdin:'pipe',stdout:'pipe',stderr:'pipe'});
proc.stdin.write(payload);proc.stdin.end();
const stdout=await new Response(proc.stdout).text();
const stderr=await new Response(proc.stderr).text();
const exit=await proc.exited;
await Bun.write(new URL('responses.jsonl',import.meta.url),stdout);
function isJson(value: unknown): value is Json {
 if(value===null || typeof value==='string' || typeof value==='boolean') return true;
 if(typeof value==='number') return Number.isFinite(value);
 if(Array.isArray(value)) return value.every(isJson);
 return typeof value==='object' && Object.values(value).every(isJson);
}
const responses=stdout.trim().split('\n').map(s=>{
 const value:unknown=JSON.parse(s);
 if(!isJson(value)||value===null||Array.isArray(value)||typeof value!=='object'||typeof value.stage!=='string') throw new Error('Invalid evaluator response');
 return value;
});
const checks=cases.map(({request,expected},index)=>{
 const actual=responses[index];
 const pass=actual?.id===request.id && actual?.stage===expected.stage && (!('value' in expected)||isDeepStrictEqual(actual.value,expected.value));
 return {id:request.id,expected,actual,pass,...(request.semanticExpected?{semanticExpected:request.semanticExpected,knownUnsafeSemanticMismatch:!isDeepStrictEqual(actual?.value,request.semanticExpected)}:{})};
});
const failures=checks.filter(c=>!c.pass);
const results={runtime:{bun:Bun.version,go:responses[0]?.goVersion,cel:'cel.dev/cel-go v0.32.0'},process:{exit,stderr},count:checks.length,failures:failures.length+(exit!==0?1:0)+(responses.length!==cases.length?1:0),checks};
await Bun.write(new URL('results.json',import.meta.url),JSON.stringify(results,null,2)+'\n');
for(const c of checks) console.log(JSON.stringify(c));
console.log(JSON.stringify({summary:{checks:checks.length,failures:results.failures,goExit:exit}}));
if(results.failures) process.exit(1);
