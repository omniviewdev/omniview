package main

import (
	"encoding/json"
	"fmt"
	"math"
	"reflect"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"

	"cel.dev/cel-go/common/types"
	"cel.dev/cel-go/common/types/ref"
	"cel.dev/cel-go/common/types/traits"
)

// This normalized fixture dialect is deliberately smaller than JSON Schema.
type Schema struct {
	Kind     string             `json:"kind"`
	Ref      string             `json:"ref,omitempty"`
	Fields   map[string]*Schema `json:"fields,omitempty"`
	Element  *Schema            `json:"element,omitempty"`
	Value    *Schema            `json:"value,omitempty"`
	Variants []*Schema          `json:"variants,omitempty"`
	Optional bool               `json:"optional,omitempty"`
	Additional *Schema `json:"additional,omitempty"`
	Const *string `json:"const,omitempty"`
	Discriminator string `json:"discriminator,omitempty"`
	Unsupported []string `json:"unsupported,omitempty"`
}
type Representation struct {
	Schema      string   `json:"schema"`
	Complete    bool     `json:"complete"`
	KnownAbsent []string `json:"knownAbsent,omitempty"`
	Data        any      `json:"data"`
}
type Fixture struct {
	Description string                    `json:"description"`
	Definitions map[string]*Schema        `json:"definitions"`
	Resources   map[string]Representation `json:"resources"`
}

const (
	maxDepth      = 12
	maxNodes      = 512
	maxCollection = 64
	maxString     = 16384
)

var integerLexeme = regexp.MustCompile(`^-?(0|[1-9][0-9]*)$`)
var unsignedLexeme = regexp.MustCompile(`^(0|[1-9][0-9]*)$`)

type Catalog struct {
	defs     map[string]*Schema
	names    map[*Schema]string
	objects  map[string]*Schema
	fallback *types.Registry
}

func newCatalog(defs map[string]*Schema) (*Catalog, error) {
	base, err := types.NewRegistry()
	if err != nil {
		return nil, err
	}
	c := &Catalog{defs: defs, names: map[*Schema]string{}, objects: map[string]*Schema{}, fallback: base}
	if len(defs) > 32 {
		return nil, fmt.Errorf("catalog definition bound")
	}
	keys := make([]string, 0, len(defs))
	for k := range defs {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	count := 0
	var visit func(*Schema, string, int) error
	visit = func(s *Schema, name string, depth int) error {
		count++
		if s == nil || depth > maxDepth || count > maxNodes {
			return fmt.Errorf("schema bound or missing child at %s", name)
		}
		if err := supportedFields(s); err != nil { return err }
		if len(s.Unsupported) != 0 {
			return fmt.Errorf("unsupported constraints at %s: %v", name, s.Unsupported)
		}
		if s.Const != nil && s.Kind != "string" {
			return fmt.Errorf("const supported only for string")
		}
		if s.Discriminator != "" && s.Kind != "anyOf" && s.Kind != "oneOf" {
			return fmt.Errorf("discriminator requires explicit union")
		}
		switch s.Kind {
		case "object":
			if len(s.Fields) > maxCollection {
				return fmt.Errorf("schema field bound")
			}
			c.names[s] = name
			c.objects[name] = s
			fields := make([]string, 0, len(s.Fields))
			for f := range s.Fields {
				fields = append(fields, f)
			}
			sort.Strings(fields)
			for _, f := range fields {
				if err := visit(s.Fields[f], name+"_"+f, depth+1); err != nil {
					return err
				}
			}
			if s.Additional != nil {
				return visit(s.Additional, name+"_additional", depth+1)
			}
		case "list":
			return visit(s.Element, name+"_item", depth+1)
		case "map", "nullable":
			return visit(s.Value, name+"_value", depth+1)
		case "anyOf", "oneOf":
			if len(s.Variants) < 2 || len(s.Variants) > 4 {
				return fmt.Errorf("union branch bound")
			}
			for i, v := range s.Variants {
				if err := visit(v, fmt.Sprintf("%s_branch%d", name, i), depth+1); err != nil {
					return err
				}
			}
		case "ref":
			if _, ok := defs[s.Ref]; !ok {
				return fmt.Errorf("unresolved schema ref %s", s.Ref)
			}
		case "bool", "string", "int64", "uint64", "double", "timestamp", "dynamic":
		default:
			return fmt.Errorf("unsupported schema kind %s", s.Kind)
		}
		return nil
	}
	for _, name := range keys {
		if err := visit(defs[name], "catalog."+name, 0); err != nil {
			return nil, err
		}
	}
	// References remain edges, not expanded trees. Reject ref-only cycles without expanding object recursion.
	for _, s := range defs {
		seen := map[*Schema]bool{}
		for s.Kind == "ref" {
			if seen[s] {
				return nil, fmt.Errorf("ref-only cycle")
			}
			seen[s] = true
			s = defs[s.Ref]
		}
	}
	if err := c.validateUnionMetadata(); err != nil { return nil, err }
	return c, nil
}
func (c *Catalog) resolve(s *Schema) *Schema {
	for s.Kind == "ref" {
		s = c.defs[s.Ref]
	}
	return s
}
func (c *Catalog) celType(s *Schema) *types.Type {
	s = c.resolve(s)
	switch s.Kind {
	case "object":
		return types.NewObjectType(c.names[s], traits.IndexerType, traits.FieldTesterType)
	case "bool":
		return types.BoolType
	case "string":
		return types.StringType
	case "int64":
		return types.IntType
	case "uint64":
		return types.UintType
	case "double":
		return types.DoubleType
	case "timestamp":
		return types.TimestampType
	case "list":
		return types.NewListType(c.celType(s.Element))
	case "map":
		return types.NewMapType(types.StringType, c.celType(s.Value))
	case "nullable":
		switch c.resolve(s.Value).Kind {
		case "bool", "string", "int64", "uint64", "double":
			return types.NewNullableType(c.celType(s.Value))
		default:
			return types.DynType
		}
	// Nullable complex types, unions and opaque branches deliberately weaken to dyn.
	default:
		return types.DynType
	}
}
func (c *Catalog) EnumValue(n string) ref.Val { return c.fallback.EnumValue(n) }
func (c *Catalog) FindIdent(n string) (ref.Val, bool) {
	if _, ok := c.objects[n]; ok {
		return types.NewObjectType(n, traits.IndexerType, traits.FieldTesterType), true
	}
	return c.fallback.FindIdent(n)
}
func (c *Catalog) FindStructType(n string) (*types.Type, bool) {
	if _, ok := c.objects[n]; ok {
		return types.NewTypeTypeWithParam(types.NewObjectType(n, traits.IndexerType, traits.FieldTesterType)), true
	}
	return c.fallback.FindStructType(n)
}
func (c *Catalog) FindStructFieldNames(n string) ([]string, bool) {
	s, ok := c.objects[n]
	if !ok {
		return c.fallback.FindStructFieldNames(n)
	}
	out := make([]string, 0, len(s.Fields))
	for k := range s.Fields {
		out = append(out, k)
	}
	sort.Strings(out)
	return out, true
}
func (c *Catalog) FindStructFieldType(n, f string) (*types.FieldType, bool) {
	s, ok := c.objects[n]
	if !ok {
		return c.fallback.FindStructFieldType(n, f)
	}
	field, ok := s.Fields[f]
	if !ok {
		field = s.Additional
		if field == nil { return nil, false }
	}
	return &types.FieldType{Type: c.celType(field)}, true
}
func (c *Catalog) NewValue(n string, fields map[string]ref.Val) ref.Val {
	return types.NewErr("catalog resource construction is not admitted: %s", n)
}
func (c *Catalog) NativeToValue(v any) ref.Val {
	if value, ok := v.(ref.Val); ok {
		return value
	}
	return types.DefaultTypeAdapter.NativeToValue(v)
}

type Object struct {
	catalog  *Catalog
	schema   *Schema
	fields   map[string]ref.Val
	path     string
	complete bool
	absent   map[string]bool
}

func (o *Object) Type() ref.Type { return o.catalog.celType(o.schema) }
func (o *Object) Value() any     { return o }
func (o *Object) ConvertToNative(t reflect.Type) (any, error) {
	if t == reflect.TypeOf(o) || t == reflect.TypeOf((*any)(nil)).Elem() {
		return o, nil
	}
	return nil, fmt.Errorf("catalog object native conversion unsupported: %v", t)
}
func (o *Object) ConvertToType(t ref.Type) ref.Val {
	if t == types.TypeType {
		return o.catalog.celType(o.schema)
	}
	if t.TypeName() == o.Type().TypeName() {
		return o
	}
	return types.NewErr("invalid object conversion")
}
func (o *Object) Equal(v ref.Val) ref.Val {
	other, ok := v.(*Object)
	if !ok || o.Type().TypeName() != other.Type().TypeName() {
		return types.False
	}
	if !o.complete || !other.complete {
		return types.NewErr("hydration-needed: equality of incomplete objects")
	}
	return types.Bool(reflect.DeepEqual(o.fields, other.fields))
}
func (o *Object) IsSet(key ref.Val) ref.Val {
	s, ok := key.(types.String)
	if !ok {
		return types.NewErr("field key must be string")
	}
	name := string(s)
	if _, ok := o.schema.Fields[name]; !ok && o.schema.Additional == nil {
		return types.NewErr("unknown field %s", name)
	}
	if _, ok := o.fields[name]; ok {
		return types.True
	}
	if o.complete || o.absent[o.path+"."+name] {
		return types.False
	}
	return types.NewErr("hydration-needed: %s.%s", o.path, name)
}
func (o *Object) Get(key ref.Val) ref.Val {
	present := o.IsSet(key)
	if types.IsError(present) {
		return present
	}
	if present == types.False {
		return types.NewErr("absent field: %s.%s", o.path, key)
	}
	return o.fields[string(key.(types.String))]
}

type admission struct {
	c        *Catalog
	complete bool
	absent   map[string]bool
	nodes    int
}

func (c *Catalog) admit(r Representation) (ref.Val, error) {
	if !r.Complete && r.Schema == "" {
		return nil, fmt.Errorf("hydration-needed: incomplete no-schema representation")
	}
	state := &admission{c: c, complete: r.Complete, absent: map[string]bool{}}
	for _, p := range r.KnownAbsent {
		state.absent[p] = true
	}
	s := &Schema{Kind: "dynamic"}
	if r.Schema != "" {
		var ok bool
		s, ok = c.defs[r.Schema]
		if !ok {
			return nil, fmt.Errorf("unknown catalog schema %s", r.Schema)
		}
	}
	return state.value(s, r.Data, "resource", 0)
}
func (a *admission) value(s *Schema, v any, path string, depth int) (ref.Val, error) {
	a.nodes++
	if depth > maxDepth || a.nodes > maxNodes {
		return nil, fmt.Errorf("admission bound at %s", path)
	}
	s = a.c.resolve(s)
	fail := func(reason string) (ref.Val, error) { return nil, fmt.Errorf("%s: %s", path, reason) }
	if s.Const != nil && v != *s.Const {
		return fail("string const mismatch")
	}
	if s.Kind == "nullable" {
		if v == nil {
			return types.NullValue, nil
		}
		return a.value(s.Value, v, path, depth+1)
	}
	if s.Kind == "anyOf" || s.Kind == "oneOf" {
		if !a.complete {
			return fail("hydration-needed: union matching requires complete representation")
		}
		matches := []ref.Val{}
		for _, branch := range s.Variants {
			value, err := a.value(branch, v, path, depth+1)
			if err == nil {
				matches = append(matches, value)
			} else if strings.Contains(err.Error(), "bound") || strings.Contains(err.Error(), "hydration-needed") {
				return nil, err
			}
		}
		if len(matches) == 0 {
			return fail("zero matching " + s.Kind + " branches")
		}
		if s.Kind == "oneOf" && len(matches) != 1 {
			return fail(fmt.Sprintf("oneOf requires exactly one match; got %d", len(matches)))
		}
		return a.c.mergeMatches(matches), nil
	}
	if s.Kind == "dynamic" {
		switch v.(type) {
		case nil:
			return types.NullValue, nil
		case bool:
			s = &Schema{Kind: "bool"}
		case string:
			s = &Schema{Kind: "string"}
		case json.Number:
			if integerLexeme.MatchString(string(v.(json.Number))) {
				s = &Schema{Kind: "int64"}
			} else {
				s = &Schema{Kind: "double"}
			}
		case []any:
			s = &Schema{Kind: "list", Element: &Schema{Kind: "dynamic"}}
		case map[string]any:
			s = &Schema{Kind: "map", Value: &Schema{Kind: "dynamic"}}
		default:
			return fail("unsupported dynamic value")
		}
	}
	switch s.Kind {
	case "object":
		m, ok := v.(map[string]any)
		if !ok {
			return fail("expected object")
		}
		if len(m) > maxCollection {
			return fail("object field bound")
		}
		o := &Object{catalog: a.c, schema: s, fields: map[string]ref.Val{}, path: path, complete: a.complete, absent: a.absent}
		keys := make([]string, 0, len(m))
		for key := range m {
			keys = append(keys, key)
		}
		sort.Strings(keys)
		for _, key := range keys {
			field, ok := s.Fields[key]
			if !ok {
				field = s.Additional
				if field == nil {
					return fail("unknown input field " + key)
				}
			}
			if a.absent[path+"."+key] {
				return fail("completeness metadata contradicts present field " + key)
			}
			value, err := a.value(field, m[key], path+"."+key, depth+1)
			if err != nil {
				return nil, err
			}
			o.fields[key] = value
		}
		for key, field := range s.Fields {
			if _, ok := m[key]; !ok && !field.Optional && (a.complete || a.absent[path+"."+key]) {
				return fail("missing required field " + key)
			}
		}
		return o, nil
	case "map":
		if !a.complete {
			return fail("hydration-needed: incomplete maps need whole-map hydration")
		}
		m, ok := v.(map[string]any)
		if !ok {
			return fail("expected map")
		}
		if len(m) > maxCollection {
			return fail("map cardinality bound")
		}
		out := map[string]ref.Val{}
		keys := make([]string, 0, len(m))
		for key := range m {
			keys = append(keys, key)
		}
		sort.Strings(keys)
		for _, key := range keys {
			if len(key) > maxString {
				return fail("map key bound")
			}
			value, err := a.value(s.Value, m[key], path+"["+strconv.Quote(key)+"]", depth+1)
			if err != nil {
				return nil, err
			}
			out[key] = value
		}
		return types.NewStringInterfaceMap(a.c, toAnyMap(out)), nil
	case "list":
		if !a.complete {
			return fail("hydration-needed: incomplete lists need whole-list hydration")
		}
		list, ok := v.([]any)
		if !ok {
			return fail("expected list")
		}
		if len(list) > maxCollection {
			return fail("list cardinality bound")
		}
		out := make([]ref.Val, len(list))
		for i, item := range list {
			value, err := a.value(s.Element, item, fmt.Sprintf("%s[%d]", path, i), depth+1)
			if err != nil {
				return nil, err
			}
			out[i] = value
		}
		return types.NewRefValList(a.c, out), nil
	case "string":
		s, ok := v.(string)
		if !ok {
			return fail("expected string")
		}
		if len(s) > maxString {
			return fail("string bound")
		}
		return types.String(s), nil
	case "bool":
		b, ok := v.(bool)
		if !ok {
			return fail("expected bool")
		}
		return types.Bool(b), nil
	case "int64":
		n, ok := v.(json.Number)
		if !ok || !integerLexeme.MatchString(string(n)) {
			return fail("expected lexical int64")
		}
		i, err := strconv.ParseInt(string(n), 10, 64)
		if err != nil {
			return fail("int64 out of range")
		}
		return types.Int(i), nil
	case "uint64":
		n, ok := v.(json.Number)
		if !ok || !unsignedLexeme.MatchString(string(n)) {
			return fail("expected lexical uint64")
		}
		i, err := strconv.ParseUint(string(n), 10, 64)
		if err != nil {
			return fail("uint64 out of range")
		}
		return types.Uint(i), nil
	case "double":
		n, ok := v.(json.Number)
		if !ok {
			return fail("expected lexical double")
		}
		f, err := strconv.ParseFloat(string(n), 64)
		if err != nil || math.IsInf(f, 0) || math.IsNaN(f) {
			return fail("double nonfinite or out of range")
		}
		return types.Double(f), nil
	case "timestamp":
		s, ok := v.(string)
		if !ok {
			return fail("expected timestamp string")
		}
		t, err := time.Parse(time.RFC3339Nano, s)
		if err != nil {
			return fail("invalid RFC3339 timestamp")
		}
		return types.Timestamp{Time: t.UTC()}, nil
	}
	return fail("unsupported schema")
}
func toAnyMap(m map[string]ref.Val) map[string]any {
	out := make(map[string]any, len(m))
	for k, v := range m {
		out[k] = v
	}
	return out
}
