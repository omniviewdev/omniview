//go:build retentionprobe

package main

import (
 "encoding/json"
 "fmt"
 "os"
)

// Parent-owned throwaway smoke: run only adapter.go extensions.go retention_probe.go.
// Records prototype catalog retention; this is not a proposed production behavior.
func main() {
 root:=&Schema{Kind:"object",Fields:map[string]*Schema{"choice":{Kind:"anyOf",Variants:[]*Schema{
  {Kind:"object",Fields:map[string]*Schema{"x":{Kind:"string"}}},
  {Kind:"object",Fields:map[string]*Schema{"x":{Kind:"string"}}},
 }}}}
 catalog,err:=newCatalog(map[string]*Schema{"Root":root});if err!=nil{panic(err)}
 before:=len(catalog.names)
 const iterations=1000
 for range iterations {
  _,err=catalog.admit(Representation{Schema:"Root",Complete:true,Data:map[string]any{"choice":map[string]any{"x":"value"}}})
  if err!=nil{panic(err)}
 }
 after:=len(catalog.names)
 result:=map[string]any{"scope":"prototype overlap-dispatch catalog retention, not heap/RSS benchmark","iterations":iterations,"catalogNamesBefore":before,"catalogNamesAfter":after,"retainedEntries":after-before,"knownLimitation":after>before}
 data,err:=json.MarshalIndent(result,"","  ");if err!=nil{panic(err)}
 if err=os.WriteFile("retention-results.json",data,0600);err!=nil{panic(err)}
 fmt.Println(string(data))
}
