package main

import (
 "fmt"
 "cel.dev/cel-go/common/types/ref"
)

// No first-branch authoring/type selection: every successful object alternative
// contributes fields, including absent optional fields and additional properties.
// The union checker boundary stays dyn; this is only a runtime field-dispatch view.
func (c *Catalog) mergeMatches(values []ref.Val) ref.Val {
 if len(values) == 1 { return values[0] }
 first, ok := values[0].(*Object)
 if !ok { return values[0] } // Scalar/list/map alternatives retain their full value shape.
 merged := &Schema{Kind:"object", Fields:map[string]*Schema{}}
 out := &Object{catalog:c, schema:merged, fields:map[string]ref.Val{}, path:first.path, complete:first.complete, absent:first.absent}
 collected := map[string][]ref.Val{}
 for _, value := range values {
  object, ok := value.(*Object)
  if !ok { return values[0] } // Mixed object/map overlap is rejected at catalog boundary below.
  for key := range object.schema.Fields { merged.Fields[key] = &Schema{Kind:"dynamic", Optional:true} }
  if object.schema.Additional != nil { merged.Additional = &Schema{Kind:"dynamic"} }
  for key, v := range object.fields { collected[key] = append(collected[key],v); merged.Fields[key] = &Schema{Kind:"dynamic"} }
 }
 for key, matches := range collected { out.fields[key] = c.mergeMatches(matches) }
 c.names[merged] = "catalog.anyOfRuntime"
 return out
}

func supportedFields(s *Schema) error {
 if s.Additional != nil && s.Kind != "object" { return fmt.Errorf("unsupported additional constraint on %s",s.Kind) }
 if len(s.Fields)>0 && s.Kind!="object" { return fmt.Errorf("unsupported fields constraint on %s",s.Kind) }
 if len(s.Variants)>0 && s.Kind!="anyOf" && s.Kind!="oneOf" { return fmt.Errorf("unsupported variants constraint on %s",s.Kind) }
 if s.Element!=nil && s.Kind!="list" { return fmt.Errorf("unsupported element constraint on %s",s.Kind) }
 if s.Value!=nil && s.Kind!="map" && s.Kind!="nullable" { return fmt.Errorf("unsupported value constraint on %s",s.Kind) }
 if s.Ref!="" && s.Kind!="ref" { return fmt.Errorf("unsupported ref constraint on %s",s.Kind) }
 return nil
}

func (c *Catalog) validateUnionMetadata() error {
 seen:=map[*Schema]bool{}
 var visit func(*Schema) error
 visit=func(s *Schema) error {
  if seen[s] { return nil }; seen[s]=true
  if s.Discriminator!="" {
   for _, branch:=range s.Variants {
    b:=c.resolve(branch)
    if b.Kind!="object" { return fmt.Errorf("unsupported discriminator branch kind %s",b.Kind) }
    tag:=b.Fields[s.Discriminator]
    if tag==nil { return fmt.Errorf("discriminator field missing from branch") }
    tag=c.resolve(tag)
    if tag.Kind!="string" || tag.Const==nil || tag.Optional { return fmt.Errorf("discriminator must be required string const") }
   }
  }
  // Mixed object/map (or intentionally dynamic) alternatives can overlap but
  // require a general field-dispatch reconciliation not claimed by this probe.
  if s.Kind=="anyOf" || s.Kind=="oneOf" {
   object, open:=false,false
   for _, b:=range s.Variants { switch c.resolve(b).Kind { case "object":object=true; case "map","dynamic":open=true } }
   if object && open { return fmt.Errorf("unsupported mixed object/map/dynamic union dispatch") }
  }
  for _,b:=range s.Variants { if err:=visit(b);err!=nil{return err} }
  for _,f:=range s.Fields { if err:=visit(f);err!=nil{return err} }
  for _,child:=range []*Schema{s.Element,s.Value,s.Additional} { if child!=nil {if err:=visit(child);err!=nil{return err}} }
  return nil
 }
 for _,s:=range c.defs { if err:=visit(s);err!=nil{return err} }
 // Type-provider recursion stops at objects or dyn alternatives; reject cycles
 // consisting solely of parameterized CEL list/map/nullable/ref constructors.
 var check func(*Schema,map[*Schema]bool) error
 check=func(s *Schema, stack map[*Schema]bool) error {
  if stack[s] { return fmt.Errorf("unsupported recursive non-object CEL type") }
  stack[s]=true; defer delete(stack,s)
  switch s.Kind { case "ref":return check(c.defs[s.Ref],stack); case "list":return check(s.Element,stack); case "map","nullable":return check(s.Value,stack) }
  return nil
 }
 for _,s:=range c.defs {if err:=check(s,map[*Schema]bool{});err!=nil{return err}}
 return nil
}
