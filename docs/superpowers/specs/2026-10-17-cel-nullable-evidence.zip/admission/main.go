package main

import (
 "bytes"
 "encoding/json"
 "fmt"
 "os"
 "runtime"
 "sort"
 "strings"
 "cel.dev/cel-go/cel"
 "cel.dev/cel-go/common/types"
 "cel.dev/cel-go/common/types/ref"
 "cel.dev/cel-go/common/types/traits"
)

type Observation struct {
 Name string `json:"name"`
 Category string `json:"category"`
 Resource string `json:"resource,omitempty"`
 Expression string `json:"expression,omitempty"`
 Expected string `json:"expected"`
 Actual string `json:"actual"`
 ExpectedDetail string `json:"expectedDetail,omitempty"`
 Detail string `json:"detail,omitempty"`
 CheckedType string `json:"checkedType,omitempty"`
 Assertion bool `json:"assertion"`
}
type Probe struct { fixture Fixture; catalog *Catalog; observations []Observation }
func(p *Probe) record(o Observation) { o.Assertion=o.Expected==o.Actual && (o.ExpectedDetail=="" || strings.Contains(o.Detail,o.ExpectedDetail));p.observations=append(p.observations,o) }
func(p *Probe) eval(name,resource,expression,expected,category string) {
 r:=p.fixture.Resources[resource]
 o:=Observation{Name:name,Category:category,Resource:resource,Expression:expression,Expected:expected}
 env,err:=cel.NewEnv(cel.CustomTypeProvider(p.catalog),cel.CustomTypeAdapter(p.catalog),cel.Variable("resource",p.catalog.celType(p.catalog.defs[r.Schema])),cel.ParserRecursionLimit(64),cel.ParserExpressionSizeLimit(4096))
 if err!=nil { panic(err) }
 ast,issues:=env.Compile(expression)
 if issues!=nil && issues.Err()!=nil {o.Actual="check-error";o.Detail=issues.Err().Error()} else {
  o.CheckedType=ast.OutputType().String()
  admitted,err:=p.catalog.admit(r)
  if err!=nil {o.Actual="admission-error";o.Detail=err.Error()} else {
   program,err:=env.Program(ast,cel.CostLimit(10000));if err!=nil {panic(err)}
   out,_,err:=program.Eval(map[string]any{"resource":admitted})
   if err!=nil {o.Actual="eval-error";o.Detail=err.Error();if strings.Contains(o.Detail,"hydration-needed"){o.Actual="hydration-needed"}} else {o.Actual=fmt.Sprint(out)}
  }
 }
 p.record(o)
}
func(p *Probe) admission(name string,r Representation,expected,detail string) {
 v,err:=p.catalog.admit(r);o:=Observation{Name:name,Category:"expected-rejection",Expected:expected,ExpectedDetail:detail,Actual:"admitted"}
 if expected=="admitted" {o.Category="feature-success"}
 if err!=nil {o.Actual="admission-error";o.Detail=err.Error()} else {o.Detail=fmt.Sprint(v.Type())};p.record(o)
}
func raw(schema,text string) Representation { var v any;d:=json.NewDecoder(strings.NewReader(text));d.UseNumber();if err:=d.Decode(&v);err!=nil{panic(err)};return Representation{Schema:schema,Complete:true,Data:v} }
func(p *Probe) schema(name string,defs map[string]*Schema,expected,detail string) {
 _,err:=newCatalog(defs);o:=Observation{Name:name,Category:"expected-rejection",Expected:expected,ExpectedDetail:detail,Actual:"admitted"};if expected=="admitted"{o.Category="feature-success"};if err!=nil{o.Actual="schema-error";o.Detail=err.Error()};p.record(o)
}
func shape(v ref.Val) any {
 if v==types.NullValue {return nil}
 if o,ok:=v.(*Object);ok {m:=map[string]any{};for k,f:=range o.fields{m[k]=shape(f)};return m}
 if m,ok:=v.(traits.Mapper);ok {out:=map[string]any{};it:=m.Iterator();for it.HasNext()==types.True{k:=it.Next();out[fmt.Sprint(k)]=shape(m.Get(k))};return out}
 if l,ok:=v.(traits.Lister);ok {out:=[]any{};for i:=range int(l.Size().(types.Int)){out=append(out,shape(l.Get(types.Int(i))))};return out}
 return v.Value()
}
func(p *Probe) shapeCheck(resource string) {
 r:=p.fixture.Resources[resource];before,_:=json.Marshal(r.Data);v,err:=p.catalog.admit(r);if err!=nil{panic(err)};after,_:=json.Marshal(r.Data);roundtrip,_:=json.Marshal(shape(v));actual:="preserved";if !bytes.Equal(before,after)||!bytes.Equal(before,roundtrip){actual="changed"}
 p.record(Observation{Name:"raw and CEL roundtrip shape: "+resource,Category:"feature-success",Expected:"preserved",Actual:actual,Detail:fmt.Sprintf("raw=%s roundtrip=%s",before,roundtrip)})
}
func main() {
 src,err:=os.ReadFile("fixtures.json");if err!=nil{panic(err)}
 var fixture Fixture;d:=json.NewDecoder(bytes.NewReader(src));d.UseNumber();d.DisallowUnknownFields();if err:=d.Decode(&fixture);err!=nil{panic(err)}
 catalog,err:=newCatalog(fixture.Definitions);if err!=nil{panic(err)};p:=&Probe{fixture:fixture,catalog:catalog}
 keys:=[]string{};for k:=range fixture.Resources{keys=append(keys,k)};sort.Strings(keys)
 for _,k:=range keys{p.admission("fixture admission: "+k,fixture.Resources[k],"admitted","")}
 evals:=[][5]string{
 {"required nullable present null","nulls",`has(resource.reqNullable) && resource.reqNullable == null`,"true","feature-success"},
 {"optional nonnullable absent","base",`!has(resource.optional)`,"true","feature-success"},
 {"optional nullable absent distinct","base",`!has(resource.optNullable)`,"true","feature-success"},
 {"optional nullable null present","nulls",`has(resource.optNullable) && resource.optNullable == null`,"true","feature-success"},
 {"empty string present and nonnullable","values",`has(resource.optional) && resource.optional == ""`,"true","feature-success"},
 {"nonnullable field null guard rejected statically","values",`has(resource.optional) && resource.optional != null && resource.optional == ""`,"check-error","known-limitation"},
 {"nullable primitive static mismatch","nulls",`resource.reqNullable + 1 == 2`,"check-error","expected-rejection"},
 {"nullable primitive unguarded operation","nulls",`resource.reqNullable.startsWith("n")`,"eval-error","known-limitation"},
 {"nullable primitive guarded null","nulls",`resource.reqNullable != null && resource.reqNullable.startsWith("n")`,"false","feature-success"},
 {"nullable primitive guarded value","values",`resource.reqNullable != null && resource.reqNullable.startsWith("n")`,"true","feature-success"},
 {"closed static typo","base",`resource.reqNullabl == null`,"check-error","expected-rejection"},
 {"nullable complex guard null","nulls",`has(resource.detail) && resource.detail != null && resource.detail.name == "d"`,"false","feature-success"},
 {"nullable complex field checked as dyn","values",`resource.detail.name`,"d","known-limitation"},
 {"nullable complex typo dynamic","values",`resource.detail.typo == "d"`,"eval-error","known-limitation"},
 {"nullable complex wrong domain dynamic","values",`resource.detail.name + 1 == 2`,"eval-error","known-limitation"},
 {"nested ancestors value","values",`has(resource.detail) && resource.detail != null && has(resource.detail.inner) && resource.detail.inner != null && has(resource.detail.inner.leaf) && resource.detail.inner.leaf != null && resource.detail.inner.leaf == "x"`,"true","feature-success"},
 {"nested ancestor null","innerNull",`has(resource.detail) && resource.detail != null && has(resource.detail.inner) && resource.detail.inner != null && has(resource.detail.inner.leaf)`,"false","feature-success"},
 {"nested leaf absent complete","empty",`!has(resource.detail.inner.leaf)`,"true","feature-success"},
 {"nullable list null","nulls",`resource.list == null`,"true","feature-success"},
 {"nullable list actual shape","values",`resource.list.size() == 3 && resource.list[0] == null && resource.list[1] == "x" && resource.list[2] == ""`,"true","feature-success"},
 {"nullable map arbitrary keys","values",`"provider/key" in resource.map && resource.map["provider/key"] == null && resource.map["empty"] == ""`,"true","feature-success"},
 {"empty collections not null","empty",`resource.list != null && resource.list.size() == 0 && resource.map != null && resource.map.size() == 0`,"true","feature-success"},
 {"required field coverage unavailable","partial",`has(resource.required)`,"hydration-needed","known-limitation"},
 {"optional field coverage unavailable","partial",`has(resource.optional)`,"hydration-needed","known-limitation"},
 {"known absence not null","knownAbsent",`!has(resource.optNullable)`,"true","feature-success"},
 {"known absence unguarded retains error","knownAbsent",`resource.optNullable == null`,"eval-error","known-limitation"},
 {"nested unknown coverage","partialNested",`has(resource.detail.inner.leaf)`,"hydration-needed","known-limitation"},
 {"nested explicit known absence","knownNested",`!has(resource.detail.inner.leaf)`,"true","feature-success"},
 {"dynamic cannot bypass coverage","partial",`has(dyn(resource).optional)`,"hydration-needed","known-limitation"},
 {"CEL error masked by false and","partial",`has(resource.optional) && false`,"false","known-limitation"},
 {"CEL error masked by true or","partial",`has(resource.optional) || true`,"true","known-limitation"},
 {"scalar anyOf native type guard","scalarString",`type(resource) == string && resource.startsWith("a")`,"true","feature-success"},
 {"scalar oneOf native type guard","scalarInt",`type(resource) == int && resource > 5`,"true","feature-success"},
 {"union wrong operation checks dyn then fails","scalarInt",`resource.startsWith("a")`,"eval-error","known-limitation"},
 {"anyOf overlapping objects keep all fields","overlap",`resource.a == "A" && resource.b == "B" && resource.extra == "E" && has(resource.a) && has(resource.b)`,"true","feature-success"},
 {"anyOf overlapping absent branch field retained","closedOverlap",`!has(resource.a) && !has(resource.b)`,"true","feature-success"},
 {"anyOf overlapping nested branch fields retained","nestedOverlap",`!has(resource.detail.a) && !has(resource.detail.b)`,"true","feature-success"},
 {"union known schema typo not statically rejected","cat",`resource.lievs == 9`,"eval-error","known-limitation"},
 {"discriminator guarded cat","cat",`resource.kind == "cat" && resource.lives == 9`,"true","feature-success"},
 {"discriminator guarded other branch","dog",`resource.kind == "cat" && resource.lives == 9`,"false","feature-success"},
 {"discriminator unguarded wrong branch","dog",`resource.lives == 9`,"eval-error","known-limitation"},
 {"discriminator contradictory operation not flow checked","cat",`resource.kind == "cat" && resource.lives.startsWith("9")`,"eval-error","known-limitation"},
 {"map union arbitrary keys","stringMap",`resource["vendor/key"] == "v" && resource.kind == "not-a-discriminator"`,"true","feature-success"},
 {"map union bool shape","boolMap",`has(resource.x) && resource.x == false`,"true","feature-success"},
 {"recursive object statically checked","node",`resource.next.name == "b" && !has(resource.next.next)`,"true","feature-success"},
 {"recursive typo statically rejected","node",`resource.next.naem == "b"`,"check-error","expected-rejection"},
 {"nullable union null","nullableUnionNull",`resource == null`,"true","feature-success"},
 {"nullable union list","nullableUnionList",`type(resource) == list && resource.size() == 2 && resource[1] == ""`,"true","feature-success"},
 {"all nullable primitives explicit null","primitiveNulls",`resource.b == null && resource.i == null && resource.u == null && resource.d == null && resource.t == null`,"true","feature-success"},
 {"nullable primitive concrete values","primitiveValues",`resource.b == false && resource.i == 2 && resource.u == 3u && resource.d == 1.5 && resource.t == timestamp("2026-10-18T00:00:00Z")`,"true","feature-success"},
 {"nullable bool static mismatch","primitiveNulls",`resource.b + 1 == 2`,"check-error","expected-rejection"},
 {"nullable unsigned static mismatch","primitiveNulls",`resource.u == "3"`,"check-error","expected-rejection"},
 {"nullable timestamp dynamic limitation","primitiveValues",`resource.t.typo == "x"`,"eval-error","known-limitation"},
 }
 for _,e:=range evals {p.eval(e[0],e[1],e[2],e[3],e[4])}
 invalid:=[][4]string{
 {"required absent even nullable","State",`{"required":"r"}`,"missing required field reqNullable"},
 {"required nonnullable rejects null","State",`{"required":null,"reqNullable":null}`,"expected string"},
 {"optional nonnullable rejects null","State",`{"required":"r","reqNullable":null,"optional":null}`,"expected string"},
 {"nullable wrong nonnull type","State",`{"required":"r","reqNullable":false}`,"expected string"},
 {"nullable complex wrong type","State",`{"required":"r","reqNullable":null,"detail":[]}`,"expected object"},
 {"nullable list child rejects bool","State",`{"required":"r","reqNullable":null,"list":[false]}`,"expected string"},
 {"nullable map child rejects bool","State",`{"required":"r","reqNullable":null,"map":{"k":false}}`,"expected string"},
 {"scalar anyOf zero matches","ScalarAny",`false`,"zero matching anyOf"},
 {"scalar oneOf zero matches","ScalarOne",`null`,"zero matching oneOf"},
 {"overlap exclusive rejected","OpenOne",`{"a":"A","b":"B","extra":"E"}`,"got 2"},
 {"closed overlap exclusive rejected","ClosedOne",`{}`,"got 2"},
 {"closed branch cannot borrow other branch fields","ClosedAny",`{"a":"A","b":"B"}`,"zero matching anyOf"},
 {"additional properties validated in each branch","OpenAny",`{"a":"A","b":"B","extra":false}`,"zero matching anyOf"},
 {"discriminator incorrect","Tagged",`{"kind":"bird","lives":9}`,"zero matching oneOf"},
 {"discriminator missing","Tagged",`{"lives":9}`,"zero matching oneOf"},
 {"tag matches contradictory payload","Tagged",`{"kind":"cat","bark":true}`,"zero matching oneOf"},
 {"tag matches wrong typed payload","Tagged",`{"kind":"cat","lives":"nine"}`,"zero matching oneOf"},
 {"tag matches but additional closed field","Tagged",`{"kind":"cat","lives":9,"bark":true}`,"zero matching oneOf"},
 {"map alternatives no per-key mixing","MapAny",`{"a":"A","b":true}`,"zero matching anyOf"},
 {"nullable union zero match","NullableUnion",`{}`,"zero matching anyOf"},
 }
 for _,v:=range invalid {p.admission(v[0],raw(v[1],v[2]),"admission-error",v[3])}
 for _,v:=range [][3]string{{"oneOf disjoint first","OpenOne",`{"a":"A"}`},{"oneOf disjoint second","OpenOne",`{"b":"B"}`},{"closed oneOf disjoint","ClosedOne",`{"a":"A"}`},{"map anyOf overlapping empty","MapAny",`{}`}} {p.admission(v[0],raw(v[1],v[2]),"admitted","")}
 partial:=raw("Tagged",`{"kind":"cat","lives":9}`);partial.Complete=false;p.admission("union summary must hydrate before counting matches",partial,"admission-error","hydration-needed")
 partial=raw("State",`{"list":[]}`);partial.Complete=false;p.admission("incomplete list cannot fake emptiness",partial,"admission-error","hydration-needed")
 partial=raw("State",`{"map":{}}`);partial.Complete=false;p.admission("incomplete map cannot fake emptiness",partial,"admission-error","hydration-needed")
 partial=fixture.Resources["knownAbsent"];partial.KnownAbsent=[]string{"resource.required"};p.admission("known absent required is invalid not unknown",partial,"admission-error","missing required")
 partial=fixture.Resources["values"];partial.KnownAbsent=[]string{"resource.optional"};p.admission("present field contradicts absent metadata",partial,"admission-error","contradicts")
 p.admission("incomplete without schema rejected",Representation{Complete:false,Data:map[string]any{}},"admission-error","hydration-needed")
 p.admission("unavailable catalog schema rejected",raw("NotAcquired",`{}`),"admission-error","unknown catalog schema")
 var node any=map[string]any{"name":"end"};for range 14{node=map[string]any{"name":"x","next":node}};p.admission("recursive resource bounded",Representation{Schema:"Node",Complete:true,Data:node},"admission-error","bound")
 p.schema("legacy first-success union explicitly not accepted",map[string]*Schema{"X":{Kind:"union",Variants:[]*Schema{{Kind:"string"},{Kind:"bool"}}}},"schema-error","union")
 p.schema("unsupported retained constraint rejects catalog",map[string]*Schema{"X":{Kind:"anyOf",Variants:[]*Schema{{Kind:"string"},{Kind:"string",Unsupported:[]string{"pattern"}}}}},"schema-error","unsupported constraints")
 p.schema("misplaced known constraint rejects instead of drops",map[string]*Schema{"X":{Kind:"string",Additional:&Schema{Kind:"dynamic"}}},"schema-error","unsupported additional")
 p.schema("mixed object map overlap explicitly unsupported",map[string]*Schema{"X":{Kind:"anyOf",Variants:[]*Schema{{Kind:"object"},{Kind:"map",Value:&Schema{Kind:"string"}}}}},"schema-error","unsupported mixed")
 p.schema("missing ref rejected",map[string]*Schema{"X":{Kind:"ref",Ref:"Missing"}},"schema-error","unresolved")
 p.schema("ref cycle rejected",map[string]*Schema{"X":{Kind:"ref",Ref:"X"}},"schema-error","ref-only cycle")
 p.schema("recursive list type rejected before checker recursion",map[string]*Schema{"X":{Kind:"list",Element:&Schema{Kind:"ref",Ref:"X"}}},"schema-error","recursive non-object")
 branches:=[]*Schema{};for range 5{branches=append(branches,&Schema{Kind:"string"})};p.schema("union branch bound",map[string]*Schema{"X":{Kind:"anyOf",Variants:branches}},"schema-error","branch bound")
 deep:=&Schema{Kind:"string"};for range 14{deep=&Schema{Kind:"list",Element:deep}};p.schema("schema recursion bound",map[string]*Schema{"X":deep},"schema-error","bound")
 p.schema("discriminator without actual branch constraints rejected",map[string]*Schema{"X":{Kind:"oneOf",Discriminator:"kind",Variants:[]*Schema{{Kind:"object",Fields:map[string]*Schema{"kind":{Kind:"string"}}},{Kind:"object",Fields:map[string]*Schema{"kind":{Kind:"string"}}}}}},"schema-error","required string const")
 unknown:=`{"kind":"string","pattern":"x"}`;var s Schema;strict:=json.NewDecoder(strings.NewReader(unknown));strict.DisallowUnknownFields();err=strict.Decode(&s);actual:="accepted";detail:="";if err!=nil{actual="schema-error";detail=err.Error()};p.record(Observation{Name:"unknown dialect keyword strict decode",Category:"expected-rejection",Expected:"schema-error",Actual:actual,ExpectedDetail:"unknown field",Detail:detail})
 heavy:=&Schema{Kind:"list",Element:&Schema{Kind:"list",Element:&Schema{Kind:"string"}}};defs:=map[string]*Schema{"Heavy":heavy,"X":{Kind:"anyOf",Variants:[]*Schema{{Kind:"ref",Ref:"Heavy"},{Kind:"ref",Ref:"Heavy"},{Kind:"ref",Ref:"Heavy"},{Kind:"ref",Ref:"Heavy"}}}};hc,err:=newCatalog(defs);if err!=nil{panic(err)}
 rows:=[]any{};for range 8{row:=[]any{};for range 32{row=append(row,"x")};rows=append(rows,row)};saved:=p.catalog;p.catalog=hc;p.admission("shared union branch work budget not reset",Representation{Schema:"X",Complete:true,Data:rows},"admission-error","bound");p.catalog=saved
 huge:=[]any{};for range 65{huge=append(huge,"x")};p.admission("collection cardinality bound",Representation{Schema:"NullableUnion",Complete:true,Data:huge},"admission-error","bound")
 for _,r:=range []string{"base","nulls","values","empty","overlap","closedOverlap","nestedOverlap","nullableUnionList","stringMap","node"}{p.shapeCheck(r)}
 failures:=0;counts:=map[string]int{};for _,o:=range p.observations{counts[o.Category]++;if !o.Assertion{failures++}}
 result:=map[string]any{"runtime":runtime.Version(),"cel":"cel.dev/cel-go v0.32.0","baseline":"docs/superpowers/specs/2026-10-17-cel-confirmation-evidence.zip:schema/{adapter.go,go.mod,go.sum}","command":"GOWORK=off go run .","observations":p.observations,"count":len(p.observations),"unexpectedAssertionFailures":failures,"categories":counts,"limitations":limitations}
 output,err:=json.MarshalIndent(result,"","  ");if err!=nil{panic(err)};if err=os.WriteFile("results.json",append(output,'\n'),0644);err!=nil{panic(err)}
 var report strings.Builder;fmt.Fprintf(&report,"# Nullable and explicit union admission probe\n\nThrowaway bounded catalog adapter; no product edits.\n\n## Exact rerun\n\n```sh\ncd /tmp/omniview-cel-nullable.SZXStB/admission\nGOWORK=off go run .\n```\n\nPins: `cel.dev/cel-go v0.32.0`, unchanged archived `go.mod` and `go.sum`; runtime `%s`. Sources: `adapter.go` copied then experimentally extended from archived schema baseline; `extensions.go`, `main.go`, `fixtures.json`. The fixture dialect is not JSON Schema. Original first-success `union` is deliberately rejected, not relabeled as oneOf.\n\n## Results\n\n%d assertions, %d unexpected failures. Counts: %v. Process exits nonzero on unexpected assertions. `results.json` preserves every expected/actual result, CEL expression, checked output type and diagnostic.\n\n",runtime.Version(),len(p.observations),failures,counts)
 report.WriteString("AnyOf validates all branches in this bounded experiment and requires at least one; oneOf counts exactly one. Discriminators require actual string-const branch constraints; the implementation deliberately validates all branches, without tag-only dispatch. Objects are closed by default; `additional` is a typed additional-properties schema. Maps retain arbitrary keys. Overlapping successful objects merge runtime field-dispatch views including branch-local absent optional fields and nested objects, not a narrowed first schema. Union/nullable-complex CEL declarations remain dyn. Completeness and known absence stay outside original data. Roundtrip shape and native CEL navigation assertions exercise no invented union envelopes.\n\n## Explicit limitations\n\n")
 for _,l:=range limitations{fmt.Fprintf(&report,"- %s\n",l)}
 report.WriteString("\n## Initial run and investigation\n\nThe first final run produced 130 observations and exited 1 with two harness assertion failures; full unmodified evidence is retained in `initial-results.json`. No adapter, dependency pin, or fixture was changed after that run. (1) The empty nonnullable string assertion incorrectly generated a nullable-only `!= null` guard. Native CEL rejected `(string, null)` at check time, while the nullable-string control compiled and evaluated true. The corrected value clause uses presence plus equality; a separate explicit diagnostic assertion preserves the original expression and native check rejection. This is a real authoring constraint, not flow narrowing or null coercion. (2) The legacy union already rejected, but the harness demanded the later kind-switch wording; `supportedFields` correctly rejected its variants earlier. The assertion now requires schema rejection with `union` context rather than arbitrary validation ordering. These are documented harness corrections, not re-pinning a failed semantic expectation or suppressing a native diagnostic. The rerun below is the only post-correction execution.\n")
 report.WriteString("\n## Unexpected observations\n\n");if failures==0{report.WriteString("None.\n")}else{for _,o:=range p.observations{if !o.Assertion{fmt.Fprintf(&report,"- %s: expected `%s`, actual `%s`; %s\n",o.Name,o.Expected,o.Actual,o.Detail)}}}
 if err=os.WriteFile("report.md",[]byte(report.String()),0644);err!=nil{panic(err)}
 fmt.Printf("%d observations; %d unexpected assertion failures; categories=%v\n",len(p.observations),failures,counts)
 if failures!=0{os.Exit(1)}
}
var limitations=[]string{
 "This is a bounded normalized fixture dialect, not a universal schema normalizer or complete JSON Schema validator. Unknown JSON fields and explicitly unsupported constraints reject; unsupported object/map/dynamic mixed union dispatch also rejects rather than pretending safe narrowing.",
 "All incomplete union/map/list representations conservatively require hydration before full admission, even if the supplied projection could in principle prove a branch. Nonunion objects retain catalog-backed per-path unknown/known-absent distinction; no actual acquisition or authorization is implemented.",
 "Nullable primitives bool/string/int/uint/double retain CEL primitive checking, but explicit null still requires runtime guards. Nullable timestamp, nullable objects/maps/lists and all unions are dyn; native CEL does not flow-narrow them from null/type/discriminator guards, so some typos and operation mismatches only fail at evaluation.",
 "Successful overlapping object alternatives reconcile runtime field dispatch without deleting fields; this is not a merged static type or authoring schema. The complete original schema alternatives remain in the catalog. Mixed scalar/list/map alternatives use an admitted full-shape value, with no full universal cross-alternative equality/type-reconciliation claim.",
 "Coverage errors are real native CEL errors. CEL can mask them with false conjunction or true disjunction; those observed booleans are not host evidence of known absence. Required schema properties do not prove acquired coverage.",
 "Bounds: 32 definitions, depth 12, 512 schema nodes and shared admission work units, 2-4 union branches, 64 collection members, 16384-byte strings; CEL parser depth 64, expression size 4096, runtime cost 10000. A limit in any branch aborts rather than being silently counted as a mismatch.",
 "No numeric-profile correction, mixed-domain arithmetic comparison claim, source rewriting, custom interpreter, provider-specific core assumption, client/editor, builder implementation, IO-producing getters, hydration planner, or authorization evidence. Integer/double coercion policy is inherited unchanged from the archived baseline.",
 "Sources were prepared before the final executable run; expected outcomes are embedded independently in main.go. results.json and report.md are regenerated by the exact rerun command. Binaries and caches are not deliverables.",
}
