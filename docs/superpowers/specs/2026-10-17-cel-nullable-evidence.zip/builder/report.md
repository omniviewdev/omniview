# Throwaway nullable/union builder-clause confirmation

## Scope and reproducibility

This is an isolated section-8 feasibility probe, not product implementation, an authoring DTO freeze, or actual editor proof. It generated native CEL from bounded structured clause documents and executed that CEL with the actual archived catalog-backed adapter. It did not implement another evaluator or rewrite arbitrary source expressions.

Exact command executed successfully once on 2026-10-18:

```sh
cd /tmp/omniview-cel-nullable.SZXStB/builder && GOWORK=off go run .
```

After extracting the archive elsewhere, run `GOWORK=off go run .` from its `builder` directory. The executable writes `results.json`, prints the same expected/actual JSON, and exits nonzero for any unexpected assertion; execution observed exit status 0. No formatter, broad test suite, or intermediate build/test run was performed. There were no failed probe runs, semantic expectation repins, or post-run source changes.

Runtime: Go `go1.26.1`; module declares Go `1.25.0`; CEL `cel.dev/cel-go v0.32.0`. `go.mod` and `go.sum` are copied verbatim from `docs/superpowers/specs/2026-10-17-cel-confirmation-evidence.zip:schema/`. `adapter.go` is also copied verbatim, SHA-256 `4b10924647127129aa5a92b39609ad7672fe9f9ed12ebcf8afc0b8ea3c7eab2e`. Results record SHA-256 for all six executable source/fixture/pin files. No product files or dependencies were changed.

Artifacts:

- `adapter.go`: unmodified actual catalog adapter, with schema validation, admission, CEL type provider, field presence/error semantics and value traits.
- `builder.go`: bounded structured-clause-to-CEL generator, not an evaluator.
- `fixtures.json`: catalog schemas, representations, expected state matrices, structured cases, correlation expectations and native-CEL controls.
- `main.go`: fixture expansion, native compilation/admission/evaluation, boolean/error assertions and JSON results.
- `go.mod`, `go.sum`: original exact dependency pins.
- `results.json`: 269 observations including structured input where applicable, generated CEL, expected/actual classification, checked type, returned value and unmodified returned error text.

## Counts and assertion strength

**269/269 passed, 0 unexpected assertions.** Expectations were supplied in the source fixture table before execution.

| Category | Assertions | Passed |
| --- | ---: | ---: |
| 28 state/path matrices × 7 operators | 196 | 196 |
| Additional structured clause/admission/builder cases | 43 | 43 |
| Correlated array fixtures | 7 | 7 |
| Native CEL controls | 23 | 23 |
| Total | 269 | 269 |

| Expected and actual outcome | Count |
| --- | ---: |
| true | 87 |
| false | 137 |
| returned hydration-needed error | 33 |
| other returned native evaluation error | 3 |
| admission rejection | 5 |
| unsupported structured clause rejection | 4 |

All 224 boolean outcomes require actual `types.Bool`, checked output type `bool`, exact expected true/false and no returned error. Every expected hydration-needed result requires a real returned error containing `hydration-needed`; errors are not converted to false/null/absence. Selected expected rejections additionally require a meaningful error-text fragment. The 12 admission/builder/native error observations are expected boundary evidence, not failures to omit from the result set.

## Executed clause semantics

For a nullable field `resource.maybe`, let `P = has(resource.maybe)` and `N = resource.maybe != null`:

| Structured operator | Generated meaning |
| --- | --- |
| absent | `!(P)` |
| present | `P` |
| null | `P && resource.maybe == null` |
| non-null | `P && N` |
| positive equality | `P && N && resource.maybe == "match"` |
| whole positive-clause NOT | `!(P && N && resource.maybe == "match")` |
| present non-null inequality | `P && N && resource.maybe != "match"` |

Actual outcomes matched this table:

| Available field state | absent | present | null | non-null | positive equality | whole-clause NOT equality | guarded inequality |
| --- | --- | --- | --- | --- | --- | --- | --- |
| present matching value | false | true | false | true | true | false | false |
| present null | false | true | true | false | false | true | false |
| known absent | true | false | false | false | false | true | false |
| unavailable summary field, standalone clause | error | error | error | error | error | error | error |

A present different value also gives equality false, whole-clause NOT true and guarded inequality true. Optional/nonnullable equality, absence, whole-clause negation, guarded inequality and incomplete coverage were exercised separately. Null state for a nonnullable field is rejected by this bounded builder; an actual null supplied to that schema is rejected by real admission. Required/nullable fields accept explicit null, reject complete omission and return hydration-needed when a required summary field is unavailable. A required/nonnullable unavailable field's `present` clause also returns hydration-needed: requiredness is not coverage.

Complete absence and explicit summary `knownAbsent` metadata have the same expected/actual truth results. Summary data with the field actually present works. No sentinel/default was inserted into resource data. The adapter's getter and presence tester are the archived in-memory implementations; neither performs IO.

### Nested ancestors, map/list values and defaults

The generated nested equality includes every affected presence/null guard, in traversal order:

```cel
has(resource.parent) && resource.parent != null &&
has(resource.parent.child) && resource.parent.child != null &&
has(resource.parent.child.leaf) && resource.parent.child.leaf != null &&
resource.parent.child.leaf == "match"
```

Nullable parent, nullable child, nullable leaf, absent parent/child/leaf, fully present values, unavailable leaf coverage and explicit leaf-absence metadata were all executed. No tested generated guard unexpectedly leaked an absent-field/null-dereference error.

**Explicit path-state convention in this probe:** descendant `present` means a reachable terminal slot; descendant `absent` is its boolean complement. Thus a known null/absent ancestor makes the descendant path absent, not descendant null. A null ancestor is still present-and-null when that ancestor itself is queried. This is a documented bounded path convention, not an independently approved/frozen editor label or a claim that a null object contains an absent child property. A production UI must expose/choose that path-state convention deliberately.

Map-key selection uses ancestor guards followed by native `"key" in map`, then an optional value-null guard. List-index selection uses ancestor guards followed by `size(list) > index`, then an optional element-null guard. Real map present/null/absent keys, null maps, empty maps, list present/null/out-of-range elements, null lists and empty lists matched all seven state/value operators. A nonnull field containing `false`, integer `0`, empty string, empty list or empty map is a real matching value; known absence does not acquire any of those defaults. Both map and list empty-string values were tested.

Map admission remains conservative: an acquired map on an incomplete representation is rejected with `resource.map: hydration-needed: incomplete maps need whole-map hydration`. This is an admission error, not a native CEL field-access error. Lists are admitted sequences with no per-index partial-coverage metadata model; this probe does not claim otherwise.

### Grouping and negation

`not` wraps the entire generated positive clause, never just the comparison. `and`/`or` preserve complete clause children. Grouped true values, nullable operands, explicit null-state alternatives and negation of an entire conjunction matched expectations. Guarded inequality remains a distinct operation: null/absence/nonmatching union branches do not become inequality matches.

Structured clauses can still exhibit native boolean/error masking. In an incomplete summary, generated `eq(maybe,"match") AND eq(id,"other")` returns false, while `eq(maybe,"match") OR eq(id,"r")` returns true. This does not prove `maybe` was covered, absent or null. It proves these generated groups retain native CEL semantics rather than running a second evaluator or enforcing a hidden coverage policy.

## Explicit union/discriminator guards

The existing first-success union adapter is sufficient for this slice's **disjoint** string/int primitive alternatives; it was not changed or relabeled as anyOf/oneOf validation. Positive primitive-union clauses require an explicit supported type condition:

```cel
has(resource.variant) && type(resource.variant) == string &&
resource.variant == "match"
```

The string branch matches the real string, the int branch matches real integer `7`, wrong branches are nonmatching, whole-clause NOT includes the other branch and guarded inequality excludes it. Missing type-guard metadata is rejected by the builder.

Object-branch traversal uses explicit catalog branch identity plus an optional native discriminator equality before field access:

```cel
has(resource.choice) &&
type(resource.choice) == catalog.Sample_choice_branch0 &&
has(resource.choice.kind) && resource.choice.kind == "text" &&
has(resource.choice.text) && resource.choice.text == "match"
```

Both object branches were exercised, including a nonmatching branch, absent union value and mismatched discriminator. Object traversal without branch metadata is rejected. These are explicit generated conditions, not CEL flow-sensitive narrowing, universal union casts or plugin-specific rules.

**Important baseline limitation:** the unchanged adapter does not validate constant discriminator tags. A shape-compatible `{kind:"count", text:"match"}` is admitted as the text-shaped branch, and the generated tag condition makes the predicate false. This demonstrates runtime predicate gating only, not correct discriminator admission. Full anyOf/oneOf, overlap/ambiguity semantics and schema discriminator validation belong to the independent admission slice; this probe has no dependency on that slice and makes no such claim.

## Same-element array correlation

The structured `exists(tags, and(eq(key,"env"), eq(value,"prod")))` is generated as a **single native CEL exists binder** whose complete child clauses reference the same element. The element itself is nullable, so each child path guards a null element. The list field is also optional/nullable, and the value field optional/nullable.

Actual results: matching element true; split `{key:"env",value:"dev"}` and `{key:"team",value:"prod"}` elements false; null list, absent list, empty list and null/absent element values false; unavailable list coverage hydration-needed. A native control with two independent `exists` expressions returns true for the split-element fixture, demonstrating that the generated correlated false result is meaningful and not merely a collection-presence check.

## Native CEL error masking is not a coverage or authorization gate

Controls were executed both with `has(resource.maybe)` and with direct `resource.maybe == "match"` where `maybe` is unavailable in a summary. Let `E` denote either error-producing expression:

| Native form | Actual result |
| --- | --- |
| `E && false`, `false && E` | false |
| `E && true`, `true && E` | returned hydration-needed error |
| `E || true`, `true || E` | true |
| `E || false`, `false || E` | returned hydration-needed error |
| `!has(resource.maybe)` | returned hydration-needed error |

This is output/error behavior, not a promise about exact evaluation order or which optimized branch was visited. Unmasked CEL errors retain their returned text in `results.json`. There are no fake fallback values. Additional native controls preserve absent-field error, a nullable-string operation's `no such overload`, and an unknown-field runtime error after a nullable-complex dynamic boundary. Thus successful guarded clauses do not establish general static null/field safety.

Admission is a separate boundary and occurs before native evaluation. `false && has(resource.maybe)` on an incomplete representation that already contains an unsupported incomplete map still produces an admission error; a false CEL branch cannot repair/reinterpret failed input admission.

Conversely, a schema-valid incomplete object is admitted for these native coverage experiments. `true || has(resource.id)` can yield true even when a required field is unavailable. **There is no authorization or acquisition/coverage preflight gate in this probe.** Product policy deciding whether incomplete coverage may participate at all must remain distinct from CEL truth/error semantics. No denial is represented as a CEL value and no authorization claim is made.

## Supported structure and explicit limits

The supported throwaway structure is field/key/index paths; absent/present/null/non-null; scalar or empty-collection equality and guarded inequality; whole-clause NOT; bounded AND/OR; explicit union type/object branch/discriminator guards; and correlated list `exists`. Path and guard metadata come from the retained catalog schema plus explicit selected branch metadata, not guesses from arbitrary code text.

Generator bounds: 12 path steps, recursion depth 12, 64 clause nodes, 2–8 grouped children, nonnegative indices below 64, map-key length 128, scalar string-literal length 256. Admission uses the unchanged archived schema/value bounds; CEL parser recursion 64, source size 8192, runtime cost limit 10000. These are finite probe bounds, not production budgets. Limit enforcement was not separately exhaustively stress-tested.

No arbitrary CEL reverse converter was needed or implemented. The explicit clause/guard structure is suitable evidence for this generated subset only. There is no evidence here for recognizing equivalent handwritten guards, recovering builder documents from arbitrary CEL, preserving unknown advanced source through an actual editor, insertion edits, stale responses, schema revisions, completion UX or full authoring integration. There is no IO in field getters, scheduler, hydration implementation, authorization, preflight, Wails binding work, editor integration, numeric-domain correction, mixed numeric comparison evidence, full schema dialect normalizer or performance/cancellation claim.

## Conclusion

The tested section-8 structured value/state clauses can be generated and executed through the actual catalog-backed adapter using ordinary native CEL guards, grouping, type/discriminator conditions and correlated comprehensions. **No unexpected semantic guard failure was observed among the 269 asserted cases.** Expected dynamic-checking/admission boundaries and native error masking remain visible rather than suppressed. This is finite throwaway feasibility evidence, not end-to-end product, editor, authorization/coverage-policy or full union-admission proof.
