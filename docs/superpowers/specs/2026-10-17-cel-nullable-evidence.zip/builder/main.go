package main

import (
    "bytes"
    "crypto/sha256"
    "encoding/hex"
    "encoding/json"
    "fmt"
    "os"
    "runtime"
    "strings"

    "cel.dev/cel-go/cel"
    "cel.dev/cel-go/common/types"
)

type Matrix struct {
    Name string `json:"name"`
    Resource string `json:"resource"`
    Path []Step `json:"path"`
    Value any `json:"value"`
    Expected []string `json:"expected"`
}
type Case struct {
    Name string `json:"name"`
    Resource string `json:"resource"`
    Clause Clause `json:"clause"`
    Expression string `json:"expression,omitempty"`
    Expected string `json:"expected"`
    ErrorContains string `json:"errorContains,omitempty"`
}
type Correlation struct { Resource string `json:"resource"`; Expected string `json:"expected"` }
type Dataset struct {
    Fixture
    Matrices []Matrix `json:"matrices"`
    Cases []Case `json:"cases"`
    Correlation []Correlation `json:"correlation"`
    Native []Case `json:"native"`
}
type Observation struct {
    Name string `json:"name"`
    Category string `json:"category"`
    Resource string `json:"resource"`
    Clause *Clause `json:"clause,omitempty"`
    Expression string `json:"expression,omitempty"`
    Expected string `json:"expected"`
    ExpectedErrorContains string `json:"expectedErrorContains,omitempty"`
    Actual string `json:"actual"`
    CheckedType string `json:"checkedType,omitempty"`
    ReturnedValue string `json:"returnedValue,omitempty"`
    ReturnedError string `json:"returnedError,omitempty"`
    Assertion bool `json:"assertion"`
}
type Results struct {
    Scope string `json:"scope"`
    GoVersion string `json:"goVersion"`
    CELPin string `json:"celPin"`
    SourceSHA256 map[string]string `json:"sourceSha256"`
    Total int `json:"total"`
    Passed int `json:"passed"`
    Unexpected int `json:"unexpected"`
    Categories map[string]int `json:"categories"`
    ExpectedCounts map[string]int `json:"expectedCounts"`
    ActualCounts map[string]int `json:"actualCounts"`
    Limitations []string `json:"limitations"`
    Observations []Observation `json:"observations"`
}
func run(catalog *Catalog, data Dataset, c Case, category string, native bool) Observation {
    obs:=Observation{Name:c.Name,Category:category,Resource:c.Resource,Expected:c.Expected,ExpectedErrorContains:c.ErrorContains}
    r,ok:=data.Resources[c.Resource]; if !ok { panic("missing resource "+c.Resource) }
    expr:=c.Expression
    if !native {
        obs.Clause=&c.Clause
        var err error
        expr,err=generate(catalog,r.Schema,c.Clause)
        if err!=nil { obs.Actual="builder-error"; obs.ReturnedError=err.Error(); return finish(obs) }
    }
    obs.Expression=expr
    root:=catalog.celType(catalog.defs[r.Schema])
    env,err:=cel.NewEnv(cel.CustomTypeProvider(catalog),cel.CustomTypeAdapter(catalog),cel.Variable("resource",root),cel.ParserRecursionLimit(64),cel.ParserExpressionSizeLimit(8192))
    if err!=nil { panic(err) }
    ast,issues:=env.Compile(expr)
    if issues!=nil && issues.Err()!=nil { obs.Actual="check-error"; obs.ReturnedError=issues.Err().Error(); return finish(obs) }
    obs.CheckedType=ast.OutputType().String()
    value,err:=catalog.admit(r)
    if err!=nil { obs.Actual="admission-error"; obs.ReturnedError=err.Error(); return finish(obs) }
    program,err:=env.Program(ast,cel.CostLimit(10000))
    if err!=nil { obs.Actual="program-error"; obs.ReturnedError=err.Error(); return finish(obs) }
    out,_,err:=program.Eval(map[string]any{"resource":value})
    if out!=nil { obs.ReturnedValue=fmt.Sprint(out) }
    if err!=nil {
        obs.Actual="eval-error"; obs.ReturnedError=err.Error()
        if strings.Contains(err.Error(),"hydration-needed") { obs.Actual="hydration-needed" }
    } else if out!=nil && types.IsError(out) {
        // Retain a returned CEL error even if a library release omits Go's error.
        obs.Actual="eval-error"; obs.ReturnedError=fmt.Sprint(out)
        if strings.Contains(obs.ReturnedError,"hydration-needed") { obs.Actual="hydration-needed" }
    } else if _,ok:=out.(types.Bool); !ok {
        obs.Actual="non-bool-result"
    } else { obs.Actual=fmt.Sprint(out) }
    return finish(obs)
}
func finish(obs Observation) Observation {
    obs.Assertion=obs.Actual==obs.Expected && (obs.ExpectedErrorContains=="" || strings.Contains(obs.ReturnedError,obs.ExpectedErrorContains))
    if obs.Expected=="true" || obs.Expected=="false" { obs.Assertion=obs.Assertion && obs.CheckedType=="bool" && obs.ReturnedError=="" }
    if obs.Expected=="hydration-needed" { obs.Assertion=obs.Assertion && strings.Contains(obs.ReturnedError,"hydration-needed") }
    return obs
}
func main() {
    raw,err:=os.ReadFile("fixtures.json"); if err!=nil{panic(err)}
    var data Dataset
    decoder:=json.NewDecoder(bytes.NewReader(raw)); decoder.UseNumber(); decoder.DisallowUnknownFields()
    if err:=decoder.Decode(&data);err!=nil{panic(err)}
    catalog,err:=newCatalog(data.Definitions); if err!=nil{panic(err)}
    result:=Results{
        Scope:"throwaway builder clause generation through native CEL; catalog coverage errors, no preflight or authorization",
        GoVersion:runtime.Version(),CELPin:"cel.dev/cel-go v0.32.0",
        SourceSHA256:map[string]string{},Categories:map[string]int{},ExpectedCounts:map[string]int{},ActualCounts:map[string]int{},
        Limitations:[]string{
            "Archived first-success union adapter is unchanged; no anyOf/oneOf or discriminator admission validation proven.",
            "Explicit host branch metadata generates native type/discriminator guards; no general flow-sensitive narrowing.",
            "Path absence is logical unreachability: absent or null ancestors make descendant path absent, not descendant null.",
            "No authorization, acquisition preflight, hydration scheduling, actual editor, or arbitrary CEL reverse conversion implemented.",
            "Native AND/OR can mask unavailable-field errors; a boolean result does not establish complete coverage.",
            "Incomplete maps require whole-map hydration; lists are admitted sequences with no partial-index coverage model.",
            "Homogeneous small int64 literals only; no numeric dependency correction or mixed numeric-domain claim.",
            "Bounded fixture dialect, clause trees and paths, not a complete JSON Schema dialect or production builder implementation.",
        },
    }
    add:=func(obs Observation){ result.Observations=append(result.Observations,obs); result.Total++; result.Categories[obs.Category]++; result.ExpectedCounts[obs.Expected]++; result.ActualCounts[obs.Actual]++; if obs.Assertion{result.Passed++}else{result.Unexpected++} }
    ops:=[]string{"absent","present","null","non-null","eq","not-eq","ne"}
    for _,m:=range data.Matrices {
        if len(m.Expected)!=len(ops){panic("matrix expectation arity")}
        for i,op:=range ops {
            clause:=Clause{Op:op,Path:m.Path,Value:m.Value}
            if op=="not-eq"{clause=Clause{Op:"not",Children:[]Clause{{Op:"eq",Path:m.Path,Value:m.Value}}}}
            add(run(catalog,data,Case{Name:m.Name+" / "+op,Resource:m.Resource,Clause:clause,Expected:m.Expected[i]},"state-matrix",false))
        }
    }
    for _,c:=range data.Cases{add(run(catalog,data,c,"structured-clause",false))}
    correlated:=Clause{Op:"exists",Path:[]Step{{Field:"tags"}},Children:[]Clause{{Op:"and",Children:[]Clause{
        {Op:"eq",Path:[]Step{{Field:"key"}},Value:"env"},
        {Op:"eq",Path:[]Step{{Field:"value"}},Value:"prod"},
    }}}}
    for _,c:=range data.Correlation{add(run(catalog,data,Case{Name:"same element correlation / "+c.Resource,Resource:c.Resource,Clause:correlated,Expected:c.Expected},"correlated-array",false))}
    // These are intentional native CEL controls, not part of the builder document.
    for _,c:=range data.Native{add(run(catalog,data,c,"native-CEL-control",true))}
    for _,name:=range []string{"adapter.go","builder.go","main.go","fixtures.json","go.mod","go.sum"}{
        source,err:=os.ReadFile(name);if err!=nil{panic(err)}; hash:=sha256.Sum256(source);result.SourceSHA256[name]=hex.EncodeToString(hash[:])
    }
    out,err:=json.MarshalIndent(result,"","  ");if err!=nil{panic(err)};out=append(out,'\n')
    if err:=os.WriteFile("results.json",out,0644);err!=nil{panic(err)}
    if _,err:=os.Stdout.Write(out);err!=nil{panic(err)}
    if result.Unexpected>0{os.Exit(1)}
}
