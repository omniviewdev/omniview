package main

import (
    "encoding/json"
    "fmt"
    "regexp"
    "strconv"
    "strings"
)

// Throwaway bounded clause document, not an authoring DTO or a CEL evaluator.
// A branch selection is explicit host schema metadata, never inferred from text.
type Step struct {
    Field string `json:"field,omitempty"`
    Key *string `json:"key,omitempty"`
    Index *int `json:"index,omitempty"`
    Branch *int `json:"branch,omitempty"`
    Discriminator string `json:"discriminator,omitempty"`
    Tag string `json:"tag,omitempty"`
}
type Clause struct {
    Op string `json:"op"`
    Path []Step `json:"path,omitempty"`
    Value any `json:"value,omitempty"`
    Type string `json:"type,omitempty"`
    Children []Clause `json:"children,omitempty"`
}
type scope struct { root string; schema *Schema }
type Generator struct { catalog *Catalog; nodes int }
var ident = regexp.MustCompile(`^[A-Za-z_][A-Za-z0-9_]*$`)
func and(parts []string) string {
    if len(parts)==0 { return "true" }
    return "("+strings.Join(parts," && ")+")"
}
func unwrap(c *Catalog, s *Schema) (*Schema, bool) {
    s=c.resolve(s)
    if s.Kind=="nullable" { return c.resolve(s.Value), true }
    return s,false
}
// path emits guards in traversal order. Every object field is presence-tested,
// including required fields: schema requiredness never implies acquired coverage.
func (g *Generator) path(sc scope, steps []Step) (string, *Schema, []string, error) {
    if len(steps)==0 || len(steps)>12 { return "",nil,nil,fmt.Errorf("path bound: need 1..12 steps") }
    expr,s:=sc.root,sc.schema
    guards:=[]string{}
    for _, step:=range steps {
        inner,nullable:=unwrap(g.catalog,s)
        if nullable { guards=append(guards,expr+" != null") }
        s=inner
        if s.Kind=="union" {
            if step.Branch==nil || *step.Branch<0 || *step.Branch>=len(s.Variants) { return "",nil,nil,fmt.Errorf("object union requires explicit branch") }
            s=g.catalog.resolve(s.Variants[*step.Branch])
            if s.Kind!="object" { return "",nil,nil,fmt.Errorf("only object branch traversal supported") }
            guards=append(guards,"type("+expr+") == "+g.catalog.names[s])
            if step.Discriminator!="" {
                field,ok:=s.Fields[step.Discriminator]
                if !ok || g.catalog.resolve(field).Kind!="string" || !ident.MatchString(step.Discriminator) { return "",nil,nil,fmt.Errorf("unsupported discriminator") }
                guards=append(guards,"has("+expr+"."+step.Discriminator+")",expr+"."+step.Discriminator+" == "+strconv.Quote(step.Tag))
            }
        } else if step.Branch!=nil || step.Discriminator!="" { return "",nil,nil,fmt.Errorf("branch condition only valid at union") }
        selectors:=0
        if step.Field!="" { selectors++ }; if step.Key!=nil { selectors++ }; if step.Index!=nil { selectors++ }
        if selectors!=1 { return "",nil,nil,fmt.Errorf("exactly one path selector required") }
        switch {
        case step.Field!="":
            if s.Kind!="object" || !ident.MatchString(step.Field) { return "",nil,nil,fmt.Errorf("unsupported object field selector") }
            child,ok:=s.Fields[step.Field]; if !ok { return "",nil,nil,fmt.Errorf("unknown schema field %s",step.Field) }
            expr+="."+step.Field
            guards=append(guards,"has("+expr+")")
            s=child
        case step.Key!=nil:
            if s.Kind!="map" || len(*step.Key)>128 { return "",nil,nil,fmt.Errorf("unsupported map selector") }
            guards=append(guards,strconv.Quote(*step.Key)+" in "+expr)
            expr+="["+strconv.Quote(*step.Key)+"]"
            s=s.Value
        case step.Index!=nil:
            if s.Kind!="list" || *step.Index<0 || *step.Index>=maxCollection { return "",nil,nil,fmt.Errorf("unsupported list index") }
            guards=append(guards,"size("+expr+") > "+strconv.Itoa(*step.Index))
            expr+="["+strconv.Itoa(*step.Index)+"]"
            s=s.Element
        }
    }
    return expr,s,guards,nil
}
func literal(v any) (string,error) {
    // Only bounded scalar literals and empty collections are in this experiment.
    switch x:=v.(type) {
    case string:
        if len(x)>256 { return "",fmt.Errorf("literal bound") }; return strconv.Quote(x),nil
    case bool: return strconv.FormatBool(x),nil
    case json.Number:
        if !integerLexeme.MatchString(string(x)) { return "",fmt.Errorf("only homogeneous int literals in probe") }
        if _,err:=strconv.ParseInt(string(x),10,64); err!=nil { return "",err }; return string(x),nil
    case []any: if len(x)==0 { return "[]",nil }
    case map[string]any: if len(x)==0 { return "{}",nil }
    }
    return "",fmt.Errorf("unsupported literal; null requires explicit null-state clause")
}
func (g *Generator) generate(c Clause,sc scope,depth int) (string,error) {
    g.nodes++
    if depth>12 || g.nodes>64 { return "",fmt.Errorf("clause bound") }
    switch c.Op {
    case "and","or":
        if len(c.Children)<2 || len(c.Children)>8 { return "",fmt.Errorf("group needs 2..8 children") }
        parts:=[]string{}
        for _,child:=range c.Children { text,err:=g.generate(child,sc,depth+1); if err!=nil{return "",err}; parts=append(parts,text) }
        join:=" && "; if c.Op=="or" { join=" || " }; return "("+strings.Join(parts,join)+")",nil
    case "not":
        if len(c.Children)!=1 { return "",fmt.Errorf("not needs one complete clause") }
        text,err:=g.generate(c.Children[0],sc,depth+1); return "!("+text+")",err
    }
    expr,s,guards,err:=g.path(sc,c.Path); if err!=nil{return "",err}
    inner,nullable:=unwrap(g.catalog,s)
    switch c.Op {
    case "present": return and(guards),nil
    case "absent": return "!("+and(guards)+")",nil
    case "null":
        if !nullable { return "",fmt.Errorf("null state requires nullable schema") }
        return and(append(guards,expr+" == null")),nil
    case "non-null":
        if nullable { guards=append(guards,expr+" != null") }; return and(guards),nil
    case "eq","ne":
        if nullable { guards=append(guards,expr+" != null") }
        if inner.Kind=="union" {
            if c.Type!="string" && c.Type!="int" && c.Type!="bool" { return "",fmt.Errorf("primitive union needs explicit supported type") }
            found:=false
            for _,branch:=range inner.Variants { k:=g.catalog.resolve(branch).Kind; if k==c.Type || k=="int64" && c.Type=="int" { found=true } }
            if !found { return "",fmt.Errorf("type guard not a declared union branch") }
            guards=append(guards,"type("+expr+") == "+c.Type)
        } else if c.Type!="" { return "",fmt.Errorf("type guard requires primitive union") }
        value,err:=literal(c.Value); if err!=nil{return "",err}
        op:=" == "; if c.Op=="ne" { op=" != " }; return and(append(guards,expr+op+value)),nil
    case "exists":
        if inner.Kind!="list" || len(c.Children)!=1 { return "",fmt.Errorf("exists requires list and one correlated child") }
        if nullable { guards=append(guards,expr+" != null") }
        // A fresh depth-derived binder keeps every child predicate on the same element.
        binder:="item"+strconv.Itoa(depth)
        child,err:=g.generate(c.Children[0],scope{binder,inner.Element},depth+1); if err!=nil{return "",err}
        return and(append(guards,expr+".exists("+binder+", "+child+")")),nil
    default: return "",fmt.Errorf("unsupported clause operation %s",c.Op)
    }
}
func generate(catalog *Catalog,schema string,c Clause) (string,error) {
    root,ok:=catalog.defs[schema]; if !ok { return "",fmt.Errorf("missing root schema") }
    g:=&Generator{catalog:catalog}; return g.generate(c,scope{"resource",root},0)
}
