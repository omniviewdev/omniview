# Parent verification and interpretation

Scope: accepted section-8 nullable/union confirmation. Throwaway artifacts, not product code. No schema authoring service/editor, client bindings, authorization preflight, hydration scheduler, numeric fix or production budgets implemented.

## Executed commands

From `admission/`: `GOWORK=off go run .` -> 131 observations; zero unexpected assertion failures; 68 feature-success, 46 expected-rejection, 17 known-limitation observations. Parent reran after agent completion and read report/results, including retained initial-results.json with the first two harness assertion failures. The corrections preserve the actual nonnullable/null checker diagnostic and schema rejection without pinning arbitrary validation ordering.

From `builder/`: `GOWORK=off go run .` -> 269/269 asserted expected outcomes; zero unexpected outcomes. 224 boolean results (87 true, 137 false), 33 hydration-needed errors, three other native evaluation errors, five admission rejections, four unsupported builder clause rejections. The generator supplies structured supported clauses; native CEL, not a second evaluator, supplies results.

From `admission/`: `GOWORK=off go run adapter.go extensions.go retention_probe.go` -> before 3 catalog-name entries; after 1000 repeated identical overlapping-anyOf admissions, 1003 entries. This parent-owned smoke records actual retained metadata growth, not heap/RSS or latency. `retention_probe.go` has a build constraint so normal `go run .` excludes its alternate main. `GOWORK=off go list -f '{{.GoFiles}}' .` confirmed only adapter.go, extensions.go and main.go are normally selected.

## Confirmed semantic evidence

- AnyOf and oneOf counting, zero-match/overlap rejection, actual discriminator constraints, closed/typed additional properties and shape-preserving overlap navigation in the bounded normalized dialect.
- Optional/nonnullable, required/nullable and optional/nullable values, complete absence and explicit-known-absence versus unavailable representation fields. Known requiredness is not proof of acquisition coverage.
- Generated presence/null guards, grouping and whole-clause negation versus guarded inequality, nested ancestors, map keys/list indices, false/zero/empty values, explicit type/discriminator guards and one-binder correlated array predicates.
- Native CEL can mask an unavailable-field error with a decisive false conjunction or true disjunction in either operand position. A resulting boolean does not establish coverage/authorization. Failed admission remains outside evaluation and cannot be repaired by a false branch.

## Constraints not closed by passing assertions

- The union adapter experimentally mutates catalog.names for new per-value merged object schemas; retention smoke proves repeated admissions retain metadata. Do not copy this as a production strategy. Production catalogs/environments must remain revision-bound and bounded/immutable during value admission; per-observation dispatch must be lifetime-bound or reuse bounded structural metadata.
- The builder uses an unchanged first-success adapter for disjoint unions. The admission adapter uses explicit anyOf/oneOf and merged overlapping object dispatch. These were independent probes, not a combined proof: branch-type guards in the first cannot be assumed valid for the second. Overlapping alternatives cannot generally be represented by a single runtime branch identity; use validated conditions or report the supported authoring subset.
- Descendant path presence in the builder means terminal reachability: a null ancestor makes its descendant path not present, not itself a null terminal value. This is a probe convention requiring explicit user-facing labels/semantics before production UX, not evidence that an absent child property physically exists inside null.
- Do not add `!= null` to statically nonnullable fields: real CEL can reject that operation. Guards must follow actual schema/CEL type support, not generic string templates.
- Nullable complex values/unions remain dyn at CEL checking; strict admission does not imply flow-sensitive type safety.
- Incomplete unions/maps/lists conservatively require hydration in the admission experiment; partial per-key/index/branch coverage and mixed object/map/dynamic union dispatch are explicitly unimplemented/rejected. This is not a full JSON Schema/OpenAPI dialect adapter.
- No arbitrary code-to-builder reverse conversion, schema-revision/stale authoring-response integration or actual editor proof. Those remain P16/P19/P21 implementation gates.

## Reproduction

Pinned modules/checksums are in both subdirectories. From a fresh extraction run each executable command above (all with GOWORK=off); expected rejection/limitation observations are not feature successes. Reports under admission/ may regenerate when its probe executes. No binaries/caches are included. The evidence preserves sources and results; it is not an integration-ready feature implementation.
