# CEL Go comparison spike

## Scope and provenance

This is an isolated, executable Go experiment, not production integration or a replacement query engine. No product files, credentials, clusters or repository module files were changed. `main.go`, `go.mod`, `go.sum`, `cel-probe`, `results.json` and `checked-ast.json` are retained here. The shared fixtures are `../corpus.json`; the timed workload follows `../benchmark-contract.json`.

**Pinned implementation: `cel.dev/cel-go v0.32.0`.** The original requested `github.com/google/cel-go` is now a read-only compatibility repository. Its current README explicitly directs new development to the canonical module `cel.dev/cel-go`, repository `github.com/cel-expr/cel-go`. The Go proxy's canonical `@latest` response identified v0.32.0, release time `2026-08-19T17:33:13Z`, tag commit `f2039bc647bca407d882d90436fc8b91bab1ae62`. The historical module's proxy latest was v0.30.0; it was downloaded for discovery only and is **not** the tested implementation or a dependency of the executable. No performance/conformance equivalence between those versions is claimed.

Provenance: [compatibility migration notice](https://github.com/google/cel-go#readme), [canonical release metadata](https://proxy.golang.org/cel.dev/cel-go/@v/v0.32.0.info), [canonical pinned source](https://github.com/cel-expr/cel-go/tree/v0.32.0).

Exact runtime dependencies, also recorded with checksums in `results.json`/`go.sum`:

| Module | Version |
|---|---|
| cel.dev/cel-go | v0.32.0 |
| cel.dev/expr | v0.25.1 |
| github.com/antlr4-go/antlr/v4 | v4.13.1 |
| go.yaml.in/yaml/v3 | v3.0.4 |
| golang.org/x/exp | v0.0.0-20240823005443-9b4947da3948 |
| golang.org/x/text | v0.22.0 |
| google.golang.org/genproto/googleapis/api | v0.0.0-20240826202546-f6391c0de4c7 |
| google.golang.org/genproto/googleapis/rpc | v0.0.0-20240826202546-f6391c0de4c7 |
| google.golang.org/protobuf | v1.36.10 |

`go mod tidy` additionally downloaded upstream test dependencies github.com/google/go-cmp v0.7.0 and gopkg.in/check.v1 v0.0.0-20161208181325-20d25e280405. They are not linked runtime dependencies. Module directive is Go 1.25.0; measured toolchain is Go 1.26.1.

## Reproduction and observed execution

Run from `/tmp/omniview-query-spike.DEcsXr/cel`:

```sh
GOWORK=off GOMODCACHE=/tmp/omniview-query-spike.DEcsXr/cel/.modcache GOCACHE=/tmp/omniview-query-spike.DEcsXr/cel/.gocache go mod download cel.dev/cel-go@v0.32.0
GOWORK=off GOMODCACHE=/tmp/omniview-query-spike.DEcsXr/cel/.modcache GOCACHE=/tmp/omniview-query-spike.DEcsXr/cel/.gocache go mod tidy
mkdir -p .gotmp
GOWORK=off GOMODCACHE=/tmp/omniview-query-spike.DEcsXr/cel/.modcache GOCACHE=/tmp/omniview-query-spike.DEcsXr/cel/.gocache GOTMPDIR=/tmp/omniview-query-spike.DEcsXr/cel/.gotmp go build -o cel-probe . && ./cel-probe
```

The existing executable can be rerun as `./cel-probe` or `./cel-probe /absolute/path/to/corpus.json`; it writes outputs in the current directory. It uses standard Go `testing.Benchmark` internally for allocation/preparation measurements. It does not run `go test`, use provider services, or start a watcher.

Final observed stdout (exit 0):

```text
CEL v0.32.0: 63 observations; 0 assertion failures; results.json written
```

Development failures were not hidden: the first build referenced nonexistent `cel.NewTextSource` (correct API is `common.NewTextSource`). The first executable attempt reached static cost estimation and panicked because `EstimateCost(ast, nil)` dereferenced the required estimator at `checker/cost.go:923`. The final source supplies a `noHints` estimator whose methods return nil, and records that limitation. All probes existed before the final execution; the final run covers the entire corpus, not a narrowed replacement.

## Shared semantics: actual results

The resource activation is `r: map(string,dyn)`. String and integer parameters are declared CEL variables and passed via Go activations, never interpolated into source. The shared corpus's JSON numeric fields are admitted via `Decoder.UseNumber` followed by range-checked `Int64`. This experiment admits integral numeric fields only; it is not a decimal transport implementation.

| Shared case | Observed IDs / outcome | Implementation boundary |
|---|---|---|
| Same-element tag key env AND value prod | cloud-a | Native `exists(t, t.key == "env" && t.value == "prod")`; cloud-b does not spuriously match |
| Quoted map key `app.kubernetes.io/name` | cloud-a | Native string-key index with presence guard |
| Container nested boolean `State.Running` | container-a | Native nested selection and `has` guards |
| Numeric CPU >= bound integer 2 | vm-100 | Native comparison, typed int binding |
| Same interface name eth0 AND public true | none | Native same-element `exists`; does not combine eth0 with eth1 |
| Pod container sidecar AND agent:v2 | pod-a | Native same-element `exists` |
| Explicit nullable null | cloud-a | `has(r.nullable) && r.nullable == null` |
| Missing nullable | cloud-b, container-a, vm-100, pod-a | `!has(r.nullable)`; absence is not silently null |
| Global n ascending, offset 1, limit 2 | cloud-b, container-a | Host numeric sort + identity tie-break + slice; also executed with standard library `ext.Lists` sortBy/slice |
| Bound environment prod | cloud-a | Runtime string variable |
| Bound malicious `prod' || true || '` | none | Same compiled expression, runtime string value; no source substitution |
| Exact 9007199254740993 versus 9007199254740992 | cloud-a only | CEL `int(r.exact) == exact`, exact int64 binding |

All shared membership predicates recorded zero runtime errors. Additional actual checks: container Labels tag-map query selects container-a; two-level nested group/member correlation returns true for a same-group match and false when the matching member belongs to a different group.

Core CEL did **not** compile `resources.sortBy(...).slice(...)`: those operations are not core built-ins. The ordinary upstream `ext.Lists()` extension compiled and evaluated `resources.sortBy(x, x.n).slice(1,3).map(x,x.id)` to the expected IDs. This is explicitly a collection transform, **not** the benchmarked per-resource predicate, and it does not supply the complete host order/null/missing/tie-break contract. No custom language function or custom CEL value adapter was installed.

## Numeric and timestamp findings

**Exact typed integers are supported; untyped float64 JSON admission is unsafe.** A separate raw JSON payload contains actual JSON numbers, not the decimal-string fixtures:

```json
[{"id":"hi","n":9007199254740993},{"id":"lo","n":9007199254740992}]
```

Executed through real decoding and CEL evaluation:

| Admission | Decoded values | `r.n == exact`, exact bound as int64 9007199254740993 |
|---|---|---|
| `json.Unmarshal` into map[string]any | Both float64 9007199254740992 | **true, true** |
| `Decoder.UseNumber`, pass json.Number directly | Distinct decimal json.Number values | true, false |
| `UseNumber`, host range-checked Int64 conversion | Distinct int64 values | true, false |

The direct `json.Number` case needs no custom adapter: the upstream default adapter tries Int64 first, then float64. [Pinned adapter source](https://github.com/cel-expr/cel-go/blob/v0.32.0/common/types/provider.go#L667-L673). Therefore values outside int64 require an explicit host policy rather than assuming arbitrary precision.

The float64 case is worse than transport loss alone: in this version, mixed double/int comparison converts the int to double, so the lower rounded value also equals the high int64 binding. This was **executed**, not inferred. [Pinned numeric comparison source](https://github.com/cel-expr/cel-go/blob/v0.32.0/common/types/compare.go#L23-L34) explains the observed result. Required policy: exact integer schema fields and bindings must not enter evaluation as double; a future schema admission/checking boundary must reject unsafe cross-type combinations. This spike does not implement that catalog-wide boundary.

Other executed outcomes:

- Distinct large integer literals compare false, without an IEEE754 collision.
- `9223372036854775807 + 1` returns `integer overflow`.
- `int("9223372036854775808")` and invalid decimal text return type-conversion errors.
- Passing string `"2"` to the declared int CPU parameter produces runtime `no such overload` for the tested numeric predicate. A declaration is not a full input-validation envelope.
- Native timestamp parse/compare correctly orders two RFC3339 instants; malformed timestamp returns `invalid RFC 3339 timestamp`.
- Decimal/fraction precision, uint64 boundary transport, protobuf Struct numeric transport, timezone normalization and JS client JSON handling are **not exercised**.

## Diagnostics, schemas and partial completion

Executed complete/partial drafts include `r.n ==`, unknown function, int/string static mismatch, `r.spec.`, `r.spec.con`, non-Kubernetes hardware fields, and Unicode preceding errors. Diagnostics expose line (1-based), column (0-based), expression ID and messages. For `"é😀" == 1 && missing == 2`, `missing` is at column/offset **13**, not UTF-8 byte offset 17 or UTF-16 code-unit offset 14. This demonstrates **Unicode scalar/code-point offsets** in the exercised source API. The host must explicitly convert these to its editor/wire convention. Diagnostic errors provide a location point, not a universal end range.

The dynamic map environment accepts `r.spec.con` as a complete ordinary expression with type dyn, not as a recoverable prefix with suggestions; it also accepts typo fields at check time. Evaluating an absent unguarded field returns `no such key: unprovided`. It does not remove that predicate or return a successful empty result.

For actual schema-aware checking, this spike hand-declares tiny Go `Pod`, `PodSpec` and `Container` structs and registers them with ordinary upstream `ext.NativeTypes(..., ext.ParseStructTag("json"))`. Valid nested array evaluation succeeds, invalid `hardware`/`con` fields are rejected, and string nodeName versus integer comparison is rejected at compile time. This is **not a provider schema adapter** and proves nothing about arbitrary JSON Schema unions, recursive references, schema admission caching, required/optional/null-preserving type generation or heterogeneous provider target unions. Those remain unknown.

Both typed and dynamic environments return no AST for trailing `r.spec.`. Typed `r.spec.con` returns no AST and an undefined-field diagnostic. No editor completion API was located in the public cel/parser packages; async evaluation APIs mentioning “completion” are unrelated. **Error-tolerant editor completion is unsupported by the exercised direct APIs**, not delivered by this spike. Host cursor recovery, schema traversal, suggestion ranking and client offset conversion are still required. Partial evaluation of unknown *values* is a different upstream capability and was not represented as partial-syntax completion.

Primary references: [pinned native struct integration](https://github.com/cel-expr/cel-go/blob/v0.32.0/ext/native.go), [ParseSource returns nil AST on errors](https://github.com/cel-expr/cel-go/blob/v0.32.0/cel/env.go#L714-L725), [source/offset implementation](https://github.com/cel-expr/cel-go/blob/v0.32.0/common/source.go), [diagnostic error type](https://github.com/cel-expr/cel-go/blob/v0.32.0/common/error.go).

## AST and bounded builder experiment

Actual APIs exercised: native `Ast.NativeRep`, preorder visitor, node kinds, type maps, native offset ranges, macro call metadata, AST unparser, checked-expression protobuf serialization and same-environment reload/evaluation. The primary predicate produces 22 visited native nodes including one comprehension, two recorded macro calls and 24 source positions. Checked AST is 1026 protobuf bytes / 3187 protojson bytes; both are recorded, with the protojson retained as `checked-ast.json`. Reloaded protobuf selects cloud-a, equal to the original program. Native ranges include token-only and synthetic macro positions, so they are **not full editor selection spans**.

The deliberately small builder subset is explicit: string/int/bool/null literals; identifiers r/environment/cpuMinimum; field selection and index; operators &&, ==, >=. Seven text expressions exercise string-key index, integer literals, null, true and false boolean literals, integer array index, typed bindings and conjunction. Each was converted from language AST to the subset structure, JSON serialized/deserialized, reconstructed with native ExprFactory, type checked, unparsed, recompiled and evaluated on all five resources. Every pair matched, **including the same runtime errors for absent unguarded fields**. The subset rejects an actual comprehension AST with `AST kind 2 outside subset`. It is not a general reversible builder for all CEL, and it does not convert unsupported text to weakened builder predicates.

Primary references: [AST/node APIs](https://github.com/cel-expr/cel-go/tree/v0.32.0/common/ast), [native factory](https://github.com/cel-expr/cel-go/blob/v0.32.0/common/ast/factory.go), [AST I/O/unparser and protobuf contracts](https://github.com/cel-expr/cel-go/blob/v0.32.0/cel/io.go). **Unknown:** cross-version serialized AST compatibility, untrusted checked-AST loading security, exhaustive macro roundtrips and a user-friendly correlated-array builder. A same-version reload is not evidence for those claims.

## Logical pushdown and final window

Actual simulated candidate predicate `r.kind == "cloud"` plus residual same-element tag predicate equals full predicate evaluation: cloud-a. This is a logical host simulation only, not proof that any cloud/provider filter implements equivalent string, null, array or numeric semantics.

For a separate final-window counterexample, full residual `r.n >= 3` followed by global ascending n/id sort and limit 2 returns container-a, pod-a. Applying candidate arrival-order limit 2 **before** residual/global sort returns cloud-a only. The unsafe transformation was explicitly detected and rejected. The host must retain final global operations unless provider capabilities/coverage establish equivalence.

## Real cancellation, parse bounds and cost behavior

Executed against a 1,000,000-item int64 list with expression `xs.all(x, x >= 0)`:

- `CostLimit(100)` aborts at actual cost **101**, error `operation cancelled: actual cost limit exceeded`, Go type `interpreter.EvalCancelledError`.
- `InterruptCheckFrequency(1)` plus real `Program.ContextEval` honors a pre-canceled context: `operation interrupted: context canceled`, observed 4,584 ns / cost 6.
- A timer cancels the same real evaluator context during evaluation after 1 ms: evaluator returns that cancellation error, observed 1,153,125 ns / cost 4,331. The timer does not abandon an evaluator goroutine; ContextEval itself returns. The measurement includes scheduling and is not a cancellation-latency percentile or hard bound.
- A scalar `true` with a pre-canceled context still evaluates true with no error. Cancellation polling is at comprehension iteration checkpoints, not universal preflight admission. Host request handling should check cancellation separately; custom blocking function interruption is unexercised.
- Explicit `ParserRecursionLimit(20)` rejects 40 nested parentheses; explicit `ParserExpressionSizeLimit(128)` rejects a 133-code-point expression. Those limit errors have sentinel location (-1,-1), not a usable source range.
- Static EstimateCost with noHints estimator gives min 2, max 18446744073709551615: runtime list size is unknown, so this is not a useful admission budget without schema/cardinality hints. Passing a nil estimator panicked in the initial experiment; final code supplies the required object. This is not an evaluator-language extension.

Primary references: [ContextEval contract/implementation](https://github.com/cel-expr/cel-go/blob/v0.32.0/cel/program.go), [cost and interrupt options](https://github.com/cel-expr/cel-go/blob/v0.32.0/cel/options.go#L744-L750), [runtime cost API](https://github.com/cel-expr/cel-go/blob/v0.32.0/cel/options.go#L812-L830), [static estimator interface and use](https://github.com/cel-expr/cel-go/blob/v0.32.0/checker/cost.go). CPU-oriented cost is not a universal memory, regex, plugin-call or end-to-end query budget. These bounds do not establish provider acquisition/session budgets.

## Measured performance (descriptive only)

Environment reported by the executable: Apple M5 Max, darwin/arm64, Go go1.26.1, 18 CPUs, GOMAXPROCS 18; final output timestamp `2026-10-18T03:33:02Z` UTC. These are local exploratory measurements; parent sequential rerun is authoritative for candidate comparison. No vendor performance claims were used.

Primary workload: compile once, warm up 5000 evaluations, then deterministic `resources[i % 5]`, same-element env/prod predicate against **one resource at a time**. Decoding and construction of activation maps are excluded; library adaptation/evaluation allocations remain included. Every timed run produced 1000/10000 matches at 5000/50000 evaluations. Three runs are not p95/p99 evidence.

| Configuration | Evaluations | Total ns, runs 1 / 2 / 3 | ns/eval, runs 1 / 2 / 3 |
|---|---:|---|---|
| Default, uninstrumented | 5000 | 901958 / 923292 / 964666 | 180.392 / 184.658 / 192.933 |
| Default, uninstrumented | 50000 | 9809166 / 9951041 / 9961834 | 196.183 / 199.021 / 199.237 |
| Cost-tracked | 5000 | 2922500 / 2968417 / 2707833 | 584.500 / 593.683 / 541.567 |
| Cost-tracked | 50000 | 30179792 / 30185500 / 29861708 | 603.596 / 603.710 / 597.234 |

Separate automatic-N `testing.Benchmark` allocation evidence:

| Configuration | N | ns/op | allocs/op | bytes/op |
|---|---:|---:|---:|---:|
| Default evaluator | 5893281 | 208 | 3 | 144 |
| Cost-tracked evaluator | 1912100 | 608 | 14 | 641 |
| Parse only | 49890 | 24601 | 472 | 31182 |
| Check pre-parsed AST | 118264 | 10280 | 252 | 12637 |
| Compile parse+check | 34356 | 36308 | 724 | 43856 |
| Program construction from checked AST | 740781 | 1756 | 64 | 3216 |

Compilation is separated from evaluation; it is not amortized into the primary timings. The default fast path does **not** include runtime cost enforcement; production bounded execution must account for the measured instrumented overhead. This is one tiny mixed fixture shape, not a representative inventory cost model, concurrent throughput test, cold-start study, allocation-retention study or end-to-end UI/query benchmark.

## Representation recommendation and explicit limits

**For CEL, prefer the library-native checked language AST as the expression representation, inside a host logical query envelope; do not immediately invent a universal second expression IR.** The actual API already supplies typing, node visitation, source metadata, macro metadata, protobuf serialization and native construction. Pin language/environment/extension versions and retain source text. Keep target/scope/bindings, final ordering/projection/window and access/coverage/session concerns in the host contract, not disguised inside expression source.

A **small optional planning IR** is justified only for a declared provably supported pushdown subset or deliberately bounded builder form. Unsupported expressions must remain intact as native AST residuals or be rejected for that operation; they must never be approximated. The executed builder subset is evidence of a bounded integration route, not proof that a second universal IR is necessary or that all CEL can roundtrip through it.

CEL is viable for the exercised provider-neutral predicate semantics, typed integer/string bindings, timestamp operations and real bounded evaluation. Selection against the other candidate should use its equivalent measured evidence, not this report alone. Outstanding product prerequisites remain: provider structural-schema typing/admission (including unsafe double/int prevention), user-facing partial-draft completion, versioned offset/error contracts, complete order/null/missing policy, resource-acquisition budgets, realistic inventory measurement, native provider equivalence proof and correlated-array builder UX. None is presented as implemented here.
