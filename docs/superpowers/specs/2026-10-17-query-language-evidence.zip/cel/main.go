package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"reflect"
	"runtime"
	"runtime/debug"
	"sort"
	"strconv"
	"strings"
	"testing"
	"time"
	"unicode/utf8"

	"cel.dev/cel-go/cel"
	"cel.dev/cel-go/checker"
	"cel.dev/cel-go/common"
	"cel.dev/cel-go/common/ast"
	"cel.dev/cel-go/common/operators"
	"cel.dev/cel-go/common/types"
	"cel.dev/cel-go/ext"
	exprpb "google.golang.org/genproto/googleapis/api/expr/v1alpha1"
	"google.golang.org/protobuf/encoding/protojson"
	"google.golang.org/protobuf/proto"
)

type Corpus struct {
	Resources  []map[string]any `json:"resources"`
	Parameters map[string]any   `json:"parameters"`
	Cases      []map[string]any `json:"cases"`
}
type Observation struct {
	ID       string `json:"id"`
	Status   string `json:"status"`
	Evidence any    `json:"evidence"`
}

var observations []Observation
var failures int

func record(id, status string, evidence any) {
	observations = append(observations, Observation{id, status, evidence})
}
func check(id string, got, want any, evidence map[string]any) {
	ok := reflect.DeepEqual(got, want)
	if !ok {
		failures++
	}
	evidence["actual"] = got
	evidence["expected"] = want
	evidence["passed"] = ok
	record(id, map[bool]string{true: "supported", false: "failed"}[ok], evidence)
}
func must(err error) {
	if err != nil {
		panic(err)
	}
}
func normalize(v any) any {
	switch x := v.(type) {
	case json.Number:
		n, err := x.Int64()
		must(err)
		return n
	case []any:
		for i, y := range x {
			x[i] = normalize(y)
		}
	case map[string]any:
		for k, y := range x {
			x[k] = normalize(y)
		}
	}
	return v
}
func environment(extra ...cel.EnvOption) *cel.Env {
	opts := []cel.EnvOption{cel.Variable("r", cel.MapType(cel.StringType, cel.DynType)), cel.Variable("environment", cel.StringType), cel.Variable("cpuMinimum", cel.IntType), cel.Variable("exact", cel.IntType), cel.Variable("xs", cel.ListType(cel.IntType)), cel.Variable("resources", cel.ListType(cel.MapType(cel.StringType, cel.DynType))), cel.EnableMacroCallTracking()}
	e, err := cel.NewEnv(append(opts, extra...)...)
	must(err)
	return e
}
func compile(e *cel.Env, text string, opts ...cel.ProgramOption) (cel.Program, *cel.Ast) {
	a, iss := e.Compile(text)
	must(iss.Err())
	p, err := e.Program(a, opts...)
	must(err)
	return p, a
}
func bindings(r map[string]any, c Corpus) map[string]any {
	return map[string]any{"r": r, "environment": c.Parameters["environment"], "cpuMinimum": c.Parameters["cpuMinimum"], "exact": int64(9007199254740993)}
}
func evalEvidence(p cel.Program, b any) map[string]any {
	v, d, err := p.Eval(b)
	m := map[string]any{}
	if v != nil {
		m["value"] = fmt.Sprint(v)
		m["type"] = fmt.Sprint(v.Type())
	}
	if err != nil {
		m["error"] = err.Error()
		m["errorGoType"] = fmt.Sprintf("%T", err)
	}
	if d != nil && d.ActualCost() != nil {
		m["cost"] = *d.ActualCost()
	}
	return m
}
func ids(p cel.Program, c Corpus, override map[string]any) ([]string, []string) {
	out := []string{}
	errors := []string{}
	for _, r := range c.Resources {
		b := bindings(r, c)
		for k, v := range override {
			b[k] = v
		}
		v, _, err := p.Eval(b)
		if err != nil {
			errors = append(errors, r["id"].(string)+": "+err.Error())
			continue
		}
		if v == types.True {
			out = append(out, r["id"].(string))
		}
	}
	return out, errors
}
func expected(c Corpus, id, key string) []string {
	for _, v := range c.Cases {
		if v["id"] == id {
			out := []string{}
			for _, s := range v[key].([]any) {
				out = append(out, s.(string))
			}
			return out
		}
	}
	panic(id)
}

const primary = `has(r.tags) && r.tags.exists(t, t.key == "env" && t.value == "prod")`

func semantic(e *cel.Env, c Corpus) {
	cases := []struct{ id, text string }{
		{"tag-same-element", primary},
		{"quoted-map-key", `has(r.labels) && "app.kubernetes.io/name" in r.labels && r.labels["app.kubernetes.io/name"] == "api"`},
		{"container-nested-bool", `has(r.State) && has(r.State.Running) && r.State.Running == true`},
		{"numeric-typed", `has(r.hardware) && has(r.hardware.cpu) && r.hardware.cpu >= cpuMinimum`},
		{"correlated-array", `has(r.interfaces) && r.interfaces.exists(i, i.name == "eth0" && i.public == true)`},
		{"pod-array", `has(r.spec) && has(r.spec.containers) && r.spec.containers.exists(c, c.name == "sidecar" && c.image == "agent:v2")`},
		{"bound-string", `has(r.tags) && r.tags.exists(t, t.key == "env" && t.value == environment)`},
		{"exact-integer", `has(r.exact) && int(r.exact) == exact`},
	}
	for _, v := range cases {
		p, _ := compile(e, v.text)
		got, errs := ids(p, c, nil)
		check(v.id, got, expected(c, v.id, "expectedIds"), map[string]any{"expression": v.text, "runtimeErrors": errs})
		if len(errs) > 0 {
			failures++
		}
		if v.id == "bound-string" {
			got, errs = ids(p, c, map[string]any{"environment": c.Parameters["malicious"]})
			check("bound-string-malicious", got, expected(c, v.id, "expectedMaliciousIds"), map[string]any{"expression": v.text, "runtimeErrors": errs, "binding": c.Parameters["malicious"]})
		}
	}
	for _, v := range []struct{ id, text, key string }{{"explicit-null", `has(r.nullable) && r.nullable == null`, "expectedExplicitNullIds"}, {"missing", `!has(r.nullable)`, "expectedMissingIds"}} {
		p, _ := compile(e, v.text)
		got, errs := ids(p, c, nil)
		check("missing-null-"+v.id, got, expected(c, "missing-null", v.key), map[string]any{"expression": v.text, "runtimeErrors": errs})
	}
	// Deliberately host-owned sort/page; CEL predicate does not silently become a collection query.
	ordered := append([]map[string]any{}, c.Resources...)
	sort.Slice(ordered, func(i, j int) bool {
		ni, nj := ordered[i]["n"].(int64), ordered[j]["n"].(int64)
		if ni == nj {
			return ordered[i]["id"].(string) < ordered[j]["id"].(string)
		}
		return ni < nj
	})
	got := []string{ordered[1]["id"].(string), ordered[2]["id"].(string)}
	check("global-sort-page-host", got, expected(c, "global-sort-page", "expectedIds"), map[string]any{"implementation": "Go host numeric sort + identity tie-break, offset 1 limit 2; not core CEL"})
	_, iss := e.Compile(`resources.sortBy(x, x.n).slice(1,3).map(x,x.id)`)
	record("global-sort-page-core", "unsupported", map[string]any{"compileError": iss.Err().Error(), "scope": "core environment without list extension"})
	le := environment(ext.Lists())
	text := `resources.sortBy(x, x.n).slice(1,3).map(x,x.id)`
	p, _ := compile(le, text)
	v, _, err := p.Eval(map[string]any{"resources": c.Resources})
	must(err)
	native, err := v.ConvertToNative(reflect.TypeOf([]string{}))
	must(err)
	check("global-sort-page-library-extension", native, expected(c, "global-sort-page", "expectedIds"), map[string]any{"expression": text, "extension": "cel.dev/cel-go/ext.Lists default version at v0.32.0; no custom function"})
	p, _ = compile(e, `has(r.Labels) && r.Labels["env"] == environment`)
	got, errs := ids(p, c, nil)
	check("tag-map", got, []string{"container-a"}, map[string]any{"runtimeErrors": errs})
	nested := `r.groups.exists(g, g.name == "a" && g.members.exists(m, m.name == "target" && m.enabled))`
	np, _ := compile(e, nested)
	nestedRows := []map[string]any{
		{"groups": []any{map[string]any{"name": "a", "members": []any{map[string]any{"name": "target", "enabled": true}}}}},
		{"groups": []any{map[string]any{"name": "a", "members": []any{map[string]any{"name": "other", "enabled": true}}}, map[string]any{"name": "b", "members": []any{map[string]any{"name": "target", "enabled": true}}}}},
	}
	nestedValues := []any{}
	for _, r := range nestedRows {
		nestedValues = append(nestedValues, evalEvidence(np, map[string]any{"r": r})["value"])
	}
	check("nested-array-correlation", nestedValues, []any{"true", "false"}, map[string]any{"expression": nested, "fixtures": nestedRows})
}

func transport(e *cel.Env) {
	raw := []byte(`[{"id":"hi","n":9007199254740993},{"id":"lo","n":9007199254740992}]`)
	var standard []map[string]any
	must(json.Unmarshal(raw, &standard))
	p, _ := compile(e, `r.n == exact`)
	evalRows := func(rows []map[string]any) []map[string]any {
		out := []map[string]any{}
		for _, r := range rows {
			m := evalEvidence(p, map[string]any{"r": r, "exact": int64(9007199254740993)})
			m["id"] = r["id"]
			m["decodedGoType"] = fmt.Sprintf("%T", r["n"])
			m["decodedValue"] = fmt.Sprint(r["n"])
			out = append(out, m)
		}
		return out
	}
	record("json-default-decoding", "unsafe", map[string]any{"raw": string(raw), "rows": evalRows(standard), "decodedCollision": standard[0]["n"] == standard[1]["n"], "note": "Original integer precision is lost at float64 decoding; measured CEL mixed double/int equality also returns true for BOTH rows against exact int64 9007199254740993. Do not admit exact integer fields as double."})
	var numbered []map[string]any
	dec := json.NewDecoder(bytes.NewReader(raw))
	dec.UseNumber()
	must(dec.Decode(&numbered))
	record("json-number-direct", "observed", evalRows(numbered))
	for _, r := range numbered {
		normalize(r)
	}
	record("json-use-number-int64-admission", "supported", map[string]any{"policy": "JSON Decoder.UseNumber then range-checked Int64 before CEL adaptation; explicit host transport policy, not custom CEL adapter", "rows": evalRows(numbered)})
	hi := evalEvidence(p, map[string]any{"r": numbered[0], "exact": int64(9007199254740993)})
	lo := evalEvidence(p, map[string]any{"r": numbered[1], "exact": int64(9007199254740993)})
	check("exact-int64-decoded-evaluation", []any{hi["value"], lo["value"]}, []any{"true", "false"}, map[string]any{})
	for _, text := range []string{`9007199254740993 == 9007199254740992`, `9223372036854775807 + 1`, `int("9223372036854775808")`, `int("not-a-number")`} {
		p, _ := compile(e, text)
		record("numeric-"+text, "observed", evalEvidence(p, map[string]any{}))
	}
	p, _ = compile(e, `cpuMinimum >= 2`)
	record("wrong-binding-type", "observed", evalEvidence(p, map[string]any{"cpuMinimum": "2"}))
	for _, text := range []string{`timestamp("2026-10-17T00:00:00Z") > timestamp("2026-10-16T23:59:59Z")`, `timestamp("bad timestamp") > timestamp("2026-10-17T00:00:00Z")`} {
		p, _ := compile(e, text)
		record("timestamp-"+text, "observed", evalEvidence(p, map[string]any{}))
	}
	p, _ = compile(e, `r.unprovided == 1`)
	record("dynamic-unknown-field-runtime", "observed", evalEvidence(p, map[string]any{"r": map[string]any{}}))
}

type Container struct {
	Name  string `json:"name"`
	Image string `json:"image"`
}
type PodSpec struct {
	Containers []Container `json:"containers"`
	NodeName   string      `json:"nodeName"`
}
type Pod struct {
	Spec PodSpec `json:"spec"`
}

func diagnostic(e *cel.Env, text string) map[string]any {
	a, iss := e.Compile(text)
	m := map[string]any{"text": text, "astReturned": a != nil, "utf8Bytes": len(text), "unicodeScalars": utf8.RuneCountInString(text)}
	errs := []map[string]any{}
	for _, v := range iss.Errors() {
		off, found := common.NewTextSource(text).LocationOffset(v.Location)
		errs = append(errs, map[string]any{"message": v.Message, "line1Based": v.Location.Line(), "column0Based": v.Location.Column(), "offset": off, "offsetFound": found, "exprId": v.ExprID})
	}
	m["diagnostics"] = errs
	if iss.Err() != nil {
		m["rendered"] = iss.Err().Error()
	}
	if a != nil {
		m["checked"] = a.IsChecked()
		m["rootType"] = a.OutputType().String()
	}
	return m
}
func diagnostics(e *cel.Env) {
	for _, text := range []string{`r.n ==`, `"é😀" == 1 && missing == 2`, `unknown_function(r)`, `cpuMinimum >= "2"`, `r.spec.`, `r.spec.con`, `r.hardware.cpu`, `r.typo == 1`} {
		record("diagnostic-"+text, "observed", diagnostic(e, text))
	}
	se, err := cel.NewEnv(cel.Variable("r", cel.ObjectType("main.Pod")), ext.NativeTypes(reflect.TypeOf(Pod{}), ext.ParseStructTag("json")))
	must(err)
	for _, text := range []string{`r.spec.`, `r.spec.con`, `r.spec.containers.exists(c, c.image == "agent:v2")`, `r.hardware.cpu == 4`, `r.spec.nodeName == 2`} {
		record("schema-diagnostic-"+text, "observed", diagnostic(se, text))
	}
	p, _ := compile(se, `r.spec.containers.exists(c, c.name == "sidecar" && c.image == "agent:v2")`)
	record("schema-native-struct-evaluation", "supported", map[string]any{"registration": "library ext.NativeTypes + JSON tags; hand-declared Go structs, NOT provider catalog-schema adapter", "evaluation": evalEvidence(p, map[string]any{"r": Pod{Spec: PodSpec{Containers: []Container{{Name: "sidecar", Image: "agent:v2"}}}}})})
	record("partial-completion", "unsupported", map[string]any{"scope": "No editor completion API located in public cel/parser packages; trailing dot returns no AST; r.spec.con compiles as ordinary dyn field in dynamic environment but fails undefined-field in typed environment; neither emits suggestions", "schemaFields": []string{"spec.containers", "spec.nodeName"}, "note": "These fields are declared in probe structs, not generated engine completions. Cursor context recovery, union catalog lookup and suggestion ranking need host tooling; not implemented."})
	re := environment(cel.ParserRecursionLimit(20), cel.ParserExpressionSizeLimit(128))
	for _, text := range []string{strings.Repeat("(", 40) + "true" + strings.Repeat(")", 40), strings.Repeat(" ", 129) + "true"} {
		record("parser-explicit-bound", "observed", diagnostic(re, text))
	}
}

// Deliberately bounded builder: literals (string/int/bool/null), declared identifiers,
// map/field selection, &&, ==, >=. No comprehensions/functions/OR accepted.
type Node struct {
	Kind     string `json:"kind"`
	Name     string `json:"name,omitempty"`
	Value    any    `json:"value"`
	Children []Node `json:"children,omitempty"`
}

func toBuilder(x ast.Expr) (Node, error) {
	n := Node{}
	switch x.Kind() {
	case ast.IdentKind:
		if x.AsIdent() != "r" && x.AsIdent() != "environment" && x.AsIdent() != "cpuMinimum" {
			return n, fmt.Errorf("identifier outside subset")
		}
		n.Kind = "identifier"
		n.Name = x.AsIdent()
	case ast.LiteralKind:
		n.Kind = "literal"
		switch v := x.AsLiteral().(type) {
		case types.String:
			n.Value = string(v)
		case types.Int:
			n.Value = int64(v)
		case types.Bool:
			n.Value = bool(v)
		case types.Null:
			n.Value = nil
		default:
			return n, fmt.Errorf("literal outside subset")
		}
	case ast.SelectKind:
		s := x.AsSelect()
		if s.IsTestOnly() {
			return n, fmt.Errorf("presence outside subset")
		}
		n.Kind = "select"
		n.Name = s.FieldName()
		b, err := toBuilder(s.Operand())
		if err != nil {
			return n, err
		}
		n.Children = []Node{b}
	case ast.CallKind:
		c := x.AsCall()
		if c.IsMemberFunction() {
			return n, fmt.Errorf("member call outside subset")
		}
		switch c.FunctionName() {
		case operators.LogicalAnd, operators.Equals, operators.GreaterEquals, operators.Index:
		default:
			return n, fmt.Errorf("call %s outside subset", c.FunctionName())
		}
		n.Kind = "call"
		n.Name = c.FunctionName()
		for _, a := range c.Args() {
			b, err := toBuilder(a)
			if err != nil {
				return n, err
			}
			n.Children = append(n.Children, b)
		}
	default:
		return n, fmt.Errorf("AST kind %d outside subset", x.Kind())
	}
	return n, nil
}
func fromBuilder(n Node, f ast.ExprFactory, next *int64) (ast.Expr, error) {
	*next++
	id := *next
	children := []ast.Expr{}
	for _, a := range n.Children {
		b, err := fromBuilder(a, f, next)
		if err != nil {
			return nil, err
		}
		children = append(children, b)
	}
	switch n.Kind {
	case "identifier":
		if n.Name != "r" && n.Name != "environment" && n.Name != "cpuMinimum" {
			return nil, fmt.Errorf("identifier outside subset")
		}
		return f.NewIdent(id, n.Name), nil
	case "literal":
		var v any = n.Value
		if j, ok := v.(json.Number); ok {
			i, err := j.Int64()
			if err != nil {
				return nil, err
			}
			v = i
		}
		switch v.(type) {
		case nil, string, int64, bool:
		default:
			return nil, fmt.Errorf("literal outside subset: %T", v)
		}
		return f.NewLiteral(id, types.DefaultTypeAdapter.NativeToValue(v)), nil
	case "select":
		if len(children) != 1 {
			return nil, fmt.Errorf("select arity")
		}
		return f.NewSelect(id, children[0], n.Name), nil
	case "call":
		switch n.Name {
		case operators.LogicalAnd, operators.Equals, operators.GreaterEquals, operators.Index:
		default:
			return nil, fmt.Errorf("operator outside subset")
		}
		if len(children) != 2 {
			return nil, fmt.Errorf("call arity")
		}
		return f.NewCall(id, n.Name, children...), nil
	}
	return nil, fmt.Errorf("kind outside subset")
}
func builder(e *cel.Env, c Corpus) {
	for _, text := range []string{`r.kind == "cloud" && r.n >= cpuMinimum`, `r.labels["app.kubernetes.io/name"] == "api"`, `r.n >= 2`, `r.nullable == null`, `r.State.Running == true`, `r.state == environment`, `r.interfaces[0].public == false`} {
		p, a := compile(e, text)
		n, err := toBuilder(a.NativeRep().Expr())
		must(err)
		encoded, err := json.Marshal(n)
		must(err)
		var loaded Node
		dec := json.NewDecoder(bytes.NewReader(encoded))
		dec.UseNumber()
		must(dec.Decode(&loaded))
		next := int64(0)
		native, err := fromBuilder(loaded, ast.NewExprFactory(), &next)
		must(err)
		pe, err := ast.ExprToProto(native)
		must(err)
		rebuilt := cel.ParsedExprToAst(&exprpb.ParsedExpr{Expr: pe})
		checked, iss := e.Check(rebuilt)
		must(iss.Err())
		txt, err := cel.AstToString(checked)
		must(err)
		q, _ := compile(e, txt)
		pairs := []map[string]any{}
		equal := true
		for _, r := range c.Resources {
			a, b := evalEvidence(p, bindings(r, c)), evalEvidence(q, bindings(r, c))
			if !reflect.DeepEqual(a, b) {
				equal = false
			}
			pairs = append(pairs, map[string]any{"id": r["id"], "text": a, "builder": b})
		}
		check("builder-subset-"+text, equal, true, map[string]any{"builder": json.RawMessage(encoded), "unparsed": txt, "perResource": pairs, "declaredSubset": "literal string/int/bool/null; r/environment/cpuMinimum; selection/index; && == >="})
	}
	_, a := compile(e, `r.tags.exists(t, t.key == "env" && t.value == "prod")`)
	_, err := toBuilder(a.NativeRep().Expr())
	record("builder-subset-reject-comprehension", "supported", map[string]any{"rejected": err != nil, "error": fmt.Sprint(err)})
	p, a := compile(e, primary)
	kinds := map[string]int{}
	ast.PreOrderVisit(a.NativeRep().Expr(), ast.NewExprVisitor(func(x ast.Expr) { kinds[strconv.Itoa(int(x.Kind()))]++ }))
	checked, err := cel.AstToCheckedExpr(a)
	must(err)
	wire, err := proto.Marshal(checked)
	must(err)
	j, err := protojson.Marshal(checked)
	must(err)
	restored := &exprpb.CheckedExpr{}
	must(proto.Unmarshal(wire, restored))
	rp, err := e.Program(cel.CheckedExprToAst(restored))
	must(err)
	got, errs := ids(rp, c, nil)
	want, _ := ids(p, c, nil)
	text, err := cel.AstToString(a)
	must(err)
	check("checked-ast-serialization", got, want, map[string]any{"protobufBytes": len(wire), "protojsonBytes": len(j), "runtimeErrors": errs, "nativeVisitorKindCounts": kinds, "kindCodes": "1 call, 2 comprehension, 3 identifier, 5 literal, 7 select", "macroCalls": len(a.SourceInfo().GetMacroCalls()), "sourcePositions": len(a.SourceInfo().GetPositions()), "text": text, "policy": "pin CEL environment/library/extension versions and recheck untrusted loaded expressions; this probe only reloads its own checked AST in same environment"})
	must(os.WriteFile("checked-ast.json", j, 0644))
	ranges := []map[string]any{}
	ast.PreOrderVisit(a.NativeRep().Expr(), ast.NewExprVisitor(func(x ast.Expr) {
		r, ok := a.NativeRep().SourceInfo().GetOffsetRange(x.ID())
		ranges = append(ranges, map[string]any{"id": x.ID(), "kind": int(x.Kind()), "start": r.Start, "stop": r.Stop, "found": ok, "type": a.NativeRep().GetType(x.ID()).String()})
	}))
	record("ast-native-offset-ranges", "observed", map[string]any{"text": primary, "nodes": ranges, "note": "AST ranges and diagnostic point positions are distinct APIs; do not invent diagnostic end positions"})
}

func pushdown(e *cel.Env, c Corpus) {
	full, _ := compile(e, `r.kind == "cloud" && `+primary)
	candidate, _ := compile(e, `r.kind == "cloud"`)
	residual, _ := compile(e, primary)
	want, _ := ids(full, c, nil)
	subset := Corpus{Parameters: c.Parameters, Resources: []map[string]any{}}
	for _, r := range c.Resources {
		v, _, err := candidate.Eval(bindings(r, c))
		must(err)
		if v == types.True {
			subset.Resources = append(subset.Resources, r)
		}
	}
	got, errs := ids(residual, subset, nil)
	check("pushdown-prefilter-residual", got, want, map[string]any{"candidate": "r.kind == cloud", "residual": primary, "runtimeErrors": errs, "claim": "logical simulation only, not provider capability/native equivalence proof"})
	filter, _ := compile(e, `r.n >= 3`)
	page := func(rows []map[string]any) []string {
		valid := []map[string]any{}
		for _, r := range rows {
			v, _, err := filter.Eval(bindings(r, c))
			must(err)
			if v == types.True {
				valid = append(valid, r)
			}
		}
		sort.Slice(valid, func(i, j int) bool {
			a, b := valid[i]["n"].(int64), valid[j]["n"].(int64)
			if a == b {
				return valid[i]["id"].(string) < valid[j]["id"].(string)
			}
			return a < b
		})
		out := []string{}
		for i := range min(len(valid), 2) {
			out = append(out, valid[i]["id"].(string))
		}
		return out
	}
	reference := page(c.Resources)
	check("pushdown-final-sort-page", reference, []string{"container-a", "pod-a"}, map[string]any{"residual": "r.n >= 3", "order": "n ascending then id", "limit": 2})
	unsafe := page(c.Resources[:2])
	check("pushdown-reject-unsafe-candidate-limit", reflect.DeepEqual(reference, unsafe), false, map[string]any{"reference": reference, "unsafeCandidateLimit2": unsafe, "hostDecision": "reject candidate limit before residual/global sort without equivalence proof"})
}

// API-required estimator with no schema/cardinality or custom-call hints.
type noHints struct{}

func (noHints) EstimateSize(checker.AstNode) *checker.SizeEstimate { return nil }
func (noHints) EstimateCallCost(string, string, *checker.AstNode, []checker.AstNode) *checker.CallEstimate {
	return nil
}

func limits(e *cel.Env) {
	xs := make([]int64, 1000000)
	for i := range xs {
		xs[i] = int64(i)
	}
	text := `xs.all(x, x >= 0)`
	p, a := compile(e, text, cel.CostLimit(100))
	v, d, err := p.Eval(map[string]any{"xs": xs})
	m := map[string]any{"expression": text, "limit": 100, "value": fmt.Sprint(v), "error": fmt.Sprint(err), "errorGoType": fmt.Sprintf("%T", err)}
	if d != nil && d.ActualCost() != nil {
		m["actualCost"] = *d.ActualCost()
	}
	check("cost-limit", err != nil, true, m)
	estimate, err := e.EstimateCost(a, noHints{})
	record("static-cost-estimate", "observed", map[string]any{"min": estimate.Min, "max": estimate.Max, "error": fmt.Sprint(err), "note": "API-required estimator object returns nil for all hints; no schema cardinalities supplied; initial probe passing nil estimator panicked at checker/cost.go:923"})
	q, _ := compile(e, text, cel.InterruptCheckFrequency(1), cel.CostTracking(nil))
	for _, mode := range []string{"pre-canceled", "during-evaluation"} {
		ctx, cancel := context.WithCancel(context.Background())
		if mode == "pre-canceled" {
			cancel()
		} else {
			timer := time.AfterFunc(time.Millisecond, cancel)
			defer timer.Stop()
		}
		start := time.Now()
		v, d, err := q.ContextEval(ctx, map[string]any{"xs": xs})
		elapsed := time.Since(start)
		cancel()
		m := map[string]any{"mode": mode, "expression": text, "listLength": len(xs), "frequency": 1, "elapsedNs": elapsed.Nanoseconds(), "value": fmt.Sprint(v), "error": fmt.Sprint(err), "errorGoType": fmt.Sprintf("%T", err)}
		if d != nil && d.ActualCost() != nil {
			m["actualCost"] = *d.ActualCost()
		}
		check("context-cancellation-"+mode, err != nil, true, m)
	}
	scalar, _ := compile(e, `true`, cel.InterruptCheckFrequency(1))
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	v, _, err = scalar.ContextEval(ctx, map[string]any{})
	record("context-cancellation-scalar", "observed", map[string]any{"value": fmt.Sprint(v), "error": fmt.Sprint(err), "note": "interrupt checks are loop checkpoints, not guaranteed preflight cancellation for every scalar expression"})
}

var sink any

func bench(e *cel.Env, c Corpus) map[string]any {
	activations := make([]map[string]any, len(c.Resources))
	for i, r := range c.Resources {
		activations[i] = map[string]any{"r": r}
	}
	configurations := []struct {
		name string
		opts []cel.ProgramOption
	}{{"default-uninstrumented", nil}, {"cost-tracked", []cel.ProgramOption{cel.CostTracking(nil)}}}
	all := []map[string]any{}
	for _, config := range configurations {
		p, _ := compile(e, primary, config.opts...)
		for i := range 5000 {
			v, _, err := p.Eval(activations[i%len(activations)])
			must(err)
			sink = v
		}
		runs := []map[string]any{}
		for _, n := range []int{5000, 50000} {
			for run := 1; run <= 3; run++ {
				matches := 0
				start := time.Now()
				for i := range n {
					v, _, err := p.Eval(activations[i%len(activations)])
					must(err)
					if v == types.True {
						matches++
					}
				}
				elapsed := time.Since(start)
				runs = append(runs, map[string]any{"evaluations": n, "run": run, "totalNs": elapsed.Nanoseconds(), "nsPerEvaluation": float64(elapsed.Nanoseconds()) / float64(n), "matches": matches, "expectedMatches": n / 5})
				if matches != n/5 {
					failures++
				}
			}
		}
		allocation := testing.Benchmark(func(b *testing.B) {
			b.ReportAllocs()
			for i := range b.N {
				v, _, err := p.Eval(activations[i%len(activations)])
				must(err)
				sink = v
			}
		})
		all = append(all, map[string]any{"configuration": config.name, "expression": primary, "compiledOnce": true, "warmupEvaluations": 5000, "decodingAndBindingsAllocationExcluded": true, "runs": runs, "allocationMeasurement": map[string]any{"method": "testing.Benchmark automatic N, deterministic mixed resources", "N": allocation.N, "allocsPerOp": allocation.AllocsPerOp(), "bytesPerOp": allocation.AllocedBytesPerOp(), "nsPerOp": allocation.NsPerOp()}})
	}
	parsed, iss := e.Parse(primary)
	must(iss.Err())
	checked, iss := e.Check(parsed)
	must(iss.Err())
	measure := func(fn func()) map[string]any {
		b := testing.Benchmark(func(b *testing.B) {
			b.ReportAllocs()
			for range b.N {
				fn()
			}
		})
		return map[string]any{"N": b.N, "nsPerOp": b.NsPerOp(), "allocsPerOp": b.AllocsPerOp(), "bytesPerOp": b.AllocedBytesPerOp()}
	}
	return map[string]any{"scope": "per-resource predicate only; no collection transform/sort/page/decoding", "timingInterpretation": "three descriptive runs, not percentiles; parent sequential rerun authoritative", "evaluation": all, "preparation": map[string]any{"parseOnly": measure(func() { a, iss := e.Parse(primary); must(iss.Err()); sink = a }), "checkParsedAst": measure(func() { a, iss := e.Check(parsed); must(iss.Err()); sink = a }), "compileParseAndCheck": measure(func() { a, iss := e.Compile(primary); must(iss.Err()); sink = a }), "programConstructionFromCheckedAst": measure(func() { p, err := e.Program(checked); must(err); sink = p })}}
}

func main() {
	path := "../corpus.json"
	if len(os.Args) > 1 {
		path = os.Args[1]
	}
	raw, err := os.ReadFile(path)
	must(err)
	var c Corpus
	d := json.NewDecoder(bytes.NewReader(raw))
	d.UseNumber()
	must(d.Decode(&c))
	for _, r := range c.Resources {
		normalize(r)
	}
	normalize(c.Parameters)
	e := environment()
	semantic(e, c)
	transport(e)
	diagnostics(e)
	builder(e, c)
	pushdown(e, c)
	limits(e)
	benchmarks := bench(e, c)
	deps := []map[string]string{}
	if b, ok := debug.ReadBuildInfo(); ok {
		for _, d := range b.Deps {
			deps = append(deps, map[string]string{"path": d.Path, "version": d.Version, "sum": d.Sum})
		}
	}
	hardware, hwerr := exec.Command("sysctl", "-n", "machdep.cpu.brand_string").Output()
	result := map[string]any{"library": "cel.dev/cel-go", "version": "v0.32.0", "environment": map[string]any{"go": runtime.Version(), "os": runtime.GOOS, "arch": runtime.GOARCH, "cpus": runtime.NumCPU(), "gomaxprocs": runtime.GOMAXPROCS(0), "hardware": strings.TrimSpace(string(hardware)), "hardwareError": fmt.Sprint(hwerr), "time": time.Now().UTC().Format(time.RFC3339)}, "dependencies": deps, "observations": observations, "benchmarks": benchmarks, "assertionFailures": failures}
	out, err := json.MarshalIndent(result, "", "  ")
	must(err)
	must(os.WriteFile("results.json", append(out, '\n'), 0644))
	fmt.Printf("CEL v0.32.0: %d observations; %d assertion failures; results.json written\n", len(observations), failures)
	if failures != 0 {
		os.Exit(1)
	}
}
