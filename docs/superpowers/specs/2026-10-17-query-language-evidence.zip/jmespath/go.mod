module omniview.local/jmespath-spike

go 1.24.0

require (
	github.com/jmespath-community/go-jmespath v1.1.1
	github.com/jmespath/go-jmespath v0.4.0
)

require golang.org/x/exp v0.0.0-20230314191032-db074128a8ec // indirect
