package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"reflect"
	"runtime"
	"strings"
	"testing"
	"time"
	"unicode/utf8"

	community "github.com/jmespath-community/go-jmespath"
	"github.com/jmespath-community/go-jmespath/pkg/binding"
	"github.com/jmespath-community/go-jmespath/pkg/functions"
	"github.com/jmespath-community/go-jmespath/pkg/interpreter"
	"github.com/jmespath-community/go-jmespath/pkg/parsing"
	standard "github.com/jmespath/go-jmespath"
)

type M = map[string]any
type Program interface{ Search(any) (any, error) }
type Engine struct {
	Name    string
	Compile func(string) (Program, error)
}

var engines = []Engine{
	{"github.com/jmespath/go-jmespath@v0.4.0", func(s string) (Program, error) { return standard.Compile(s) }},
	{"github.com/jmespath-community/go-jmespath@v1.1.1", func(s string) (Program, error) { return community.Compile(s) }},
}
var sink any

func fatal(err error) {
	if err != nil {
		panic(err)
	}
}
func same(a, b any) bool { x, _ := json.Marshal(a); y, _ := json.Marshal(b); return bytes.Equal(x, y) }
func eval(e Engine, expression string, input any) (out M) {
	out = M{"expression": expression}
	defer func() {
		if p := recover(); p != nil {
			out["panic"] = fmt.Sprint(p)
		}
	}()
	p, err := e.Compile(expression)
	if err != nil {
		out["compileError"] = err.Error()
		return
	}
	out["compiled"] = true
	value, err := p.Search(input)
	out["value"] = value
	if err != nil {
		out["evalError"] = err.Error()
	}
	return
}
func selectIDs(e Engine, expression string, rows []any, params M, envelope bool) M {
	result := M{"expression": expression, "bindingMode": "none"}
	if envelope {
		result["bindingMode"] = "typed input envelope (not native lexical bindings)"
	}
	p, err := e.Compile(expression)
	if err != nil {
		result["compileError"] = err.Error()
		return result
	}
	ids := []string{}
	values := []any{}
	errs := []string{}
	for _, row := range rows {
		input := row
		if envelope {
			input = M{"resource": row, "parameters": params}
		}
		v, err := p.Search(input)
		values = append(values, v)
		if err != nil {
			errs = append(errs, err.Error())
		}
		if v == true {
			ids = append(ids, row.(map[string]any)["id"].(string))
		}
	}
	result["ids"] = ids
	result["rowValues"] = values
	result["errors"] = errs
	return result
}
func check(r M, expected any) M {
	r["expectedIds"] = expected
	r["pass"] = same(r["ids"], expected)
	return r
}
func semantic(e Engine, rows []any, params M) []M {
	cases := []struct {
		id, expr string
		expected []string
	}{
		{"tag-same-element", "length((tags || `[]`)[?key == 'env' && value == 'prod']) > `0`", []string{"cloud-a"}},
		{"quoted-map-key", "labels.\"app.kubernetes.io/name\" == 'api'", []string{"cloud-a"}},
		{"container-nested-bool", "State.Running == `true`", []string{"container-a"}},
		{"correlated-array", "length((interfaces || `[]`)[?name == 'eth0' && public == `true`]) > `0`", []string{}},
		{"pod-array", "length((spec.containers || `[]`)[?name == 'sidecar' && image == 'agent:v2']) > `0`", []string{"pod-a"}},
		{"explicit-null", "contains(keys(@), 'nullable') && nullable == `null`", []string{"cloud-a"}},
		{"missing", "!contains(keys(@), 'nullable')", []string{"cloud-b", "container-a", "vm-100", "pod-a"}},
		{"lookup-null-collapses-missing", "nullable == `null`", []string{"cloud-a", "cloud-b", "container-a", "vm-100", "pod-a"}},
		{"exact-string-transport-not-integer-semantics", "exact == '9007199254740993'", []string{"cloud-a"}},
	}
	results := []M{}
	for _, c := range cases {
		r := check(selectIDs(e, c.expr, rows, nil, false), c.expected)
		r["id"] = c.id
		results = append(results, r)
	}
	numeric := check(selectIDs(e, "resource.hardware.cpu >= parameters.cpuMinimum", rows, params, true), []string{"vm-100"})
	numeric["id"] = "numeric-typed"
	results = append(results, numeric)
	for _, v := range []struct {
		id    string
		value any
		want  []string
	}{{"bound-string", params["environment"], []string{"cloud-a"}}, {"bound-malicious", params["malicious"], []string{}}, {"bound-wrong-number-type", "2", []string{}}} {
		expression := "contains((resource.tags || `[]`)[?key == 'env'].value, parameters.environment)"
		binding := M{"environment": v.value}
		if v.id == "bound-wrong-number-type" {
			expression = "resource.hardware.cpu >= parameters.cpuMinimum"
			binding = M{"cpuMinimum": v.value}
		}
		r := check(selectIDs(e, expression, rows, binding, true), v.want)
		r["id"] = v.id
		results = append(results, r)
	}
	pageRows := append([]any(nil), rows...)
	page := eval(e, "sort_by(resources, &n)[1:3].id", M{"resources": pageRows})
	page["id"] = "global-sort-page"
	page["expected"] = []string{"cloud-b", "container-a"}
	page["pass"] = same(page["value"], page["expected"])
	page["inputSliceMutated"] = !same(pageRows, rows)
	page["isolation"] = "collection sort receives a shallow slice copy; original deterministic corpus order preserved for every predicate/benchmark"
	results = append(results, page)
	return results
}
func numeric(e Engine) []M {
	raw := []byte(`{"a":9007199254740993,"b":9007199254740992}`)
	var floats any
	fatal(json.Unmarshal(raw, &floats))
	var numbers any
	d := json.NewDecoder(bytes.NewReader(raw))
	d.UseNumber()
	fatal(d.Decode(&numbers))
	var integers map[string]int64
	fatal(json.Unmarshal(raw, &integers))
	inputs := []struct {
		name  string
		value any
	}{{"json.Unmarshal float64", floats}, {"json.Decoder.UseNumber", numbers}, {"json.Unmarshal typed int64 map", M{"a": integers["a"], "b": integers["b"]}}}
	out := []M{}
	for _, in := range inputs {
		for _, expr := range []string{"a == b", "a > b", "a == `9007199254740993`", "type(a)", "to_number(a)", "`9007199254740993` == `9007199254740992`"} {
			r := eval(e, expr, in.value)
			r["decoding"] = in.name
			r["inputAType"] = fmt.Sprintf("%T", in.value.(map[string]any)["a"])
			out = append(out, r)
		}
	}
	return out
}
func diagnostics(e Engine, rows []any) []M {
	out := []M{}
	for _, expr := range []string{"resources[?n > ]", "\"é😀\". ]", "spec.", "spec.con", "State.Running", "no_such_fn(@)", "n > 'two'", "contains(n, 'x')", "unknown.deep", "timestamp('2026-10-17T00:00:00Z')", "to_timestamp('bad')", "'2026-10-17T00:00:00Z' > '2026-10-16T23:00:00Z'"} {
		r := eval(e, expr, rows[0])
		_, err := e.Compile(expr)
		if err != nil {
			switch x := err.(type) {
			case standard.SyntaxError:
				r["offset"] = x.Offset
				r["highlight"] = x.HighlightLocation()
			case community.SyntaxError:
				r["offset"] = x.Offset
				r["highlight"] = x.HighlightLocation()
			}
		}
		r["utf8Bytes"] = len(expr)
		r["unicodeCodepoints"] = utf8.RuneCountInString(expr)
		r["utf16Units"] = len([]rune(expr))
		for _, c := range expr {
			if c > 0xffff {
				r["utf16Units"] = r["utf16Units"].(int) + 1
			}
		}
		out = append(out, r)
	}
	return out
}
func controls(e Engine) M {
	methods := []string{}
	p, err := e.Compile("@")
	fatal(err)
	t := reflect.TypeOf(p)
	for i := range t.NumMethod() {
		methods = append(methods, t.Method(i).Type.String())
	}
	nests := []M{}
	for _, n := range []int{32, 128, 512} {
		r := eval(e, strings.Repeat("(", n)+"`true`"+strings.Repeat(")", n), nil)
		r["depth"] = n
		nests = append(nests, r)
	}
	return M{"compiledPublicMethods": methods, "contextCancellation": "unsupported: no context-bearing evaluation API", "costBudget": "unsupported: no evaluator step/cost hook or budget in inspected API/interpreter", "nestingProbes": nests, "limitInterpretation": "Successful finite nesting does not prove unbounded safety; no adversarial unbounded run; caller input limits are not evaluator cancellation."}
}
func astEvidence() M {
	expr := "kind == 'cloud' && state == 'running'"
	a, err := standard.NewParser().Parse(expr)
	fatal(err)
	sa, _ := json.Marshal(a)
	ca, err := community.NewParser().Parse(expr)
	fatal(err)
	cb, _ := json.Marshal(ca)
	var decoded parsing.ASTNode
	fatal(json.Unmarshal(cb, &decoded))
	caller := interpreter.NewFunctionCaller(functions.GetDefaultFunctions()...)
	row := M{"kind": "cloud", "state": "running"}
	v, err := interpreter.NewInterpreter(row, caller, nil).Execute(decoded, row)
	errText := ""
	if err != nil {
		errText = err.Error()
	}
	fields := []M{}
	t := reflect.TypeOf(a)
	for i := range t.NumField() {
		f := t.Field(i)
		fields = append(fields, M{"name": f.Name, "exported": f.IsExported()})
	}
	var count func(parsing.ASTNode) int
	count = func(n parsing.ASTNode) int {
		c := 1
		for _, child := range n.Children {
			c += count(child)
		}
		return c
	}
	original, err := interpreter.NewInterpreter(row, caller, nil).Execute(ca, row)
	fatal(err)
	return M{"expression": expr, "standard": M{"fields": fields, "json": string(sa), "prettyPrint": a.String(), "visitor": "unsupported via exported API; fields private"}, "community": M{"json": string(cb), "visitedNodes": count(ca), "originalASTEval": original, "jsonRoundtripEval": v, "jsonRoundtripError": errText, "roundtripWarning": "interface-held comparator enum decodes as float64, not token enum; JSON encoding alone is not an executable portable AST contract", "stability": "source explicitly calls AST an implementation detail; no source ranges"}}
}

// Deliberately limited builder: field path, literal, eq, and. No parsing of arbitrary text.
type Builder struct {
	Op    string    `json:"op"`
	Path  []string  `json:"path,omitempty"`
	Value any       `json:"value,omitempty"`
	Args  []Builder `json:"args,omitempty"`
}

func (b Builder) Text() (string, error) {
	switch b.Op {
	case "field":
		p := []string{}
		for _, s := range b.Path {
			x, _ := json.Marshal(s)
			p = append(p, string(x))
		}
		return strings.Join(p, "."), nil
	case "literal":
		v, err := json.Marshal(b.Value)
		return "`" + strings.ReplaceAll(string(v), "`", "\\u0060") + "`", err
	case "eq", "and":
		if len(b.Args) != 2 {
			return "", fmt.Errorf("binary arity")
		}
		l, err := b.Args[0].Text()
		if err != nil {
			return "", err
		}
		r, err := b.Args[1].Text()
		if err != nil {
			return "", err
		}
		op := " == "
		if b.Op == "and" {
			op = " && "
		}
		return "(" + l + op + r + ")", nil
	}
	return "", fmt.Errorf("outside builder subset: %s", b.Op)
}
func fromAST(n parsing.ASTNode) (Builder, error) {
	switch n.NodeType {
	case parsing.ASTField:
		return Builder{Op: "field", Path: []string{n.Value.(string)}}, nil
	case parsing.ASTLiteral:
		return Builder{Op: "literal", Value: n.Value}, nil
	case parsing.ASTSubexpression:
		parts := []string{}
		for _, c := range n.Children {
			b, err := fromAST(c)
			if err != nil || b.Op != "field" {
				return Builder{}, fmt.Errorf("not a field path")
			}
			parts = append(parts, b.Path...)
		}
		return Builder{Op: "field", Path: parts}, nil
	case parsing.ASTComparator, parsing.ASTAndExpression:
		op := "and"
		if n.NodeType == parsing.ASTComparator {
			if n.Value != parsing.TOKEQ {
				return Builder{}, fmt.Errorf("comparator outside subset")
			}
			op = "eq"
		}
		args := []Builder{}
		for _, c := range n.Children {
			b, err := fromAST(c)
			if err != nil {
				return Builder{}, err
			}
			args = append(args, b)
		}
		return Builder{Op: op, Args: args}, nil
	}
	return Builder{}, fmt.Errorf("AST node outside subset: %s", n.NodeType)
}
func builderEvidence(rows []any) M {
	b := Builder{Op: "and", Args: []Builder{{Op: "eq", Args: []Builder{{Op: "field", Path: []string{"kind"}}, {Op: "literal", Value: "cloud"}}}, {Op: "eq", Args: []Builder{{Op: "field", Path: []string{"state"}}, {Op: "literal", Value: "running"}}}}}
	text, err := b.Text()
	fatal(err)
	a, err := community.NewParser().Parse(text)
	fatal(err)
	back, err := fromAST(a)
	fatal(err)
	again, err := back.Text()
	fatal(err)
	out := M{"declaredSubset": []string{"field path", "JSON literal", "equality", "binary conjunction"}, "builder": b, "text": text, "roundtrippedBuilder": back, "roundtripEqual": same(b, back), "roundtripText": again, "engines": []M{}, "standardReverse": "unsupported: opaque AST; no reverse parser invented"}
	for _, e := range engines {
		r := check(selectIDs(e, text, rows, nil, false), []string{"cloud-a"})
		r["engine"] = e.Name
		out["engines"] = append(out["engines"].([]M), r)
	}
	outside, err := community.NewParser().Parse("sort_by(@, &n)")
	fatal(err)
	_, err = fromAST(outside)
	out["outsideSubsetRejected"] = err.Error()
	malicious := Builder{Op: "eq", Args: []Builder{{Op: "field", Path: []string{"state"}}, {Op: "literal", Value: "running` || `true"}}}
	mt, err := malicious.Text()
	fatal(err)
	out["literalBacktickEscape"] = M{"text": mt, "result": eval(engines[0], mt, rows[0])}
	return out
}
func bindingEvidence(rows []any, params M) M {
	caller := interpreter.NewFunctionCaller(functions.GetDefaultFunctions()...)
	out := []M{}
	for _, v := range []any{params["environment"], params["malicious"], float64(2)} {
		expr := "length((tags || `[]`)[?key == 'env' && value == $environment]) > `0`"
		a, err := community.NewParser().Parse(expr)
		fatal(err)
		ids := []string{}
		for _, row := range rows {
			bindings := binding.NewBindings().Register("$environment", v)
			result, err := interpreter.NewInterpreter(row, caller, bindings).Execute(a, row)
			fatal(err)
			if result == true {
				ids = append(ids, row.(map[string]any)["id"].(string))
			}
		}
		out = append(out, M{"expression": expr, "valueType": fmt.Sprintf("%T", v), "ids": ids, "expectedIds": func() []string {
			if v == params["environment"] {
				return []string{"cloud-a"}
			}
			return []string{}
		}()})
	}
	return M{"standardNativeVariableProbe": eval(engines[0], "$environment", rows[0]), "communityPublicInterpreterBindingAPI": out, "typeChecking": "Values are bound without text substitution, but no declarations/static binding type checking. Envelope binding also safe but dynamic. Community high-level Compile/Search lacks bindings argument."}
}
func pushdown(e Engine, rows []any) M {
	root := M{"resources": rows}
	full := eval(e, "sort_by(resources[?n >= `2` && n <= `4`], &n)[1:3].id", root)
	pre := eval(e, "resources[?n >= `2`]", root)
	hybrid := eval(e, "sort_by(resources[?n <= `4`], &n)[1:3].id", M{"resources": pre["value"]})
	unsafe := eval(e, "resources[?n >= `2`][:2]", root)
	unsafeFinal := eval(e, "sort_by(resources[?n <= `4`], &n)[1:3].id", M{"resources": unsafe["value"]})
	return M{"full": full, "candidate": pre, "hybrid": hybrid, "expected": []string{"container-a", "pod-a"}, "equivalent": same(full["value"], hybrid["value"]), "expectedPass": same(full["value"], []string{"container-a", "pod-a"}), "unsafeCandidateLimit": unsafeFinal, "unsafeEquivalent": same(full["value"], unsafeFinal["value"]), "scope": "Logical prefilter/residual simulation only, not provider API proof; n total here, null/missing/order ties not validated by this fixture."}
}
func benchmark(e Engine, rows []any) M {
	expr := "length((tags || `[]`)[?key == 'env' && value == 'prod']) > `0`"
	p, err := e.Compile(expr)
	fatal(err)
	for i := range 5000 {
		sink, err = p.Search(rows[i%len(rows)])
		fatal(err)
	}
	runs := []M{}
	for _, n := range []int{5000, 50000} {
		for run := range 3 {
			matches := 0
			start := time.Now()
			for i := range n {
				v, err := p.Search(rows[i%len(rows)])
				fatal(err)
				if v == true {
					matches++
				}
				sink = v
			}
			elapsed := time.Since(start)
			runs = append(runs, M{"evaluations": n, "run": run + 1, "totalNs": elapsed.Nanoseconds(), "nsPerEvaluation": float64(elapsed.Nanoseconds()) / float64(n), "matches": matches, "expectedMatches": n / 5, "pass": matches == n/5})
		}
	}
	alloc := testing.Benchmark(func(b *testing.B) {
		for i := range b.N {
			sink, err = p.Search(rows[i%len(rows)])
			if err != nil {
				b.Fatal(err)
			}
		}
	})
	compile := testing.Benchmark(func(b *testing.B) {
		for range b.N {
			sink, err = e.Compile(expr)
			if err != nil {
				b.Fatal(err)
			}
		}
	})
	return M{"expression": expr, "workload": "per-resource deterministic corpus cycle; decode excluded; compiled once; default evaluator; no cost instrumentation", "warmupEvaluations": 5000, "runs": runs, "evaluationAllocationBenchmark": M{"iterations": alloc.N, "nsPerOp": alloc.NsPerOp(), "allocsPerOp": alloc.AllocsPerOp(), "bytesPerOp": alloc.AllocedBytesPerOp()}, "parseAndCompileBenchmark": M{"iterations": compile.N, "nsPerOp": compile.NsPerOp(), "allocsPerOp": compile.AllocsPerOp(), "bytesPerOp": compile.AllocedBytesPerOp()}, "check": "No separate type-check phase exists in these APIs; parse+compile combined."}
}
func main() {
	corpusPath := "../corpus.json"
	if len(os.Args) > 1 {
		corpusPath = os.Args[1]
	}
	raw, err := os.ReadFile(corpusPath)
	fatal(err)
	var corpus map[string]any
	fatal(json.Unmarshal(raw, &corpus))
	rows := corpus["resources"].([]any)
	params := corpus["parameters"].(map[string]any)
	hw, _ := exec.Command("sysctl", "-n", "machdep.cpu.brand_string").Output()
	report := M{"generatedAt": time.Now().UTC().Format(time.RFC3339), "throwaway": true, "corpus": corpusPath, "environment": M{"go": runtime.Version(), "os": runtime.GOOS, "arch": runtime.GOARCH, "numCPU": runtime.NumCPU(), "gomaxprocs": runtime.GOMAXPROCS(0), "hardware": strings.TrimSpace(string(hw))}, "engines": []M{}, "ast": astEvidence(), "builder": builderEvidence(rows), "bindings": bindingEvidence(rows, params)}
	for _, e := range engines {
		report["engines"] = append(report["engines"].([]M), M{"name": e.Name, "semantics": semantic(e, rows, params), "numeric": numeric(e), "diagnostics": diagnostics(e, rows), "controls": controls(e), "pushdown": pushdown(e, rows), "benchmark": benchmark(e, rows)})
	}
	encoded, err := json.MarshalIndent(report, "", "  ")
	fatal(err)
	fatal(os.WriteFile("results.json", append(encoded, '\n'), 0644))
	fmt.Printf("wrote results.json; engines=%d corpusRows=%d\n", len(engines), len(rows))
}
