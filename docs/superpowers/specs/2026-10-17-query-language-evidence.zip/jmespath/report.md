# JMESPath Go comparison — throwaway evidence

## Scope and recommendation

These are real Go evaluations of the shared corpus, not a proposed production engine. Source, pinned module files, executable `probe`, and `results.json` are in this directory. No product source or repository module was changed.

**Recommendation:** neither tested JMESPath implementation meets the complete resource-foundation semantic/safety boundary as shipped. Both handle provider-neutral nested JSON predicates well and cheaply, including same-element correlation, exact quoted map keys, and presence tests. Both fail exact-integer numeric semantics in their normal numeric domain, have no timestamp value domain/default timestamp parser, no static schema/type-check boundary, and no in-evaluator cancellation/cost-budget API. Do not equate passing the explicitly narrowed string-transport test with passing the corpus's exact-integer requirement.

The community fork materially improves AST access and native lexical bindings, but does not solve these blocking numeric/control requirements. If JMESPath is selected despite those trade-offs, do not adopt upstream's opaque AST as Omniview's logical query contract or serialize the fork's raw AST as a portable contract. Keep language-native parsed trees internal to a pinned adapter; justify a small, explicitly typed planner/builder IR only for the supported pushdown/builder subset. Reject text outside that subset when conversion is requested. A universal IR or second interpreter is not established or warranted by this experiment. An IR would not fix the tested evaluators' number precision or cancellation.

## Versions and rationale

| Candidate | Pin | Published version timestamp | Role |
|---|---|---|---|
| Established upstream | `github.com/jmespath/go-jmespath v0.4.0` | 2020-09-18T23:53:51Z | Baseline established release |
| Community fork | `github.com/jmespath-community/go-jmespath v1.1.1` | 2023-05-31T18:40:41Z | Material alternative: exported AST fields, public interpreter, externally supplied lexical bindings |

The fork was included because those APIs directly change the feasibility of the requested builder/planner and safe-binding probes, not because more candidates are inherently better. Maintenance evidence is limited: its default-branch API returned commit `ef5fae83c6c0eb042599aad2d509ce829167f4b2`, a dependency update dated 2025-02-28. This is newer activity than the release, **not** evidence of active 2026 language development or a support commitment. No unreleased branch code was evaluated. `go.sum` pins module content; the fork version resolves to origin commit `4a4bfbff5d014f1fc5c0c8b660562b2ca172bc96`.

## Reproduce

Run from this directory:

```sh
GOWORK=off go mod download -json
GOWORK=off go mod tidy
gofmt -w main.go
GOWORK=off go build -o probe .
./probe
```

The executable takes an optional corpus path; default is `../corpus.json`. It writes `results.json` in its current directory. Alternatively, `GOWORK=off go run .` executes the same source. The final executed command was `gofmt -w main.go && GOWORK=off go build -o probe . && ./probe`; exit status 0, stdout:

```text
wrote results.json; engines=2 corpusRows=5
```

Earlier development runs: the first `GOWORK=off go run .` exposed a harness mistake registering `environment` instead of the fork's exact `$environment` binding name (`panic: variable not defined: $environment`). The next run completed but exposed fixture-order contamination by library `sort_by`. Source inspection established that sorting mutates input slices. Final source isolates collection-sort input with a shallow slice copy, records the mutation explicitly, and preserves original corpus order for both candidates and all benchmark loops. These are disclosed harness corrections, not engine feature failures. No product test suite/build was run.

## Shared semantic outcomes

Both implementations produced the following final observed results. Fourteen labeled semantic observations per implementation have `pass: true`; these include controls and narrower transport observations and must not be reported as fourteen independent full feature guarantees.

| Probe | Observed result | Assessment |
|---|---|---|
| Same tag element `key=env && value=prod` | `cloud-a` only; `cloud-b` does not falsely match across elements | Supported |
| Quoted key `labels."app.kubernetes.io/name"` | `cloud-a` | Supported |
| Nested `State.Running` boolean | `container-a` | Supported |
| Numeric `hardware.cpu >= cpuMinimum` with bound number 2 | `vm-100` | Supported for float64 domain; dynamic input envelope |
| Interface same-element `name=eth0 && public=true` | Empty, despite separate matching elements on cloud-a | Supported correlation |
| Pod container `name=sidecar && image=agent:v2` | `pod-a` | Supported |
| Explicit nullable null | `cloud-a` using `contains(keys(@), 'nullable') && nullable == null` | Supported via parent-key presence check |
| Missing nullable | cloud-b, container-a, vm-100, pod-a in corpus order | Supported via `!contains(keys(@), 'nullable')` |
| Plain nullable equality with null | All five rows | Missing lookup and explicit null collapse at lookup; this is standard language behavior |
| Global ascending n, offset 1, limit 2 | cloud-b, container-a | Supported collection transform, separate from predicate benchmarks |
| Bound environment `prod` | `cloud-a` | Supported via typed input envelope; no text interpolation |
| Malicious bound string `prod' \|\| true \|\| '` | Empty | Remains a value, not executable syntax |
| Number binding replaced by string `"2"` | Empty, values null rather than binding/type diagnostic | No static typed binding validation |
| Decimal-preserving string equality | `cloud-a` | Supported string transport only, **not exact integer semantics** |

The input envelope is an ordinary Go data value `{resource, parameters}`. The correlated bound-tag expression first selects tags with fixed key env, then checks their values against the separately addressed parameter using `contains`. No resource rewriting, lexical substitution, custom function, or interpreter was added. Standard JMESPath has no variable syntax: `$environment` fails compilation. The community fork additionally executes a parsed native `$environment` expression through its public `binding.NewBindings().Register("$environment", value)` and `interpreter.NewInterpreter(...).Execute(...)`: prod matches cloud-a; the malicious string and float64 2 match none. This is a real native binding API, but high-level `Compile/Search` has no bindings argument and there is no declaration/static binding type checker.

### Exact integer decoding/evaluation

The probe actually decodes JSON numbers `9007199254740993` and `9007199254740992` through three paths, then executes both candidates' real APIs:

| Path | `a == b` | `a > b` | `a == numeric literal 9007199254740993` | `type(a)` / `to_number(a)` |
|---|---|---|---|---|
| `json.Unmarshal` into interface{} | true (collision) | false | true (rounded) | number / 9007199254740992 |
| `json.Decoder.UseNumber` | false | null | false | `unknown type` errors |
| `json.Unmarshal` into map[string]int64, preserved as int64 values in evaluator input | false | null | false | `unknown type` errors |

Even independent numeric literals `9007199254740993 == 9007199254740992` evaluate **true** in both implementations. Preserving Go representations avoids transport loss but does not make those representations supported evaluator numbers. Data-to-data equality happens to distinguish their different values; it is not a complete numeric solution. Both libraries' comparator implementations explicitly assert float64 for ordering. JMESPath's specification lists JSON numbers, including integers; do **not** mislabel float64-only behavior or literal collisions as a universal requirement of every possible JMESPath implementation. No custom big-integer extension was installed.

### Timestamp, diagnostics and authoring

Observed in both candidates:

- `timestamp('2026-10-17T00:00:00Z')` and `to_timestamp('bad')` compile, then fail with unknown-function errors. Default function tables contain neither timestamp/date functions. The standard language JSON type domain has no timestamp type. Malformed timestamp validation is therefore unsupported, not passed. Direct ISO-looking string ordering also returns null; strings are not temporal values. No custom timestamp function was supplied.
- `resources[?n > ]` fails with a syntax error at offset 15. The Unicode probe `"é😀". ]` reports offset 10: a UTF-8 byte offset (the source has 11 bytes, 7 Unicode codepoints, 8 UTF-16 units). An editor adapter must convert offsets and derive end ranges; APIs expose a single offset, not start/end spans.
- `spec.` fails at offset 5; `spec.con` parses but returns null on the cloud row. `State.Running` likewise parses on an inapplicable cloud row and returns null. `unknown.deep` is accepted and returns null. There is no schema environment, field-resolution/type-check API, partial AST recovery, or completion engine in these inspected APIs. These are executed parser/runtime observations, not a claim that schema-aware completion has been implemented.
- Unknown functions are discovered at evaluation, not compile. `n > 'two'` returns null without error; `contains(n, 'x')` returns an invalid-type error. Host validation cannot be replaced with successful `Compile`.

## AST and bounded builder evidence

Upstream `NewParser().Parse` returns a nominally exported AST type, but all three fields are private. Reflection recorded them as unexported; `encoding/json` produced `{}`. PrettyPrint exists, but source explicitly declares the AST an implementation detail whose output must not be relied on. No unsupported reflection/unsafe access or PrettyPrint parser was invented.

The fork exposes `NodeType`, `Value`, `Children`; a real recursive visitor counted seven nodes for the conjunction fixture. The original parsed AST executed to true through the public interpreter. JSON serialization and unmarshal succeeded but re-evaluation returned null with no error: comparator values stored in interface{} lost their token-enum type and became float64. Thus exported fields are useful for a pinned adapter, not proof of a stable executable serialization contract. The fork retains the same implementation-detail disclaimer. Neither AST carries source spans.

The declared builder subset is field paths, JSON literals, equality, and binary conjunction. Its small structured Go representation emits escaped candidate-native text; the real fork parser maps the supported nodes back to the structured subset, reproducing the original builder and emitted text. Both engines execute the emitted conjunction and select cloud-a. `sort_by(@, &n)` is explicitly rejected by this reverse conversion as outside the subset. Backticks inside a builder string literal are encoded as JSON `\u0060`; the actual emitted expression evaluates false rather than executing injected syntax. This is literal emission, **not parameter binding**. Only this narrow conjunction fixture and escaping control were executed; arbitrary nested-path/literal combinations and general-language roundtrip are not established. Upstream reverse conversion remains unsupported because its AST is opaque.

## Native pushdown simulation

Full reference: `n >= 2 && n <= 4`, final numeric sort, offset 1, limit 2. Candidate prefilter: `n >= 2`; residual: `n <= 4`; final ordering/window retained after residual. Both engines produce container-a, pod-a in full and hybrid paths. Applying a candidate-side limit before residual/order produces an empty final page instead: **non-equivalent**, as expected.

This is only logical local prefilter/residual equivalence over the fixed fixture, not evidence about any real provider's native semantics, pagination, representation coverage, or query API. Null/missing order, identity tie breaks, tied values, and capability negotiation are not covered. Both engines mutate the input slice passed to `sort_by`; final harness copies that collection slice to avoid sharing/mutation contamination. This matters for a future host adapter but is not measured inside per-resource timings.

## Real control/safety evidence

Reflection found only `Search(interface{}) (interface{}, error)` on compiled objects. Pinned API/interpreter source has no context, cancellation, cost, budget, or step hook; the fork public interpreter has `Execute(ASTNode, interface{})`, likewise without control arguments. This is **source/API evidence of unsupported evaluator cancellation/cost metering**, not an executed cancellation success. No goroutine-abandonment wrapper was used or claimed to stop evaluation.

Finite parenthesis nesting depths 32, 128, and 512 compile and evaluate true in both. They establish acceptance of those inputs only: no maximum depth, stack safety, memory bound, or adversarial safety guarantee. No unbounded input was run. Caller-side row/expression limits and between-row context checks would be separate host mechanisms and do not interrupt a costly individual evaluation.

## Benchmark evidence

Environment: Go go1.26.1, darwin/arm64, Apple M5 Max, 18 logical CPUs, GOMAXPROCS 18. All numbers below are exploratory local observations; another spike may have been running concurrently. Parent must rerun candidates sequentially for the decision record. No p95 or end-to-end/provider latency claim is made.

Primary workload is exactly the shared benchmark contract: one resource at a time in original `resources[i % 5]` order, compiled once, decoded fixtures outside timing, 5,000 warmup evaluations, three measured runs each at 5,000 and 50,000 evaluations, default evaluator without cost instrumentation. Expression:

```jmespath
length((tags || `[]`)[?key == 'env' && value == 'prod']) > `0`
```

| Candidate / evaluations | Total ns for runs 1 / 2 / 3 | ns/eval for runs 1 / 2 / 3 | Matches each run |
|---|---|---|---|
| Upstream / 5,000 | 531042 / 583375 / 537000 | 106.2084 / 116.675 / 107.4 | 1000 |
| Upstream / 50,000 | 5538875 / 5354208 / 5747125 | 110.7775 / 107.08416 / 114.9425 | 10000 |
| Community / 5,000 | 870833 / 1037375 / 886666 | 174.1666 / 207.475 / 177.3332 | 1000 |
| Community / 50,000 | 8999708 / 8768334 / 8995292 | 179.99416 / 175.36668 / 179.90584 | 10000 |

Separate Go `testing.Benchmark` measurements over the deterministic row cycle:

| Candidate | Eval ns/op | Eval allocs/op | Eval bytes/op | Parse+compile ns/op | Compile allocs/op | Compile bytes/op |
|---|---|---|---|---|---|---|
| Upstream | 111 | 2 | 44 | 2446 | 107 | 8568 |
| Community | 181 | 3 | 92 | 4912 | 163 | 18016 |

Allocation figures use Go BenchmarkResult's integer per-operation reporting and may truncate fractional mixed-workload allocation counts. Compile metrics combine parsing and compiled-program/function-table creation: neither API offers a separate static checking phase. Collection sorting/transformation, decoding, native-binding interpreter setup, wire encoding, and real acquisition are not included in primary predicate measurements. Full per-run values and actual benchmark iteration counts are in `results.json`.

## Explicit unsupported / unknown boundary

Unsupported as shipped in the tested libraries: exact integer numeric comparisons/order/literals at the collision boundary; timestamp parsing/types; schema-aware static validation; declaration-checked typed bindings; evaluator cancellation/cost limits; portable raw-AST JSON roundtrip; upstream visitor/reverse-builder access. Standard language lacks native variables and timestamp domain; fork variables are community extensions. Presence can be tested through object keys, but missing is not a first-class value distinct from lookup null.

Unknown/not established: real provider pushdown, authorization/schema integration, cancellation under production providers, cross-client language tooling, a complete planner IR, safe evaluation under adversarial nesting/data, sort tie/null ordering policy, all builder combinations, end-to-end latency and wire cost. These results do not justify silently adding extensions to manufacture parity.

## Primary sources

- Standard language domain, identifiers/missing, grammar, functions: https://jmespath.org/specification.html
- Upstream pinned release metadata: https://proxy.golang.org/github.com/jmespath/go-jmespath/@v/v0.4.0.info
- Upstream API: https://github.com/jmespath/go-jmespath/blob/v0.4.0/api.go
- Upstream AST opacity/disclaimer: https://github.com/jmespath/go-jmespath/blob/v0.4.0/parser.go#L39-L55
- Upstream float64 comparator: https://github.com/jmespath/go-jmespath/blob/v0.4.0/interpreter.go#L31-L65
- Upstream UTF-8 byte positions and SyntaxError: https://github.com/jmespath/go-jmespath/blob/v0.4.0/lexer.go
- Upstream mutating sort implementation: https://github.com/jmespath/go-jmespath/blob/v0.4.0/functions.go#L735-L764
- Community release metadata: https://proxy.golang.org/github.com/jmespath-community/go-jmespath/@v/v1.1.1.info
- Community branch maintenance observation: https://github.com/jmespath-community/go-jmespath/commit/ef5fae83c6c0eb042599aad2d509ce829167f4b2
- Community API: https://github.com/jmespath-community/go-jmespath/blob/v1.1.1/pkg/api/api.go
- Community exposed AST/disclaimer: https://github.com/jmespath-community/go-jmespath/blob/v1.1.1/pkg/parsing/parser.go#L46-L62
- Community binding API: https://github.com/jmespath-community/go-jmespath/blob/v1.1.1/pkg/binding/binding.go
- Community interpreter API/numeric behavior: https://github.com/jmespath-community/go-jmespath/blob/v1.1.1/pkg/interpreter/interpreter.go
- Community default functions: https://github.com/jmespath-community/go-jmespath/blob/v1.1.1/pkg/functions/default.go
