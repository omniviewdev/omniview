# CEL numeric-profile investigation — throwaway evidence

No product code/dependency changed. Direct upstream pin: cel.dev/cel-go v0.32.0. Parent executed these probes locally with Go go1.26.1. Run `sh reproduce.sh` from a fresh extraction to recreate the final experiments and isolated dependency suites. The archive preserves changed dependency source files (including original license headers), not the entire copied dependency or binaries. go.mod/go.sum pin the unmodified run; probe.mod/probe.sum select a relative, experimental module copy. The script fetches the pinned module before applying the two replacement files.

## Root cause and supported hooks

common/types/compare.go converts exact Int/Uint to Double before comparison, losing distinctions beyond 2^53 and at range boundaries. Equality's interpreter nodes call types.Equal directly, bypassing ordinary dispatcher overload replacement. The attempted ordinary Equals overload received zero invocations for `resource.s == 'prod'`, which remained true. CustomDecoratorV2 plus NewCall permits scalar guards with single operand evaluation, but aggregate Equal/Contains and optimized membership do not uniformly traverse those guarded scalar nodes.

The decorator is an interception probe, not a complete numeric profile or suggested production implementation. NewCall uses a varargs runtime path with allocation overhead; no performance equivalence is claimed. Recursively intercepting or prewalking aggregate comparisons would add semantic/cost work, and was not implemented.

## Observed stages

- hooks.json: early corpus, 44 observations, 11 mathematical mismatches, 14 runtime rejections. Primitive oracle had 432 directional comparison checks, nine failing input pairs.
- helpers-only.json: early corpus after only numeric helper changes, 44 observations, one mathematical mismatch (optimized int-literal membership), zero runtime rejections; primitive oracle passed all 432 checks. This command exited 1 as intended for unmet mathematical expectations.
- patched.json: early corpus after membership optimization changes too, 44 observations, zero mathematical mismatches/rejections, primitive oracle 432 checks with zero pair failures.
- hooks-expanded.json: expanded corpus with scalar decorator, 64 observations (32 expressions × optimize off/on), 13 mathematical mismatches, 24 runtime rejections. Direct native primitive oracle: 100816 checks, 4987 input pairs with at least one wrong outcome. That oracle deliberately calls native numeric types, not guarded interpreter operations.
- patched-expanded.json: same expanded corpus, unguarded native CEL using experimental dependency change: 64 observations, zero mathematical mismatches/rejections. Oracle: 100816 checks with zero pair failures.
- patched-typed.json: typed-checker extension with CrossTypeNumericComparisons(true), 72 observations: 68 actual boolean evaluations, four expected compile rejections for two mixed equality expressions × optimizer settings. Zero mathematical mismatches/unexpected runtime rejections; oracle 100816 checks with zero pair failures. CrossTypeNumericComparisons enables heterogeneous ordering, not heterogeneous equality checking. The first attempted typed extension panicked on the genuine checker rejection; final runner records the unsupported operations explicitly, without pretending they evaluated.

Historical smaller-stage JSON predates the expanded final runner. reproduce.sh reproduces final expanded stages, not byte-identical earlier harness revisions.

## Minimal dependency experiment

Only two production dependency files were changed, solely in an isolated temporary copy:

1. common/types/compare.go: two double/integer helpers check exclusive upper conversion bounds, truncate the double safely, compare integers exactly first, then compare the fractional remainder only when truncated integers agree. No big.Int/big.Rat allocation or resource traversal is added to these helpers. Reverse helpers already delegate to them.
2. interpreter/decorators.go: two constant-set conversion branches add double aliases only when the conversion preserves numeric equality. Helpers alone were insufficient because precomputed membership sets had stored rounded aliases.

This retains the existing CEL evaluator and native collection equality/membership. Explicit lossy conversion `double(resource.i)` retains its ordinary documented meaning; it cannot restore lost precision. The test oracle uses arbitrary-precision rational arithmetic independently of the runtime helper, over boundary tables and deterministic PCG samples (seeds 20261017/20261018). Actual binary64 values, not their originally intended decimal lexemes, define floating-point comparisons. It checks forward/reverse ordering and equality for signed and unsigned values, including finite fractions, nextafter neighborhoods and infinities. It is finite evidence, not exhaustive IEEE-754 or full-language conformance proof.

## Native regression suites

`GOWORK=off go test ./common/types ./interpreter -count=1` initially failed setup because the module download contains a vendor directory without complete vendored test dependencies. With explicit module resolution:

`GOWORK=off go test -mod=mod ./common/types ./interpreter -count=1`

both packages passed (observed 0.183s / 0.269s). No full dependency suite, host suite, performance benchmark, Wails bindings, query/source integration or provider test was run. No external issue/PR was created. No package/API release containing a fix was established.

## Sources

- Pinned implementation: https://github.com/cel-expr/cel-go/tree/v0.32.0
- Numeric helpers: https://github.com/cel-expr/cel-go/blob/v0.32.0/common/types/compare.go
- Equality nodes and NewCall: https://github.com/cel-expr/cel-go/blob/v0.32.0/interpreter/interpretable.go
- Optimized membership: https://github.com/cel-expr/cel-go/blob/v0.32.0/interpreter/decorators.go
- Program hooks: https://github.com/cel-expr/cel-go/blob/v0.32.0/cel/options.go
- Approved numeric comparison design: https://github.com/cel-expr/cel-spec/wiki/proposal-210 (runtime heterogeneous comparisons; parametric equality checker still requires matching types)
- Upstream master compare.go was fetched during investigation and still used integer-to-double comparison in the inspected content: https://raw.githubusercontent.com/cel-expr/cel-go/master/common/types/compare.go . This is not a claim about every release/branch.

## Recommendation and gates

Prefer an upstream narrow numeric/membership correction over a host-level replacement equality engine or broad ban on dynamic comparisons. Retain the exact tagged boundary and native CEL type-checker guarantees. A bounded temporary dependency patch may be considered if upstream timing requires it, but is not adopted or approved for production by this probe. Such adoption needs review, full conformance coverage, packaging/pin/update/removal ownership and measurements before release. Do not expand this into a wholesale fork.

Known static mixed equality still requires aligned operand types or deliberate dynamic dispatch; no source rewriting was introduced. Nullable/union static guarantees and all previously listed source/runtime/product integration gates remain unresolved by this numeric experiment.
