#!/bin/sh
set -eu
# Run from a fresh extraction of the evidence archive. Creates only this local module copy.
GOWORK=off go mod download
cache="$(GOWORK=off go env GOMODCACHE)"
if [ -e cel-go-probe ]; then
  echo 'cel-go-probe already exists; use a fresh extraction to avoid overwriting work' >&2
  exit 1
fi
cp -R "$cache/cel.dev/cel-go@v0.32.0" cel-go-probe
chmod -R u+w cel-go-probe
cp changes/compare.go cel-go-probe/common/types/compare.go
cp changes/decorators.go cel-go-probe/interpreter/decorators.go
GOWORK=off go run . -mode hooks -out reproduced-hooks.json
GOWORK=off go run -modfile=probe.mod . -mode native -out reproduced-patched.json
GOWORK=off go run -modfile=probe.mod . -mode native -cross-type -out reproduced-typed.json
(cd cel-go-probe && GOWORK=off go test -mod=mod ./common/types ./interpreter -count=1)
