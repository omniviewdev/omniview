package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"math"
	"math/big"
	"math/rand/v2"
	"os"

	"cel.dev/cel-go/cel"
	"cel.dev/cel-go/common/functions"
	"cel.dev/cel-go/common/operators"
	"cel.dev/cel-go/common/overloads"
	"cel.dev/cel-go/common/types"
	"cel.dev/cel-go/common/types/ref"
	"cel.dev/cel-go/common/types/traits"
	"cel.dev/cel-go/interpreter"
)

type sample struct {
	Name, Source string
	Want         bool
}
type observation struct {
	Name                     string `json:"name"`
	Source                   string `json:"source"`
	Optimize                 bool   `json:"optimize"`
	Want                     bool   `json:"mathematicalExpected"`
	Actual                   any    `json:"actual"`
	Error                    string `json:"error,omitempty"`
	Mismatch                 bool   `json:"mathematicalMismatch"`
	ExpectedCompileRejection bool   `json:"expectedCompileRejection,omitempty"`
}

func mixed(a, b ref.Val) bool {
	_, ad := a.(types.Double)
	_, bd := b.(types.Double)
	_, ai := a.(types.Int)
	_, au := a.(types.Uint)
	_, bi := b.(types.Int)
	_, bu := b.(types.Uint)
	return ad && (bi || bu) || bd && (ai || au)
}
func scalarGuard(i interpreter.InterpretableV2) (interpreter.InterpretableV2, error) {
	c, ok := i.(interpreter.InterpretableCall)
	if !ok {
		return i, nil
	}
	fn := c.Function()
	switch fn {
	case operators.Equals, operators.NotEquals, operators.Less, operators.LessEquals, operators.Greater, operators.GreaterEquals:
	default:
		return i, nil
	}
	if len(c.Args()) != 2 {
		return i, nil
	}
	return interpreter.NewCall(c.ID(), fn, c.OverloadID(), c.Args(), func(v ...ref.Val) ref.Val {
		if mixed(v[0], v[1]) {
			return types.NewErr("numeric_domain_mismatch: explicit conversion required")
		}
		if fn == operators.Equals {
			return types.Equal(v[0], v[1])
		}
		if fn == operators.NotEquals {
			e := types.Equal(v[0], v[1])
			if b, ok := e.(types.Bool); ok {
				return !b
			}
			return e
		}
		cmp, ok := v[0].(traits.Comparer)
		if !ok {
			return types.NewErr("not comparable")
		}
		r := cmp.Compare(v[1])
		n, ok := r.(types.Int)
		if !ok {
			return r
		}
		switch fn {
		case operators.Less:
			return types.Bool(n < 0)
		case operators.LessEquals:
			return types.Bool(n <= 0)
		case operators.Greater:
			return types.Bool(n > 0)
		default:
			return types.Bool(n >= 0)
		}
	}), nil
}
func main() {
	mode := flag.String("mode", "hooks", "hooks or native")
	out := flag.String("out", "results.json", "output JSON")
	crossType := flag.Bool("cross-type", false, "enable checked mixed numeric comparisons")
	flag.Parse()
	env, e := cel.NewEnv(cel.Variable("resource", cel.MapType(cel.StringType, cel.DynType)), cel.CrossTypeNumericComparisons(*crossType))
	if e != nil {
		panic(e)
	}
	vars := map[string]any{"resource": map[string]any{"i": int64(9007199254740993), "d": float64(9007199254740992), "u": uint64(math.MaxUint64), "upper": math.Exp2(64), "s": "prod", "labels": map[string]any{"env": "prod"}, "items": []any{int64(9007199254740993)}, "empty": []any{}}}
	cases := []sample{
		{"dynamic-equality", "resource.i == resource.d", false}, {"dynamic-order", "resource.d < resource.i", true}, {"reverse-order", "resource.i > resource.d", true},
		{"dynamic-inequality", "resource.i != resource.d", true}, {"uint-boundary", "resource.u == resource.upper", false},
		{"nested-list", "[resource.i] == [resource.d]", false}, {"nested-map", "{'n':resource.i} == {'n':resource.d}", false},
		{"list-membership", "resource.d in resource.items", false}, {"literal-int-membership", "resource.d in [9007199254740993]", false},
		{"literal-double-membership", "resource.i in [9007199254740992.0]", false}, {"nested-membership", "[resource.d] in [[resource.i]]", false},
		{"dynamic-string", "resource.s == 'prod'", true}, {"dynamic-map-access", "resource.labels['env'] == 'prod'", true}, {"dynamic-map-equality", "resource.labels == {'env':'prod'}", true},
		{"correlated-array", "[{'k':'env','v':'dev'},{'k':'team','v':'prod'}].exists(t,t.k=='env' && t.v=='prod')", false},
		{"presence", "has(resource.labels)", true}, {"same-domain", "resource.i == 9007199254740993", true}, {"explicit-lossy-conversion", "double(resource.i) == resource.d", true},
		{"guarded-exists", "resource.items.exists(n,n == resource.d)", false}, {"guarded-all", "resource.items.all(n,n != resource.d)", true},
		{"short-circuit", "false && resource.i == resource.d", false}, {"empty-membership", "resource.i in resource.empty", false},
		{"numeric-map-key", "resource.d in {9007199254740993:true}", false},
		{"numeric-map-key-reverse", "resource.i in {9007199254740992.0:true}", false},
		{"optimized-uint-membership", "resource.upper in [18446744073709551615u]", false},
		{"uint-order", "resource.u < resource.upper", true},
		{"exact-cross-int-uint", "dyn(1) == dyn(1u)", true},
		{"nested-mixed-object", "{'count':resource.i,'ratio':0.5} == {'count':resource.i,'ratio':0.5}", true},
		{"finite-fraction", "dyn(1) < dyn(1.5)", true},
		{"negative-fraction", "dyn(-1.5) < dyn(-1)", true},
		{"nan-equality", "dyn(double('NaN')) == dyn(0)", false},
		{"positive-infinity", "dyn(double('Infinity')) > resource.u", true},
	}
	if *crossType {
		cases = append(cases,
			sample{"typed-mixed-equality", "9007199254740993 == 9007199254740992.0", false},
			sample{"typed-mixed-order", "9007199254740993 > 9007199254740992.0", true},
			sample{"typed-small-mixed", "1 == 1.0", true},
			sample{"typed-uint-boundary", "18446744073709551615u < 18446744073709551616.0", true},
		)
	}
	observations := []observation{}
	for _, optimize := range []bool{false, true} {
		for _, tc := range cases {
			a, iss := env.Compile(tc.Source)
			wantCompileRejection := tc.Name == "typed-mixed-equality" || tc.Name == "typed-small-mixed"
			if iss.Err() != nil {
				if !wantCompileRejection {
					panic(iss.Err())
				}
				observations = append(observations, observation{Name: tc.Name, Source: tc.Source, Optimize: optimize, Want: tc.Want, Error: iss.Err().Error(), ExpectedCompileRejection: true})
				continue
			}
			if wantCompileRejection {
				panic("mixed equality unexpectedly compiled; review checker contract")
			}
			opts := []cel.ProgramOption{cel.CostLimit(10000)}
			if *mode == "hooks" {
				opts = append(opts, cel.CustomDecoratorV2(scalarGuard))
			}
			if optimize {
				opts = append(opts, cel.EvalOptions(cel.OptOptimize))
			}
			p, err := env.Program(a, opts...)
			if err != nil {
				panic(err)
			}
			v, _, err := p.Eval(vars)
			o := observation{Name: tc.Name, Source: tc.Source, Optimize: optimize, Want: tc.Want}
			if err != nil {
				o.Error = err.Error()
			} else if b, ok := v.(types.Bool); ok {
				o.Actual = bool(b)
				o.Mismatch = bool(b) != tc.Want
			} else {
				o.Actual = fmt.Sprint(v)
				o.Mismatch = true
			}
			observations = append(observations, o)
		}
	}
	// Equality has a dedicated interpreter node and bypasses ordinary overload bindings.
	hits := 0
	a, iss := env.Compile("resource.s == 'prod'")
	if iss.Err() != nil {
		panic(iss.Err())
	}
	p, err := env.Program(a, cel.Functions(&functions.Overload{Operator: overloads.Equals, Binary: func(a, b ref.Val) ref.Val { hits++; return types.False }}))
	if err != nil {
		panic(err)
	}
	val, _, err := p.Eval(vars)
	if err != nil {
		panic(err)
	}
	// Independent exact-rational oracle over deterministic scalar boundaries. No arbitrary-precision work is proposed in the runtime helper.
	ds := []float64{-math.Inf(1), -math.Exp2(63), -9007199254740992, -1.5, -0.5, 0, 0.5, 1.5, 9007199254740992, math.Exp2(63), math.Exp2(64), math.Inf(1)}
	is := []int64{math.MinInt64, math.MinInt64 + 1, -9007199254740993, -9007199254740992, -1, 0, 1, 9007199254740992, 9007199254740993, math.MaxInt64 - 1, math.MaxInt64}
	us := []uint64{0, 1, 9007199254740992, 9007199254740993, math.MaxInt64, math.MaxUint64 - 1, math.MaxUint64}
	oracleChecks, oracleFailures := 0, 0
	oracleExamples := []any{}
	check := func(d float64, n ref.Val, exact *big.Int) {
		want := 0
		if math.IsInf(d, 1) {
			want = 1
		} else if math.IsInf(d, -1) {
			want = -1
		} else {
			want = new(big.Rat).SetFloat64(d).Cmp(new(big.Rat).SetInt(exact))
		}
		actual := types.Double(d).Compare(n)
		rev := n.(traits.Comparer).Compare(types.Double(d))
		eq := types.Double(d).Equal(n)
		revEq := n.Equal(types.Double(d))
		oracleChecks += 4
		if actual != types.Int(want) || rev != types.Int(-want) || eq != types.Bool(want == 0) || revEq != types.Bool(want == 0) {
			oracleFailures++
			if len(oracleExamples) < 8 {
				oracleExamples = append(oracleExamples, map[string]any{"double": fmt.Sprint(d), "integer": exact.String(), "want": want, "actual": fmt.Sprint(actual), "reverse": fmt.Sprint(rev)})
			}
		}
	}
	for _, d := range ds {
		for _, i := range is {
			check(d, types.Int(i), big.NewInt(i))
		}
		for _, u := range us {
			check(d, types.Uint(u), new(big.Int).SetUint64(u))
		}
	}
	rng := rand.New(rand.NewPCG(20261017, 20261018))
	for range 5000 {
		i := int64(rng.Uint64())
		u := rng.Uint64()
		d := math.Float64frombits(rng.Uint64())
		if !math.IsNaN(d) {
			check(d, types.Int(i), big.NewInt(i))
			check(d, types.Uint(u), new(big.Int).SetUint64(u))
		}
		for _, near := range []float64{float64(i), math.Nextafter(float64(i), math.Inf(-1)), math.Nextafter(float64(i), math.Inf(1))} {
			check(near, types.Int(i), big.NewInt(i))
		}
	}
	mismatches, errors, expectedCompileRejections := 0, 0, 0
	for _, o := range observations {
		if o.Mismatch {
			mismatches++
		}
		if o.ExpectedCompileRejection {
			expectedCompileRejections++
		} else if o.Error != "" {
			errors++
		}
	}
	result := map[string]any{"mode": *mode, "crossTypeNumericChecking": *crossType, "cel": "cel.dev/cel-go v0.32.0", "observations": observations, "count": len(observations), "mathematicalMismatches": mismatches, "rejections": errors, "expectedCompileRejections": expectedCompileRejections, "ordinaryEqualityOverload": map[string]any{"hits": hits, "actual": fmt.Sprint(val)}, "scalarOracleChecks": oracleChecks, "scalarOraclePairFailures": oracleFailures, "oracleFailureExamples": oracleExamples}
	data, _ := json.MarshalIndent(result, "", "  ")
	if err := os.WriteFile(*out, data, 0600); err != nil {
		panic(err)
	}
	fmt.Printf("mode=%s observations=%d mathematical_mismatches=%d rejections=%d oracle_checks=%d oracle_pair_failures=%d overload_hits=%d\n", *mode, len(observations), mismatches, errors, oracleChecks, oracleFailures, hits)
	if *mode == "native" && (mismatches != 0 || oracleFailures != 0 || errors != 0) {
		os.Exit(1)
	}
}
